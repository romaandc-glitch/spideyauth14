# Spidey Auth JavaScript / TypeScript SDK

Official JavaScript and TypeScript client for **Spidey Auth** developer authentication, user management, and licensing. Works in Node.js, Electron, Next.js, React, and browser environments.

## Installation

```bash
npm install @spideyauth/sdk
```

## Quick Start

```typescript
import { SpideyAuth } from '@spideyauth/sdk';

const auth = new SpideyAuth({
  applicationId: 'APP-92JD83',
  applicationSecret: 'spy_sec_your_secret_here',
  baseUrl: 'https://api.spideyauth.dev',
});

// Authenticate user
const user = await auth.login('player123', 'secretPassword!');
console.log('Logged in as:', user.username);

// Activate license
const license = await auth.activateLicense('SPIDEY-XXXX-XXXX-XXXX-XXXX');
console.log('License activated! Type:', license.subscriptionType);

// Validate license
const check = await auth.validateLicense('SPIDEY-XXXX-XXXX-XXXX-XXXX');
console.log('Is valid:', check.valid);
```
