export interface SpideyAuthConfig {
  applicationId: string;
  applicationSecret: string;
  baseUrl?: string;
}

export interface SpideyUser {
  id: string;
  username: string;
  email?: string;
  status: string;
  subscriptionRole: string;
  expiresAt?: string;
  lastLoginAt?: string;
}

export interface SpideyLicense {
  status: string;
  subscriptionType: string;
  activations: number;
  maxActivations: number;
  expires?: string;
  activatedAt: string;
}

export interface SpideyResponse<T = any> {
  success: boolean;
  user?: T;
  license?: T;
  message?: string;
  error?: {
    code: string;
    message: string;
  };
}

export class SpideyAuth {
  private applicationId: string;
  private applicationSecret: string;
  private baseUrl: string;
  public currentUser: SpideyUser | null = null;
  public currentLicense: SpideyLicense | null = null;

  constructor(config: SpideyAuthConfig) {
    this.applicationId = config.applicationId;
    this.applicationSecret = config.applicationSecret;
    this.baseUrl = (config.baseUrl || 'http://localhost:3000').replace(/\/$/, '');
  }

  private async request<T = any>(endpoint: string, body: Record<string, any>): Promise<T> {
    const response = await fetch(`${this.baseUrl}${endpoint}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-application-id': this.applicationId,
        'x-application-secret': this.applicationSecret,
      },
      body: JSON.stringify({
        applicationId: this.applicationId,
        applicationSecret: this.applicationSecret,
        ...body,
      }),
    });

    const data = await response.json();
    if (!response.ok || !data.success) {
      const err = new Error(data.error?.message || 'Spidey Auth API request failed');
      (err as any).code = data.error?.code || 'API_ERROR';
      throw err;
    }

    return data;
  }

  public async login(username: string, password: string, hwid?: string): Promise<SpideyUser> {
    const res = await this.request<{ success: boolean; user: SpideyUser }>('/api/user/login', {
      username,
      password,
      hwid: hwid || 'browser_client',
    });
    this.currentUser = res.user;
    return res.user;
  }

  public async register(username: string, password: string, email?: string, licenseKey?: string): Promise<SpideyUser> {
    const res = await this.request<{ success: boolean; user: SpideyUser }>('/api/user/register', {
      username,
      password,
      email,
      licenseKey,
    });
    this.currentUser = res.user;
    return res.user;
  }

  public async activateLicense(licenseKey: string, hwid?: string): Promise<SpideyLicense> {
    const res = await this.request<{ success: boolean; license: SpideyLicense }>('/api/license/activate', {
      licenseKey,
      username: this.currentUser?.username,
      hwid: hwid || 'browser_client',
    });
    this.currentLicense = res.license;
    return res.license;
  }

  public async validateLicense(licenseKey: string): Promise<{ valid: boolean; license: any }> {
    return this.request('/api/license/validate', { licenseKey });
  }

  public logout(): void {
    this.currentUser = null;
    this.currentLicense = null;
  }
}

/**
 * KeyAuth v1.3 Compatible Client for JavaScript / TypeScript
 * Drop-in replacement for KeyAuth Web / Node clients.
 */
export class KeyAuthApi {
  public name: string;
  public ownerid: string;
  public secret: string;
  public version: string;
  public url: string;
  public sessionId: string | null = null;
  public initialized = false;
  public response = { success: false, message: '' };
  public appData = { numUsers: '0', numKeys: '0', version: '1.0.0' };
  public userData: any = null;

  constructor(name: string, ownerid: string, ...rest: any[]) {
    this.name = name;
    this.ownerid = ownerid;

    if (rest.length >= 3) {
      // (name, ownerid, secret, version, url)
      this.secret = String(rest[0] || '');
      this.version = String(rest[1] || '1.0');
      this.url = String(rest[2] || 'http://localhost:3000/api/1.3/').replace(/\/$/, '') + '/';
    } else if (rest.length === 2) {
      if (typeof rest[1] === 'string' && (rest[1].startsWith('http://') || rest[1].startsWith('https://'))) {
        // (name, ownerid, version, url)
        this.secret = '';
        this.version = String(rest[0] || '1.0');
        this.url = rest[1].replace(/\/$/, '') + '/';
      } else {
        // (name, ownerid, secret, version)
        this.secret = String(rest[0] || '');
        this.version = String(rest[1] || '1.0');
        this.url = 'http://localhost:3000/api/1.3/';
      }
    } else {
      this.secret = '';
      this.version = String(rest[0] || '1.0');
      this.url = 'http://localhost:3000/api/1.3/';
    }
  }

  private async req(params: Record<string, string>): Promise<any> {
    const body = new URLSearchParams(params).toString();
    const res = await fetch(this.url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body,
    });
    const data = await res.json();
    this.response = { success: !!data.success, message: data.message || '' };
    return data;
  }

  public async init(): Promise<boolean> {
    const res = await this.req({
      type: 'init',
      ver: this.version,
      name: this.name,
      ownerid: this.ownerid,
    });
    if (res.success) {
      this.sessionId = res.sessionid;
      this.initialized = true;
      if (res.appinfo) {
        this.appData = res.appinfo;
      }
      return true;
    }
    return false;
  }

  public async login(username: string, pass: string, hwid = 'web-client'): Promise<boolean> {
    if (!this.initialized) throw new Error('Call init() first.');
    const res = await this.req({
      type: 'login',
      username,
      pass,
      hwid,
      sessionid: this.sessionId || '',
      name: this.name,
      ownerid: this.ownerid,
    });
    if (res.success && res.info) {
      this.userData = res.info;
      return true;
    }
    return false;
  }

  public async register(username: string, pass: string, key = '', email = '', hwid = 'web-client'): Promise<boolean> {
    if (!this.initialized) throw new Error('Call init() first.');
    const res = await this.req({
      type: 'register',
      username,
      pass,
      key,
      email,
      hwid,
      sessionid: this.sessionId || '',
      name: this.name,
      ownerid: this.ownerid,
    });
    if (res.success && res.info) {
      this.userData = res.info;
      return true;
    }
    return false;
  }

  public async license(key: string, hwid = 'web-client'): Promise<boolean> {
    if (!this.initialized) throw new Error('Call init() first.');
    const res = await this.req({
      type: 'license',
      key,
      hwid,
      sessionid: this.sessionId || '',
      name: this.name,
      ownerid: this.ownerid,
    });
    if (res.success && res.info) {
      this.userData = res.info;
      return true;
    }
    return false;
  }

  public async check(): Promise<boolean> {
    if (!this.initialized) throw new Error('Call init() first.');
    const res = await this.req({
      type: 'check',
      sessionid: this.sessionId || '',
      name: this.name,
      ownerid: this.ownerid,
    });
    return !!res.success;
  }
}

