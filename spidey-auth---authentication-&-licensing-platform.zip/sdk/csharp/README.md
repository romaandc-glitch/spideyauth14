# Spidey Auth C# SDK

Official .NET SDK for integrating **Spidey Auth** authentication, user management, and licensing into C# desktop apps, Unity games, and WPF/.NET Core services.

## Installation

Add the `SpideyAuthSDK` files to your project or reference the Spidey Auth library.

```csharp
using SpideyAuthSDK;

var auth = new SpideyAuth(
    applicationId: "APP-92JD83",
    applicationSecret: "spy_sec_your_secret_here",
    baseUrl: "https://your-domain.com"
);
```

## Quick Start Examples

### 1. User Login
```csharp
var response = await auth.LoginAsync("player123", "secretPassword!");
if (response.Success)
{
    Console.WriteLine($"Welcome {response.Data?.Username}!");
    Console.WriteLine($"Tier: {response.Data?.SubscriptionRole}");
}
else
{
    Console.WriteLine($"Login failed: [{response.ErrorCode}] {response.ErrorMessage}");
}
```

### 2. User Registration with License Key
```csharp
var response = await auth.RegisterAsync(
    username: "newPlayer",
    password: "securePassword123!",
    email: "player@example.com",
    licenseKey: "SPIDEY-XXXX-XXXX-XXXX-XXXX"
);
```

### 3. License Key Activation
```csharp
var licResponse = await auth.ActivateLicenseAsync("SPIDEY-AX91-KL84-99P2-44QR");
if (licResponse.Success)
{
    Console.WriteLine($"License activated! Type: {licResponse.Data?.SubscriptionType}");
}
```

### 4. License Validation Check
```csharp
var check = await auth.ValidateLicenseAsync("SPIDEY-AX91-KL84-99P2-44QR");
if (check.Success)
{
    Console.WriteLine("License is valid and operational.");
}
```

---

## KeyAuth Drop-In Compatibility (Windows Forms Example)

If you are migrating existing Windows Forms applications from KeyAuth, simply include `KeyAuthApp.cs` into your project and use:

```csharp
using KeyAuth;

public static api KeyAuthApp = new api(
    name: "Apex Velocity",                         // Application Name from Spidey Auth
    ownerid: "SPY-OWNER-82HD72",                   // Owner ID from Spidey Auth Dashboard
    version: "1.0",
    url: "https://your-domain.com/api/1.3/"         // Spidey Auth Gateway
);

public Form1()
{
    InitializeComponent();
    try
    {
        KeyAuthApp.init(); // MUST run before ANY login
    }
    catch (Exception ex)
    {
        MessageBox.Show(ex.Message, "Init Failed");
        Environment.Exit(0);
    }
}

// IN LOGIN BUTTON:
if (string.IsNullOrWhiteSpace(User.Text) || string.IsNullOrWhiteSpace(Pass.Text))
{
    MessageBox.Show("Username or Password empty");
    return;
}

KeyAuthApp.login(User.Text, Pass.Text);

if (KeyAuthApp.response.success)
{
    Form2 f2 = new Form2();
    f2.Show();
    this.Hide();
}
else
{
    MessageBox.Show(KeyAuthApp.response.message, "Login Failed");
}
```

```
