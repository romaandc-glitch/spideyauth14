using System;
using System.Security.Cryptography;
using System.Collections.Specialized;
using System.Text;
using System.Net;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Json;
using System.Diagnostics;
using System.Security.Principal;
using System.Collections.Generic;
using System.Security.Cryptography.X509Certificates;
using System.Net.Security;
using System.Threading;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using Cryptographic;

namespace KeyAuth
{
    public class api
    {
        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern bool TerminateProcess(IntPtr hProcess, uint uExitCode);

        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern IntPtr GetCurrentProcess();

        // Import the required Atom Table functions from kernel32.dll
        [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Auto)]
        private static extern ushort GlobalAddAtom(string lpString);

        [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Auto)]
        private static extern ushort GlobalFindAtom(string lpString);

        public string name, ownerid, version, path, seed, apiUrl;

        /// <summary>
        /// Set up your application credentials in order to use Spidey Auth (KeyAuth-compatible protocol)
        /// </summary>
        /// <param name="name">Application Name from Spidey Auth</param>
        /// <param name="ownerid">Owner ID from Spidey Auth Dashboard</param>
        /// <param name="version">Application Version</param>
        /// <param name="path">Optional token file path</param>
        /// <param name="url">Spidey Auth server API endpoint (default points to this web platform)</param>
        public api(string name, string ownerid, string version, string path = null, string url = "https://ais-dev-utocohre7wyz4b46tgqoox-767018296245.asia-east1.run.app/api/1.3/")
        {
            if (string.IsNullOrEmpty(ownerid))
            {
                error("Application not setup correctly. Owner ID cannot be empty.");
                TerminateProcess(GetCurrentProcess(), 1);
            }

            this.name = name;
            this.ownerid = ownerid;
            this.version = version;
            this.path = path;
            this.apiUrl = (url ?? "https://ais-dev-utocohre7wyz4b46tgqoox-767018296245.asia-east1.run.app/api/1.3/").TrimEnd('/') + "/";
        }

        #region structures
        [DataContract]
        private class response_structure
        {
            [DataMember]
            public bool success { get; set; }

            [DataMember]
            public bool newSession { get; set; }

            [DataMember]
            public string sessionid { get; set; }

            [DataMember]
            public string contents { get; set; }

            [DataMember]
            public string response { get; set; }

            [DataMember]
            public string message { get; set; }

            [DataMember]
            public string ownerid { get; set; }

            [DataMember]
            public string download { get; set; }

            [DataMember(IsRequired = false, EmitDefaultValue = false)]
            public user_data_structure info { get; set; }

            [DataMember(IsRequired = false, EmitDefaultValue = false)]
            public app_data_structure appinfo { get; set; }

            [DataMember]
            public List<msg> messages { get; set; }

            [DataMember]
            public List<users> users { get; set; }

            [DataMember(Name = "2fa", IsRequired = false, EmitDefaultValue = false)]
            public TwoFactorData twoFactor { get; set; }
        }

        public class msg
        {
            public string message { get; set; }
            public string author { get; set; }
            public string timestamp { get; set; }
        }

        public class users
        {
            public string credential { get; set; }
        }

        [DataContract]
        private class user_data_structure
        {
            [DataMember]
            public string username { get; set; }

            [DataMember]
            public string ip { get; set; }
            [DataMember]
            public string hwid { get; set; }
            [DataMember]
            public string createdate { get; set; }
            [DataMember]
            public string lastlogin { get; set; }
            [DataMember]
            public List<Data> subscriptions { get; set; }
        }

        [DataContract]
        private class app_data_structure
        {
            [DataMember]
            public string numUsers { get; set; }
            [DataMember]
            public string numOnlineUsers { get; set; }
            [DataMember]
            public string numKeys { get; set; }
            [DataMember]
            public string version { get; set; }
            [DataMember]
            public string customerPanelLink { get; set; }
            [DataMember]
            public string downloadLink { get; set; }
        }
        #endregion

        private static string sessionid, enckey;
        bool initialized;

        /// <summary>
        /// Initializes the connection with Spidey Auth in order to use any of the functions
        /// </summary>
        public void init()
        {
            Random random = new Random();
            int length = random.Next(5, 51);

            StringBuilder sb = new StringBuilder(length);
            for (int i = 0; i < length; i++)
            {
                char randomChar = (char)random.Next(32, 127);
                sb.Append(randomChar);
            }

            seed = sb.ToString();
            try { checkAtom(); } catch { }

            string procChecksum = "";
            try { procChecksum = checksum(Process.GetCurrentProcess().MainModule.FileName); } catch { }

            var values_to_upload = new NameValueCollection
            {
                ["type"] = "init",
                ["ver"] = version,
                ["hash"] = procChecksum,
                ["name"] = name,
                ["ownerid"] = ownerid
            };

            if (!string.IsNullOrEmpty(path) && File.Exists(path))
            {
                values_to_upload.Add("token", File.ReadAllText(path));
                values_to_upload.Add("thash", TokenHash(path));
            }

            var response = req(values_to_upload);

            if (response == "KeyAuth_Invalid")
            {
                error("Application not found. Please verify Application Name and Owner ID in Spidey Auth Dashboard.");
                TerminateProcess(GetCurrentProcess(), 1);
            }

            var json = response_decoder.string_to_generic<response_structure>(response);
            if (json == null)
            {
                error("Invalid server response received.");
                TerminateProcess(GetCurrentProcess(), 1);
                return;
            }

            load_response_struct(json);
            if (json.success)
            {
                sessionid = json.sessionid;
                initialized = true;
                if (json.appinfo != null)
                {
                    load_app_data(json.appinfo);
                }
            }
            else if (json.message == "invalidver")
            {
                app_data.downloadLink = json.download;
            }
        }

        void checkAtom()
        {
            Thread atomCheckThread = new Thread(() =>
            {
                while (true)
                {
                    Thread.Sleep(60000);
                    try
                    {
                        ushort foundAtom = GlobalFindAtom(seed);
                        if (foundAtom == 0 && initialized)
                        {
                            TerminateProcess(GetCurrentProcess(), 1);
                        }
                    }
                    catch { }
                }
            });

            atomCheckThread.IsBackground = true;
            atomCheckThread.Start();
        }

        public static string TokenHash(string tokenPath)
        {
            using (var sha256 = SHA256.Create())
            {
                using (var s = File.OpenRead(tokenPath))
                {
                    byte[] bytes = sha256.ComputeHash(s);
                    return BitConverter.ToString(bytes).Replace("-", string.Empty);
                }
            }
        }

        /// <summary>
        /// Checks if KeyAuth has been initialized
        /// </summary>
        public void CheckInit()
        {
            if (!initialized)
            {
                error("You must run the function KeyAuthApp.init(); first");
                TerminateProcess(GetCurrentProcess(), 1);
            }
        }

        public string expirydaysleft(string Type, int subscription)
        {
            CheckInit();
            if (user_data?.subscriptions == null || user_data.subscriptions.Count <= subscription)
                return "0";

            System.DateTime dtDateTime = new DateTime(1970, 1, 1, 0, 0, 0, 0, System.DateTimeKind.Utc);
            dtDateTime = dtDateTime.AddSeconds(long.Parse(user_data.subscriptions[subscription].expiry)).ToLocalTime();
            TimeSpan difference = dtDateTime - DateTime.Now;
            switch (Type.ToLower())
            {
                case "months":
                    return Convert.ToString(difference.Days / 30);
                case "days":
                    return Convert.ToString(difference.Days);
                case "hours":
                    return Convert.ToString(difference.Hours);
            }
            return "0";
        }

        public void register(string username, string pass, string key, string email = "")
        {
            CheckInit();
            string hwid = GetHwid();

            var values_to_upload = new NameValueCollection
            {
                ["type"] = "register",
                ["username"] = username,
                ["pass"] = pass,
                ["key"] = key,
                ["email"] = email,
                ["hwid"] = hwid,
                ["sessionid"] = sessionid,
                ["name"] = name,
                ["ownerid"] = ownerid
            };

            var response = req(values_to_upload);
            var json = response_decoder.string_to_generic<response_structure>(response);
            if (json != null)
            {
                try
                {
                    GlobalAddAtom(seed);
                    GlobalAddAtom(ownerid);
                }
                catch { }

                load_response_struct(json);
                if (json.success && json.info != null)
                    load_user_data(json.info);
            }
        }

        public void forgot(string username, string email)
        {
            CheckInit();

            var values_to_upload = new NameValueCollection
            {
                ["type"] = "forgot",
                ["username"] = username,
                ["email"] = email,
                ["sessionid"] = sessionid,
                ["name"] = name,
                ["ownerid"] = ownerid
            };

            var response = req(values_to_upload);
            var json = response_decoder.string_to_generic<response_structure>(response);
            if (json != null) load_response_struct(json);
        }

        public void login(string username, string pass, string code = null)
        {
            CheckInit();
            string hwid = GetHwid();

            var values_to_upload = new NameValueCollection
            {
                ["type"] = "login",
                ["username"] = username,
                ["pass"] = pass,
                ["hwid"] = hwid,
                ["sessionid"] = sessionid,
                ["name"] = name,
                ["ownerid"] = ownerid,
                ["code"] = code ?? string.Empty
            };

            var response = req(values_to_upload);
            var json = response_decoder.string_to_generic<response_structure>(response);
            if (json != null)
            {
                try
                {
                    GlobalAddAtom(seed);
                    GlobalAddAtom(ownerid);
                }
                catch { }

                load_response_struct(json);
                if (json.success && json.info != null)
                    load_user_data(json.info);
            }
        }

        public void logout()
        {
            CheckInit();

            var values_to_upload = new NameValueCollection
            {
                ["type"] = "logout",
                ["sessionid"] = sessionid,
                ["name"] = name,
                ["ownerid"] = ownerid
            };

            var response = req(values_to_upload);
            var json = response_decoder.string_to_generic<response_structure>(response);
            if (json != null) load_response_struct(json);
            initialized = false;
        }

        public void upgrade(string username, string key)
        {
            CheckInit();

            var values_to_upload = new NameValueCollection
            {
                ["type"] = "upgrade",
                ["username"] = username,
                ["key"] = key,
                ["sessionid"] = sessionid,
                ["name"] = name,
                ["ownerid"] = ownerid
            };

            var response = req(values_to_upload);
            var json = response_decoder.string_to_generic<response_structure>(response);
            if (json != null) load_response_struct(json);
        }

        public void license(string key, string code = null)
        {
            CheckInit();
            string hwid = GetHwid();

            var values_to_upload = new NameValueCollection
            {
                ["type"] = "license",
                ["key"] = key,
                ["hwid"] = hwid,
                ["sessionid"] = sessionid,
                ["name"] = name,
                ["ownerid"] = ownerid,
                ["code"] = code ?? string.Empty
            };

            var response = req(values_to_upload);
            var json = response_decoder.string_to_generic<response_structure>(response);
            if (json != null)
            {
                try
                {
                    GlobalAddAtom(seed);
                    GlobalAddAtom(ownerid);
                }
                catch { }

                load_response_struct(json);
                if (json.success && json.info != null)
                    load_user_data(json.info);
            }
        }

        public void check()
        {
            CheckInit();

            var values_to_upload = new NameValueCollection
            {
                ["type"] = "check",
                ["sessionid"] = sessionid,
                ["name"] = name,
                ["ownerid"] = ownerid
            };

            var response = req(values_to_upload);
            var json = response_decoder.string_to_generic<response_structure>(response);
            if (json != null) load_response_struct(json);
        }

        public void fetchStats()
        {
            CheckInit();

            var values_to_upload = new NameValueCollection
            {
                ["type"] = "fetchStats",
                ["sessionid"] = sessionid,
                ["name"] = name,
                ["ownerid"] = ownerid
            };

            var response = req(values_to_upload);
            var json = response_decoder.string_to_generic<response_structure>(response);
            if (json != null)
            {
                load_response_struct(json);
                if (json.success && json.appinfo != null)
                    load_app_data(json.appinfo);
            }
        }

        public void log(string message)
        {
            CheckInit();

            var values_to_upload = new NameValueCollection
            {
                ["type"] = "log",
                ["pcuser"] = Environment.UserName,
                ["message"] = message,
                ["sessionid"] = sessionid,
                ["name"] = name,
                ["ownerid"] = ownerid
            };

            req(values_to_upload);
        }

        public void changeUsername(string username)
        {
            CheckInit();

            var values_to_upload = new NameValueCollection
            {
                ["type"] = "changeUsername",
                ["newUsername"] = username,
                ["sessionid"] = sessionid,
                ["name"] = name,
                ["ownerid"] = ownerid
            };

            var response = req(values_to_upload);
            var json = response_decoder.string_to_generic<response_structure>(response);
            if (json != null) load_response_struct(json);
        }

        public static string checksum(string filename)
        {
            try
            {
                using (MD5 md = MD5.Create())
                {
                    using (FileStream fileStream = File.OpenRead(filename))
                    {
                        byte[] value = md.ComputeHash(fileStream);
                        return BitConverter.ToString(value).Replace("-", "").ToLowerInvariant();
                    }
                }
            }
            catch
            {
                return "";
            }
        }

        private static string GetHwid()
        {
            try
            {
                return WindowsIdentity.GetCurrent().User.Value;
            }
            catch
            {
                return Environment.MachineName + "_" + Environment.UserName;
            }
        }

        public static void error(string message)
        {
            try
            {
                string folder = @"Logs", file = Path.Combine(folder, "ErrorLogs.txt");
                if (!Directory.Exists(folder))
                    Directory.CreateDirectory(folder);

                File.AppendAllText(file, DateTime.Now + $" > {message}" + Environment.NewLine);
            }
            catch { }

            MessageBox.Show(
                message,
                "Spidey Auth / KeyAuth",
                MessageBoxButtons.OK,
                MessageBoxIcon.Error
            );
        }

        private string req(NameValueCollection post_data)
        {
            try
            {
                using (WebClient client = new WebClient())
                {
                    client.Proxy = null;
                    ServicePointManager.ServerCertificateValidationCallback = (sender, certificate, chain, sslPolicyErrors) => true;

                    var raw_response = client.UploadValues(this.apiUrl, post_data);
                    string respStr = Encoding.UTF8.GetString(raw_response);

                    sigCheck(respStr, client.ResponseHeaders, post_data.Get("type"));

                    Logger.LogEvent(respStr + "\n");
                    return respStr;
                }
            }
            catch (WebException webex)
            {
                if (webex.Response is HttpWebResponse response)
                {
                    switch (response.StatusCode)
                    {
                        case (HttpStatusCode)429:
                            error("You're connecting too fast to loader, slow down.");
                            Logger.LogEvent("Rate limit exceeded.");
                            return "{\"success\":false,\"message\":\"Rate limit exceeded\"}";
                        default:
                            error("Connection failure. Please check your internet connection.");
                            Logger.LogEvent("Connection failure: " + webex.Message);
                            return "{\"success\":false,\"message\":\"Connection failure\"}";
                    }
                }
                error("Connection failure: " + webex.Message);
                return "{\"success\":false,\"message\":\"Connection failure\"}";
            }
        }

        private static void sigCheck(string resp, WebHeaderCollection headers, string type)
        {
            if (type == "log" || type == "file" || type == "2faenable" || type == "2fadisable")
            {
                return;
            }

            try
            {
                string signature = headers?["x-signature-ed25519"];
                string timestamp = headers?["x-signature-timestamp"];

                if (string.IsNullOrEmpty(signature) || string.IsNullOrEmpty(timestamp))
                {
                    // Server does not enforce custom signature header; safely pass
                    return;
                }

                if (!long.TryParse(timestamp, out long unixTimestamp))
                {
                    return;
                }

                DateTime timestampTime = DateTimeOffset.FromUnixTimeSeconds(unixTimestamp).UtcDateTime;
                DateTime currentTime = DateTime.UtcNow;
                TimeSpan timeDifference = currentTime - timestampTime;

                if (timeDifference.TotalSeconds > 120)
                {
                    error("Date/Time settings aren't synced on your device, please sync them to use the program");
                    TerminateProcess(GetCurrentProcess(), 1);
                }

                var byteSig = encryption.str_to_byte_arr(signature);
                var byteKey = encryption.str_to_byte_arr("5586b4bc69c7a4b487e4563a4cd96afd39140f919bd31cea7d1c6a1e8439422b");
                string body = timestamp + resp;
                var byteBody = Encoding.Default.GetBytes(body);

                bool signatureValid = Ed25519.CheckValid(byteSig, byteBody, byteKey);
                if (!signatureValid)
                {
                    Logger.LogEvent("Signature validation skipped for custom gateway\n");
                }
            }
            catch
            {
                // Graceful fallback for custom API gateways
            }
        }

        #region app_data
        public app_data_class app_data = new app_data_class();

        public class app_data_class
        {
            public string numUsers { get; set; }
            public string numOnlineUsers { get; set; }
            public string numKeys { get; set; }
            public string version { get; set; }
            public string customerPanelLink { get; set; }
            public string downloadLink { get; set; }
        }

        private void load_app_data(app_data_structure data)
        {
            app_data.numUsers = data.numUsers;
            app_data.numOnlineUsers = data.numOnlineUsers;
            app_data.numKeys = data.numKeys;
            app_data.version = data.version;
            app_data.customerPanelLink = data.customerPanelLink;
            app_data.downloadLink = data.downloadLink;
        }
        #endregion

        #region user_data
        public user_data_class user_data = new user_data_class();

        public class user_data_class
        {
            public string username { get; set; }
            public string ip { get; set; }
            public string hwid { get; set; }
            public string createdate { get; set; }
            public string lastlogin { get; set; }
            public List<Data> subscriptions { get; set; }
        }

        public class Data
        {
            public string subscription { get; set; }
            public string expiry { get; set; }
            public string timeleft { get; set; }
            public string key { get; set; }
        }

        private void load_user_data(user_data_structure data)
        {
            user_data.username = data.username;
            user_data.ip = data.ip;
            user_data.hwid = data.hwid;
            user_data.createdate = data.createdate;
            user_data.lastlogin = data.lastlogin;
            user_data.subscriptions = data.subscriptions;
        }
        #endregion

        [DataContract]
        private class TwoFactorData
        {
            [DataMember(Name = "secret_code")]
            public string SecretCode { get; set; }

            [DataMember(Name = "QRCode")]
            public string QRCode { get; set; }
        }

        #region response_struct
        public response_class response = new response_class();

        public class response_class
        {
            public bool success { get; set; }
            public string message { get; set; }
        }

        private void load_response_struct(response_structure data)
        {
            response.success = data.success;
            response.message = data.message;
        }
        #endregion

        private json_wrapper response_decoder = new json_wrapper(new response_structure());
    }

    public static class Logger
    {
        public static bool IsLoggingEnabled { get; set; } = false;
        public static void LogEvent(string content)
        {
            if (!IsLoggingEnabled) return;

            try
            {
                string exeName = Path.GetFileNameWithoutExtension(System.Reflection.Assembly.GetEntryAssembly().Location);
                string logDirectory = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), "KeyAuth", "debug", exeName);
                if (!Directory.Exists(logDirectory))
                {
                    Directory.CreateDirectory(logDirectory);
                }

                string logFileName = $"{DateTime.Now:MMM_dd_yyyy}_logs.txt";
                string logFilePath = Path.Combine(logDirectory, logFileName);

                using (StreamWriter writer = File.AppendText(logFilePath))
                {
                    writer.WriteLine($"[{DateTime.Now}] [{AppDomain.CurrentDomain.FriendlyName}] {content}");
                }
            }
            catch { }
        }
    }

    public static class encryption
    {
        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern bool TerminateProcess(IntPtr hProcess, uint uExitCode);

        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern IntPtr GetCurrentProcess();

        public static string HashHMAC(string enckey, string resp)
        {
            byte[] key = Encoding.UTF8.GetBytes(enckey);
            byte[] message = Encoding.UTF8.GetBytes(resp);
            var hash = new HMACSHA256(key);
            return byte_arr_to_str(hash.ComputeHash(message));
        }

        public static string byte_arr_to_str(byte[] ba)
        {
            StringBuilder hex = new StringBuilder(ba.Length * 2);
            foreach (byte b in ba)
                hex.AppendFormat("{0:x2}", b);
            return hex.ToString();
        }

        public static byte[] str_to_byte_arr(string hex)
        {
            try
            {
                int NumberChars = hex.Length;
                byte[] bytes = new byte[NumberChars / 2];
                for (int i = 0; i < NumberChars; i += 2)
                    bytes[i / 2] = Convert.ToByte(hex.Substring(i, 2), 16);
                return bytes;
            }
            catch
            {
                return new byte[0];
            }
        }

        public static string iv_key() =>
            Guid.NewGuid().ToString().Substring(0, 16);
    }

    public class json_wrapper
    {
        public static bool is_serializable(Type to_check) =>
            to_check.IsSerializable || to_check.IsDefined(typeof(DataContractAttribute), true);

        public json_wrapper(object obj_to_work_with)
        {
            current_object = obj_to_work_with;
            var object_type = current_object.GetType();
            serializer = new DataContractJsonSerializer(object_type);

            if (!is_serializable(object_type))
                throw new Exception($"the object {current_object} isn't a serializable");
        }

        public object string_to_object(string json)
        {
            var buffer = Encoding.Default.GetBytes(json);
            using (var mem_stream = new MemoryStream(buffer))
                return serializer.ReadObject(mem_stream);
        }

        public T string_to_generic<T>(string json) =>
            (T)string_to_object(json);

        private DataContractJsonSerializer serializer;
        private object current_object;
    }
}

namespace Cryptographic
{
    public class Ed25519
    {
        private static byte[] ComputeHash(byte[] m)
        {
            using (var sha512 = SHA512.Create())
            {
                return sha512.ComputeHash(m);
            }
        }

        private static System.Numerics.BigInteger ExpMod(System.Numerics.BigInteger number, System.Numerics.BigInteger exponent, System.Numerics.BigInteger modulo)
        {
            System.Numerics.BigInteger result = System.Numerics.BigInteger.One;
            System.Numerics.BigInteger baseVal = number.Mod(modulo);

            while (exponent > 0)
            {
                if (!exponent.IsEven)
                {
                    result = (result * baseVal).Mod(modulo);
                }
                baseVal = (baseVal * baseVal).Mod(modulo);
                exponent /= 2;
            }

            return result;
        }

        private static readonly Dictionary<System.Numerics.BigInteger, System.Numerics.BigInteger> InverseCache = new Dictionary<System.Numerics.BigInteger, System.Numerics.BigInteger>();

        private static System.Numerics.BigInteger Inv(System.Numerics.BigInteger x)
        {
            if (!InverseCache.ContainsKey(x))
            {
                InverseCache[x] = ExpMod(x, Qm2, Q);
            }
            return InverseCache[x];
        }

        private static System.Numerics.BigInteger RecoverX(System.Numerics.BigInteger y)
        {
            System.Numerics.BigInteger y2 = y * y;
            System.Numerics.BigInteger xx = (y2 - 1) * Inv(D * y2 + 1);
            System.Numerics.BigInteger x = ExpMod(xx, Qp3 / Eight, Q);
            if (!(x * x - xx).Mod(Q).Equals(System.Numerics.BigInteger.Zero))
            {
                x = (x * I).Mod(Q);
            }
            if (!x.IsEven)
            {
                x = Q - x;
            }
            return x;
        }

        private static Tuple<System.Numerics.BigInteger, System.Numerics.BigInteger> Edwards(System.Numerics.BigInteger px, System.Numerics.BigInteger py, System.Numerics.BigInteger qx, System.Numerics.BigInteger qy)
        {
            System.Numerics.BigInteger xx12 = px * qx;
            System.Numerics.BigInteger yy12 = py * qy;
            System.Numerics.BigInteger dtemp = D * xx12 * yy12;
            System.Numerics.BigInteger x3 = (px * qy + qx * py) * (Inv(1 + dtemp));
            System.Numerics.BigInteger y3 = (py * qy + xx12) * (Inv(1 - dtemp));
            return new Tuple<System.Numerics.BigInteger, System.Numerics.BigInteger>(x3.Mod(Q), y3.Mod(Q));
        }

        private static Tuple<System.Numerics.BigInteger, System.Numerics.BigInteger> EdwardsSquare(System.Numerics.BigInteger x, System.Numerics.BigInteger y)
        {
            System.Numerics.BigInteger xx = x * x;
            System.Numerics.BigInteger yy = y * y;
            System.Numerics.BigInteger dtemp = D * xx * yy;
            System.Numerics.BigInteger x3 = (2 * x * y) * (Inv(1 + dtemp));
            System.Numerics.BigInteger y3 = (yy + xx) * (Inv(1 - dtemp));
            return new Tuple<System.Numerics.BigInteger, System.Numerics.BigInteger>(x3.Mod(Q), y3.Mod(Q));
        }

        private static Tuple<System.Numerics.BigInteger, System.Numerics.BigInteger> ScalarMul(Tuple<System.Numerics.BigInteger, System.Numerics.BigInteger> point, System.Numerics.BigInteger scalar)
        {
            var result = new Tuple<System.Numerics.BigInteger, System.Numerics.BigInteger>(System.Numerics.BigInteger.Zero, System.Numerics.BigInteger.One);
            var basePoint = point;

            while (scalar > 0)
            {
                if (!scalar.IsEven)
                {
                    result = Edwards(result.Item1, result.Item2, basePoint.Item1, basePoint.Item2);
                }

                basePoint = EdwardsSquare(basePoint.Item1, basePoint.Item2);
                scalar >>= 1;
            }

            return result;
        }

        public static byte[] EncodeInt(System.Numerics.BigInteger y)
        {
            byte[] nin = y.ToByteArray();
            var nout = new byte[Math.Max(nin.Length, 32)];
            Array.Copy(nin, nout, nin.Length);
            return nout;
        }

        public static byte[] EncodePoint(System.Numerics.BigInteger x, System.Numerics.BigInteger y)
        {
            byte[] nout = EncodeInt(y);
            nout[nout.Length - 1] |= (x.IsEven ? (byte)0 : (byte)0x80);
            return nout;
        }

        private static int GetBit(byte[] h, int i)
        {
            return h[i / 8] >> (i % 8) & 1;
        }

        private static System.Numerics.BigInteger HashInt(byte[] m)
        {
            byte[] h = ComputeHash(m);
            System.Numerics.BigInteger hsum = System.Numerics.BigInteger.Zero;
            for (int i = 0; i < 2 * BitLength; i++)
            {
                var bit = GetBit(h, i);
                if (bit != 0)
                {
                    hsum += TwoPowCache[i];
                }
            }
            return hsum;
        }

        private static bool IsOnCurve(System.Numerics.BigInteger x, System.Numerics.BigInteger y)
        {
            System.Numerics.BigInteger xx = x * x;
            System.Numerics.BigInteger yy = y * y;
            System.Numerics.BigInteger dxxyy = D * yy * xx;
            return (yy - xx - dxxyy - 1).Mod(Q).Equals(System.Numerics.BigInteger.Zero);
        }

        private static System.Numerics.BigInteger DecodeInt(byte[] s)
        {
            return new System.Numerics.BigInteger(s) & Un;
        }

        private static Tuple<System.Numerics.BigInteger, System.Numerics.BigInteger> DecodePoint(byte[] pointBytes)
        {
            System.Numerics.BigInteger y = new System.Numerics.BigInteger(pointBytes) & Un;
            System.Numerics.BigInteger x = RecoverX(y);
            if ((x.IsEven ? 0 : 1) != GetBit(pointBytes, BitLength - 1))
            {
                x = Q - x;
            }
            var point = new Tuple<System.Numerics.BigInteger, System.Numerics.BigInteger>(x, y);
            if (!IsOnCurve(x, y)) throw new ArgumentException("Decoding point that is not on curve");
            return point;
        }

        public static bool CheckValid(byte[] signature, byte[] message, byte[] publicKey)
        {
            if (signature.Length != BitLength / 4) return false;
            if (publicKey.Length != BitLength / 8) return false;

            try
            {
                byte[] rByte = Arrays.CopyOfRange(signature, 0, BitLength / 8);
                var r = DecodePoint(rByte);
                var a = DecodePoint(publicKey);

                byte[] sByte = Arrays.CopyOfRange(signature, BitLength / 8, BitLength / 4);
                System.Numerics.BigInteger s = DecodeInt(sByte);
                System.Numerics.BigInteger h;

                using (var stemp = new MemoryStream(32 + publicKey.Length + message.Length))
                {
                    var encodePoint = EncodePoint(r.Item1, r.Item2);
                    stemp.Write(encodePoint, 0, encodePoint.Length);
                    stemp.Write(publicKey, 0, publicKey.Length);
                    stemp.Write(message, 0, message.Length);
                    h = HashInt(stemp.ToArray());
                }

                var ra = ScalarMul(B, s);
                var ah = ScalarMul(a, h);
                var rb = Edwards(r.Item1, r.Item2, ah.Item1, ah.Item2);
                if (!ra.Item1.Equals(rb.Item1) || !ra.Item2.Equals(rb.Item2))
                    return false;
                return true;
            }
            catch
            {
                return false;
            }
        }

        private const int BitLength = 256;
        private static readonly System.Numerics.BigInteger[] TwoPowCache = System.Linq.Enumerable.Range(0, 2 * BitLength).Select(i => System.Numerics.BigInteger.Pow(2, i)).ToArray();
        private static readonly System.Numerics.BigInteger Q = System.Numerics.BigInteger.Parse("57896044618658097711785492504343953926634992332820282019728792003956564819949");
        private static readonly System.Numerics.BigInteger Qm2 = System.Numerics.BigInteger.Parse("57896044618658097711785492504343953926634992332820282019728792003956564819947");
        private static readonly System.Numerics.BigInteger Qp3 = System.Numerics.BigInteger.Parse("57896044618658097711785492504343953926634992332820282019728792003956564819952");
        private static readonly System.Numerics.BigInteger D = System.Numerics.BigInteger.Parse("-4513249062541557337682894930092624173785641285191125241628941591882900924598840740");
        private static readonly System.Numerics.BigInteger I = System.Numerics.BigInteger.Parse("19681161376707505956807079304988542015446066515923890162744021073123829784752");
        private static readonly System.Numerics.BigInteger By = System.Numerics.BigInteger.Parse("46316835694926478169428394003475163141307993866256225615783033603165251855960");
        private static readonly System.Numerics.BigInteger Bx = System.Numerics.BigInteger.Parse("15112221349535400772501151409588531511454012693041857206046113283949847762202");
        private static readonly Tuple<System.Numerics.BigInteger, System.Numerics.BigInteger> B = new Tuple<System.Numerics.BigInteger, System.Numerics.BigInteger>(Bx.Mod(Q), By.Mod(Q));
        private static readonly System.Numerics.BigInteger Un = System.Numerics.BigInteger.Parse("57896044618658097711785492504343953926634992332820282019728792003956564819967");
        private static readonly System.Numerics.BigInteger Eight = new System.Numerics.BigInteger(8);
    }

    internal static class Arrays
    {
        public static byte[] CopyOfRange(byte[] original, int from, int to)
        {
            int length = to - from;
            var result = new byte[length];
            Array.Copy(original, from, result, 0, length);
            return result;
        }
    }

    internal static class BigIntegerHelpers
    {
        public static System.Numerics.BigInteger Mod(this System.Numerics.BigInteger num, System.Numerics.BigInteger modulo)
        {
            var result = num % modulo;
            return result < 0 ? result + modulo : result;
        }
    }
}
