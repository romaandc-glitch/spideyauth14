using System;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace SpideyAuthSDK
{
    public class SpideyAuth
    {
        private readonly string _applicationId;
        private readonly string _applicationSecret;
        private readonly string _baseUrl;
        private readonly HttpClient _httpClient;

        public SpideyUser? CurrentUser { get; private set; }
        public SpideyLicense? CurrentLicense { get; private set; }

        public SpideyAuth(string applicationId, string applicationSecret, string baseUrl = "http://localhost:3000")
        {
            _applicationId = applicationId ?? throw new ArgumentNullException(nameof(applicationId));
            _applicationSecret = applicationSecret ?? throw new ArgumentNullException(nameof(applicationSecret));
            _baseUrl = baseUrl.TrimEnd('/');
            _httpClient = new HttpClient();
            _httpClient.DefaultRequestHeaders.Add("x-application-id", _applicationId);
            _httpClient.DefaultRequestHeaders.Add("x-application-secret", _applicationSecret);
        }

        public async Task<SpideyResponse<SpideyUser>> LoginAsync(string username, string password, string? hwid = null)
        {
            var payload = new
            {
                applicationId = _applicationId,
                applicationSecret = _applicationSecret,
                username,
                password,
                hwid = hwid ?? Environment.MachineName
            };

            return await PostAsync<SpideyUser>("/api/user/login", payload, (data) =>
            {
                CurrentUser = data;
            });
        }

        public async Task<SpideyResponse<SpideyUser>> RegisterAsync(string username, string password, string? email = null, string? licenseKey = null)
        {
            var payload = new
            {
                applicationId = _applicationId,
                applicationSecret = _applicationSecret,
                username,
                password,
                email,
                licenseKey
            };

            return await PostAsync<SpideyUser>("/api/user/register", payload, (data) =>
            {
                CurrentUser = data;
            });
        }

        public async Task<SpideyResponse<SpideyLicense>> ActivateLicenseAsync(string licenseKey, string? username = null, string? hwid = null)
        {
            var payload = new
            {
                applicationId = _applicationId,
                applicationSecret = _applicationSecret,
                licenseKey,
                username = username ?? CurrentUser?.Username,
                hwid = hwid ?? Environment.MachineName
            };

            return await PostAsync<SpideyLicense>("/api/license/activate", payload, (data) =>
            {
                CurrentLicense = data;
            });
        }

        public async Task<SpideyResponse<SpideyLicenseValidation>> ValidateLicenseAsync(string licenseKey)
        {
            var payload = new
            {
                applicationId = _applicationId,
                applicationSecret = _applicationSecret,
                licenseKey
            };

            return await PostAsync<SpideyLicenseValidation>("/api/license/validate", payload);
        }

        public void Logout()
        {
            CurrentUser = null;
            CurrentLicense = null;
        }

        private async Task<SpideyResponse<T>> PostAsync<T>(string endpoint, object payload, Action<T>? onSuccess = null)
        {
            try
            {
                var json = JsonSerializer.Serialize(payload);
                var content = new StringContent(json, Encoding.UTF8, "application/json");
                var response = await _httpClient.PostAsync($"{_baseUrl}{endpoint}", content);
                var responseBody = await response.Content.ReadAsStringAsync();

                using var doc = JsonDocument.Parse(responseBody);
                var root = doc.RootElement;
                bool isSuccess = root.GetProperty("success").GetBoolean();

                if (isSuccess)
                {
                    T data = default!;
                    if (root.TryGetProperty("user", out var userProp))
                    {
                        data = JsonSerializer.Deserialize<T>(userProp.GetRawText())!;
                    }
                    else if (root.TryGetProperty("license", out var licProp))
                    {
                        data = JsonSerializer.Deserialize<T>(licProp.GetRawText())!;
                    }

                    onSuccess?.Invoke(data);
                    return new SpideyResponse<T> { Success = true, Data = data, Message = "Success" };
                }
                else
                {
                    string code = "UNKNOWN_ERROR";
                    string message = "An error occurred";
                    if (root.TryGetProperty("error", out var errProp))
                    {
                        code = errProp.GetProperty("code").GetString() ?? code;
                        message = errProp.GetProperty("message").GetString() ?? message;
                    }
                    return new SpideyResponse<T> { Success = false, ErrorCode = code, ErrorMessage = message };
                }
            }
            catch (Exception ex)
            {
                return new SpideyResponse<T> { Success = false, ErrorCode = "CLIENT_EXCEPTION", ErrorMessage = ex.Message };
            }
        }
    }
}
