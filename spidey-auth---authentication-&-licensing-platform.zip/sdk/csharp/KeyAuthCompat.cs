using System;
using System.Security.Cryptography;
using System.Collections.Specialized;
using System.Text;
using System.Net;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Json;
using System.Diagnostics;
using System.Security.Principal;
using System.Collections.Generic;
using System.Security.Cryptography.X509Certificates;
using System.Net.Security;
using System.Threading;

namespace KeyAuth
{
    /// <summary>
    /// Spidey Auth - KeyAuth v1.3 Compatible C# Client API
    /// Drop-in compatible with applications migrating from KeyAuth.
    /// Point this to your Spidey Auth server endpoint (e.g. https://your-domain/api/1.3/)
    /// </summary>
    public class api
    {
        public string name, ownerid, secret, version, path, seed, apiUrl;

        /// <summary>
        /// Global error handler callback. Defaults to Console.WriteLine.
        /// </summary>
        public static Action<string> OnError = (msg) => Console.WriteLine("[SpideyAuth] " + msg);

        /// <summary>
        /// KeyAuth standard constructor: api(name, ownerid, secret, version, path, url)
        /// Drop-in compatible with existing KeyAuth projects.
        /// </summary>
        public api(string name, string ownerid, string secret, string version, string path = null, string url = "http://localhost:3000/api/1.3/")
        {
            this.name = name;
            this.ownerid = ownerid;
            this.secret = secret;
            this.version = version;
            this.path = path;
            this.apiUrl = (url ?? "http://localhost:3000/api/1.3/").TrimEnd('/') + "/";
        }

        /// <summary>
        /// Simplified constructor without secret: api(name, ownerid, version, path, url)
        /// </summary>
        public api(string name, string ownerid, string version, string path = null, string url = "http://localhost:3000/api/1.3/")
        {
            this.name = name;
            this.ownerid = ownerid;
            this.secret = "";
            this.version = version;
            this.path = path;
            this.apiUrl = (url ?? "http://localhost:3000/api/1.3/").TrimEnd('/') + "/";
        }

        #region structures
        [DataContract]
        private class response_structure
        {
            [DataMember]
            public bool success { get; set; }

            [DataMember]
            public bool newSession { get; set; }

            [DataMember]
            public string sessionid { get; set; }

            [DataMember]
            public string contents { get; set; }

            [DataMember]
            public string response { get; set; }

            [DataMember]
            public string message { get; set; }

            [DataMember]
            public string ownerid { get; set; }

            [DataMember]
            public string download { get; set; }

            [DataMember(IsRequired = false, EmitDefaultValue = false)]
            public user_data_structure info { get; set; }

            [DataMember(IsRequired = false, EmitDefaultValue = false)]
            public app_data_structure appinfo { get; set; }

            [DataMember]
            public List<msg> messages { get; set; }

            [DataMember]
            public List<users> users { get; set; }
        }

        public class msg
        {
            public string message { get; set; }
            public string author { get; set; }
            public string timestamp { get; set; }
        }

        public class users
        {
            public string credential { get; set; }
        }

        [DataContract]
        private class user_data_structure
        {
            [DataMember]
            public string username { get; set; }

            [DataMember]
            public string ip { get; set; }

            [DataMember]
            public string hwid { get; set; }

            [DataMember]
            public string createdate { get; set; }

            [DataMember]
            public string lastlogin { get; set; }

            [DataMember]
            public List<Data> subscriptions { get; set; }
        }

        [DataContract]
        private class app_data_structure
        {
            [DataMember]
            public string numUsers { get; set; }

            [DataMember]
            public string numOnlineUsers { get; set; }

            [DataMember]
            public string numKeys { get; set; }

            [DataMember]
            public string version { get; set; }

            [DataMember]
            public string customerPanelLink { get; set; }

            [DataMember]
            public string downloadLink { get; set; }
        }
        #endregion

        private static string sessionid, enckey;
        bool initialized;

        /// <summary>
        /// Initializes the connection with Spidey Auth
        /// </summary>
        public void init()
        {
            Random random = new Random();
            int length = random.Next(5, 51);
            StringBuilder sb = new StringBuilder(length);

            for (int i = 0; i < length; i++)
            {
                char randomChar = (char)random.Next(32, 127);
                sb.Append(randomChar);
            }

            seed = sb.ToString();

            var values_to_upload = new NameValueCollection
            {
                ["type"] = "init",
                ["ver"] = version,
                ["name"] = name,
                ["ownerid"] = ownerid
            };

            var response = req(values_to_upload);

            if (response == "KeyAuth_Invalid")
            {
                error("Application not found in Spidey Auth. Check application name and Owner ID.");
                return;
            }

            var json = response_decoder.string_to_generic<response_structure>(response);
            load_response_struct(json);

            if (json.success)
            {
                sessionid = json.sessionid;
                initialized = true;
                if (json.appinfo != null)
                {
                    load_app_data(json.appinfo);
                }
            }
            else if (json.message == "invalidver")
            {
                app_data.downloadLink = json.download;
            }
        }

        public void CheckInit()
        {
            if (!initialized)
            {
                error("You must run KeyAuthApp.init(); first before calling authentication functions.");
            }
        }

        public string expirydaysleft(string Type, int subscription)
        {
            CheckInit();
            if (user_data?.subscriptions == null || user_data.subscriptions.Count <= subscription)
                return "0";

            DateTime dtDateTime = new DateTime(1970, 1, 1, 0, 0, 0, 0, DateTimeKind.Utc);
            dtDateTime = dtDateTime.AddSeconds(long.Parse(user_data.subscriptions[subscription].expiry)).ToLocalTime();
            TimeSpan difference = dtDateTime - DateTime.Now;

            switch (Type.ToLower())
            {
                case "months":
                    return Convert.ToString(difference.Days / 30);
                case "days":
                    return Convert.ToString(difference.Days);
                case "hours":
                    return Convert.ToString(difference.Hours);
            }
            return "0";
        }

        public void register(string username, string pass, string key, string email = "")
        {
            CheckInit();
            string hwid = GetHwid();

            var values_to_upload = new NameValueCollection
            {
                ["type"] = "register",
                ["username"] = username,
                ["pass"] = pass,
                ["key"] = key,
                ["email"] = email,
                ["hwid"] = hwid,
                ["sessionid"] = sessionid,
                ["name"] = name,
                ["ownerid"] = ownerid
            };

            var response = req(values_to_upload);
            var json = response_decoder.string_to_generic<response_structure>(response);

            load_response_struct(json);
            if (json.success && json.info != null)
                load_user_data(json.info);
        }

        public void login(string username, string pass, string code = null)
        {
            CheckInit();
            string hwid = GetHwid();

            var values_to_upload = new NameValueCollection
            {
                ["type"] = "login",
                ["username"] = username,
                ["pass"] = pass,
                ["hwid"] = hwid,
                ["sessionid"] = sessionid,
                ["name"] = name,
                ["ownerid"] = ownerid,
                ["code"] = code ?? string.Empty
            };

            var response = req(values_to_upload);
            var json = response_decoder.string_to_generic<response_structure>(response);

            load_response_struct(json);
            if (json.success && json.info != null)
                load_user_data(json.info);
        }

        public void license(string key, string code = null)
        {
            CheckInit();
            string hwid = GetHwid();

            var values_to_upload = new NameValueCollection
            {
                ["type"] = "license",
                ["key"] = key,
                ["hwid"] = hwid,
                ["sessionid"] = sessionid,
                ["name"] = name,
                ["ownerid"] = ownerid,
                ["code"] = code ?? string.Empty
            };

            var response = req(values_to_upload);
            var json = response_decoder.string_to_generic<response_structure>(response);

            load_response_struct(json);
            if (json.success && json.info != null)
                load_user_data(json.info);
        }

        public void upgrade(string username, string key)
        {
            CheckInit();
            var values_to_upload = new NameValueCollection
            {
                ["type"] = "upgrade",
                ["username"] = username,
                ["key"] = key,
                ["sessionid"] = sessionid,
                ["name"] = name,
                ["ownerid"] = ownerid
            };

            var response = req(values_to_upload);
            var json = response_decoder.string_to_generic<response_structure>(response);
            load_response_struct(json);
        }

        public void check()
        {
            CheckInit();
            var values_to_upload = new NameValueCollection
            {
                ["type"] = "check",
                ["sessionid"] = sessionid,
                ["name"] = name,
                ["ownerid"] = ownerid
            };

            var response = req(values_to_upload);
            var json = response_decoder.string_to_generic<response_structure>(response);
            load_response_struct(json);
        }

        public void logout()
        {
            CheckInit();
            var values_to_upload = new NameValueCollection
            {
                ["type"] = "logout",
                ["sessionid"] = sessionid,
                ["name"] = name,
                ["ownerid"] = ownerid
            };

            var response = req(values_to_upload);
            var json = response_decoder.string_to_generic<response_structure>(response);
            load_response_struct(json);
            initialized = false;
        }

        public void fetchStats()
        {
            CheckInit();
            var values_to_upload = new NameValueCollection
            {
                ["type"] = "fetchStats",
                ["sessionid"] = sessionid,
                ["name"] = name,
                ["ownerid"] = ownerid
            };

            var response = req(values_to_upload);
            var json = response_decoder.string_to_generic<response_structure>(response);
            load_response_struct(json);
            if (json.success && json.appinfo != null)
                load_app_data(json.appinfo);
        }

        public void log(string message)
        {
            CheckInit();
            var values_to_upload = new NameValueCollection
            {
                ["type"] = "log",
                ["message"] = message,
                ["sessionid"] = sessionid,
                ["name"] = name,
                ["ownerid"] = ownerid
            };

            req(values_to_upload);
        }

        public void changeUsername(string username)
        {
            CheckInit();
            var values_to_upload = new NameValueCollection
            {
                ["type"] = "changeUsername",
                ["newUsername"] = username,
                ["sessionid"] = sessionid,
                ["name"] = name,
                ["ownerid"] = ownerid
            };

            var response = req(values_to_upload);
            var json = response_decoder.string_to_generic<response_structure>(response);
            load_response_struct(json);
        }

        private static string GetHwid()
        {
            try
            {
                return WindowsIdentity.GetCurrent().User.Value;
            }
            catch
            {
                return Environment.MachineName + "_" + Environment.UserName;
            }
        }

        public static void error(string message)
        {
            OnError?.Invoke(message);
        }

        private string req(NameValueCollection post_data)
        {
            try
            {
                using (WebClient client = new WebClient())
                {
                    client.Proxy = null;
                    ServicePointManager.ServerCertificateValidationCallback = (sender, certificate, chain, sslPolicyErrors) => true;

                    var raw_response = client.UploadValues(this.apiUrl, post_data);
                    return Encoding.UTF8.GetString(raw_response);
                }
            }
            catch (WebException webex)
            {
                if (webex.Response is HttpWebResponse resp)
                {
                    if (resp.StatusCode == (HttpStatusCode)429)
                    {
                        error("You're connecting too fast. Rate limit exceeded.");
                        return "{\"success\":false,\"message\":\"Rate limit exceeded\"}";
                    }
                }
                error("Connection failure: " + webex.Message);
                return "{\"success\":false,\"message\":\"Connection failure\"}";
            }
        }

        #region app_data
        public app_data_class app_data = new app_data_class();

        public class app_data_class
        {
            public string numUsers { get; set; }
            public string numOnlineUsers { get; set; }
            public string numKeys { get; set; }
            public string version { get; set; }
            public string customerPanelLink { get; set; }
            public string downloadLink { get; set; }
        }

        private void load_app_data(app_data_structure data)
        {
            app_data.numUsers = data.numUsers;
            app_data.numOnlineUsers = data.numOnlineUsers;
            app_data.numKeys = data.numKeys;
            app_data.version = data.version;
            app_data.customerPanelLink = data.customerPanelLink;
            app_data.downloadLink = data.downloadLink;
        }
        #endregion

        #region user_data
        public user_data_class user_data = new user_data_class();

        public class user_data_class
        {
            public string username { get; set; }
            public string ip { get; set; }
            public string hwid { get; set; }
            public string createdate { get; set; }
            public string lastlogin { get; set; }
            public List<Data> subscriptions { get; set; }
        }

        public class Data
        {
            public string subscription { get; set; }
            public string expiry { get; set; }
            public string timeleft { get; set; }
            public string key { get; set; }
        }

        private void load_user_data(user_data_structure data)
        {
            user_data.username = data.username;
            user_data.ip = data.ip;
            user_data.hwid = data.hwid;
            user_data.createdate = data.createdate;
            user_data.lastlogin = data.lastlogin;
            user_data.subscriptions = data.subscriptions;
        }
        #endregion

        #region response_struct
        public response_class response = new response_class();

        public class response_class
        {
            public bool success { get; set; }
            public string message { get; set; }
        }

        private void load_response_struct(response_structure data)
        {
            response.success = data.success;
            response.message = data.message;
        }
        #endregion

        private json_wrapper response_decoder = new json_wrapper(new response_structure());
    }

    public class json_wrapper
    {
        public json_wrapper(object obj_to_work_with)
        {
            current_object = obj_to_work_with;
            var object_type = current_object.GetType();
            serializer = new DataContractJsonSerializer(object_type);
        }

        public object string_to_object(string json)
        {
            var buffer = Encoding.UTF8.GetBytes(json);
            using (var mem_stream = new MemoryStream(buffer))
                return serializer.ReadObject(mem_stream);
        }

        public T string_to_generic<T>(string json) =>
            (T)string_to_object(json);

        private DataContractJsonSerializer serializer;
        private object current_object;
    }
}

namespace SpideyAuth
{
    // Alias to allow using SpideyAuth namespace seamlessly
    public class api : KeyAuth.api
    {
        public api(string name, string ownerid, string version, string path = null, string url = "http://localhost:3000/api/1.3/")
            : base(name, ownerid, version, path, url)
        {
        }
    }
}
