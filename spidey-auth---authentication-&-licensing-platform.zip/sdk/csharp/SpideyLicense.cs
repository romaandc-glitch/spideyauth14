using System;
using System.Text.Json.Serialization;

namespace SpideyAuthSDK
{
    public class SpideyLicense
    {
        [JsonPropertyName("status")]
        public string Status { get; set; } = string.Empty;

        [JsonPropertyName("subscriptionType")]
        public string SubscriptionType { get; set; } = string.Empty;

        [JsonPropertyName("activations")]
        public int Activations { get; set; }

        [JsonPropertyName("maxActivations")]
        public int MaxActivations { get; set; }

        [JsonPropertyName("expires")]
        public DateTime? Expires { get; set; }

        [JsonPropertyName("activatedAt")]
        public DateTime? ActivatedAt { get; set; }
    }

    public class SpideyLicenseValidation
    {
        [JsonPropertyName("key")]
        public string Key { get; set; } = string.Empty;

        [JsonPropertyName("status")]
        public string Status { get; set; } = string.Empty;

        [JsonPropertyName("subscriptionType")]
        public string SubscriptionType { get; set; } = string.Empty;

        [JsonPropertyName("currentActivations")]
        public int CurrentActivations { get; set; }

        [JsonPropertyName("maxActivations")]
        public int MaxActivations { get; set; }

        [JsonPropertyName("expires")]
        public DateTime? Expires { get; set; }
    }
}
