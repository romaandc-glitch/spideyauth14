using System;
using System.Windows.Forms;
using KeyAuth;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        // ==========================================
        // 1. INITIALIZE KEYAUTH CLIENT
        // Point url to your Spidey Auth server endpoint
        // ==========================================
        public static api KeyAuthApp = new api(
            name: "Apex Velocity",                         // Your Application Name from Spidey Auth Dashboard
            ownerid: "SPY-OWNER-82HD72",                   // Your Owner ID from Spidey Auth Dashboard
            version: "1.0",                                // Application Version
            path: null,
            url: "https://ais-dev-utocohre7wyz4b46tgqoox-767018296245.asia-east1.run.app/api/1.3/" // Spidey Auth Gateway
        );

        public Form1()
        {
            InitializeComponent();

            try
            {
                KeyAuthApp.init(); // MUST run before ANY login
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Init Failed");
                Environment.Exit(0);
            }
        }

        // ==========================================
        // 2. LOGIN BUTTON CLICK EVENT
        // ==========================================
        private void LoginBtn_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(User.Text) || string.IsNullOrWhiteSpace(Pass.Text))
            {
                MessageBox.Show("Username or Password empty");
                return;
            }

            KeyAuthApp.login(User.Text, Pass.Text);

            if (KeyAuthApp.response.success)
            {
                // Authenticated successfully! Proceed to main window
                Form2 f2 = new Form2();
                f2.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show(KeyAuthApp.response.message, "Login Failed");
            }
        }

        // ==========================================
        // 3. LICENSE (KEY-ONLY) BUTTON CLICK EVENT
        // ==========================================
        private void LicenseBtn_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(LicenseKey.Text))
            {
                MessageBox.Show("License key empty");
                return;
            }

            KeyAuthApp.license(LicenseKey.Text);

            if (KeyAuthApp.response.success)
            {
                Form2 f2 = new Form2();
                f2.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show(KeyAuthApp.response.message, "License Error");
            }
        }
    }
}
