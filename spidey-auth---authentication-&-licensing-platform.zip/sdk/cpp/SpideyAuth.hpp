#pragma once

#include <string>
#include <functional>
#include <memory>

namespace SpideyAuth {

struct User {
    std::string id;
    std::string username;
    std::string email;
    std::string status;
    std::string subscriptionRole;
    std::string expiresAt;
};

struct License {
    std::string status;
    std::string subscriptionType;
    int activations;
    int maxActivations;
    std::string expires;
};

struct Response {
    bool success;
    std::string message;
    std::string errorCode;
    std::string errorMessage;
};

class Client {
public:
    Client(const std::string& appId, const std::string& appSecret, const std::string& baseUrl = "http://localhost:3000");
    ~Client();

    Response Login(const std::string& username, const std::string& password, User& outUser);
    Response Register(const std::string& username, const std::string& password, const std::string& email, const std::string& licenseKey, User& outUser);
    Response ActivateLicense(const std::string& licenseKey, License& outLicense);
    Response ValidateLicense(const std::string& licenseKey, bool& isValid);
    void Logout();

    const User* GetCurrentUser() const;

private:
    std::string m_appId;
    std::string m_appSecret;
    std::string m_baseUrl;
    std::unique_ptr<User> m_currentUser;

    std::string HttpPost(const std::string& endpoint, const std::string& jsonPayload, long& statusCode);
};

} // namespace SpideyAuth
