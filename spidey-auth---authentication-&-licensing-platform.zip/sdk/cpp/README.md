# Spidey Auth C++ SDK

High performance C++ client for native gaming, anti-cheat friendly desktop apps, and client utilities.

## Requirements
- C++17 or higher
- `libcurl` or `CPR` (or standard WinINet for Windows)

## Quick Start

```cpp
#include "SpideyAuth.hpp"
#include <iostream>

int main() {
    SpideyAuth::Client auth("APP-92JD83", "spy_sec_your_secret", "https://api.spideyauth.dev");

    SpideyAuth::User user;
    auto loginRes = auth.Login("player123", "secretPassword!", user);

    if (loginRes.success) {
        std::cout << "Successfully authenticated: " << user.username << std::endl;
        std::cout << "Role: " << user.subscriptionRole << std::endl;
    } else {
        std::cerr << "Login error: " << loginRes.errorMessage << std::endl;
    }

    SpideyAuth::License license;
    auto licRes = auth.ActivateLicense("SPIDEY-XXXX-XXXX-XXXX-XXXX", license);
    if (licRes.success) {
        std::cout << "License active! Expires: " << license.expires << std::endl;
    }

    return 0;
}
```
