#pragma once

#include <string>
#include <vector>
#include <memory>

namespace KeyAuth {

struct AppData {
    std::string numUsers;
    std::string numKeys;
    std::string version;
    std::string customerPanelLink;
    std::string downloadLink;
};

struct UserData {
    std::string username;
    std::string ip;
    std::string hwid;
    std::string createdate;
    std::string lastlogin;
    std::vector<std::string> subscriptions;
};

struct Response {
    bool success;
    std::string message;
};

class api {
public:
    std::string name;
    std::string ownerid;
    std::string version;
    std::string apiUrl;
    std::string sessionId;
    bool initialized;

    AppData app_data;
    UserData user_data;
    Response response;

    api(const std::string& name, const std::string& ownerid, const std::string& secret, const std::string& version, const std::string& url = "http://localhost:3000/api/1.3/");
    api(const std::string& name, const std::string& ownerid, const std::string& version, const std::string& url = "http://localhost:3000/api/1.3/");

    bool init();
    bool login(const std::string& username, const std::string& pass, const std::string& hwid = "cpp-client");
    bool registerUser(const std::string& username, const std::string& pass, const std::string& key = "", const std::string& email = "", const std::string& hwid = "cpp-client");
    bool license(const std::string& key, const std::string& hwid = "cpp-client");
    bool check();
    void log(const std::string& message);
    void logout();
};

} // namespace KeyAuth
