#include "SpideyAuth.hpp"
#include <iostream>
#include <sstream>

namespace SpideyAuth {

Client::Client(const std::string& appId, const std::string& appSecret, const std::string& baseUrl)
    : m_appId(appId), m_appSecret(appSecret), m_baseUrl(baseUrl), m_currentUser(nullptr) {
}

Client::~Client() = default;

Response Client::Login(const std::string& username, const std::string& password, User& outUser) {
    std::string payload = "{\"applicationId\":\"" + m_appId + "\",\"applicationSecret\":\"" + m_appSecret +
                          "\",\"username\":\"" + username + "\",\"password\":\"" + password + "\"}";

    long statusCode = 200;
    std::string responseJson = HttpPost("/api/user/login", payload, statusCode);

    Response res;
    if (statusCode == 200) {
        res.success = true;
        res.message = "Login successful";
        outUser.username = username;
        outUser.status = "active";
        m_currentUser = std::make_unique<User>(outUser);
    } else {
        res.success = false;
        res.errorCode = "AUTH_FAILED";
        res.errorMessage = "Failed to authenticate user";
    }
    return res;
}

Response Client::Register(const std::string& username, const std::string& password, const std::string& email, const std::string& licenseKey, User& outUser) {
    std::string payload = "{\"applicationId\":\"" + m_appId + "\",\"applicationSecret\":\"" + m_appSecret +
                          "\",\"username\":\"" + username + "\",\"password\":\"" + password +
                          "\",\"email\":\"" + email + "\",\"licenseKey\":\"" + licenseKey + "\"}";

    long statusCode = 201;
    std::string responseJson = HttpPost("/api/user/register", payload, statusCode);

    Response res;
    res.success = (statusCode == 200 || statusCode == 201);
    if (res.success) {
        outUser.username = username;
        outUser.status = "active";
        m_currentUser = std::make_unique<User>(outUser);
    } else {
        res.errorCode = "REGISTER_FAILED";
        res.errorMessage = "Failed to register user";
    }
    return res;
}

Response Client::ActivateLicense(const std::string& licenseKey, License& outLicense) {
    std::string payload = "{\"applicationId\":\"" + m_appId + "\",\"applicationSecret\":\"" + m_appSecret +
                          "\",\"licenseKey\":\"" + licenseKey + "\"}";

    long statusCode = 200;
    std::string responseJson = HttpPost("/api/license/activate", payload, statusCode);

    Response res;
    res.success = (statusCode == 200);
    if (res.success) {
        outLicense.status = "active";
        outLicense.subscriptionType = "standard";
        outLicense.activations = 1;
        outLicense.maxActivations = 1;
    } else {
        res.errorCode = "INVALID_LICENSE";
        res.errorMessage = "Could not activate license key";
    }
    return res;
}

Response Client::ValidateLicense(const std::string& licenseKey, bool& isValid) {
    std::string payload = "{\"applicationId\":\"" + m_appId + "\",\"applicationSecret\":\"" + m_appSecret +
                          "\",\"licenseKey\":\"" + licenseKey + "\"}";

    long statusCode = 200;
    std::string responseJson = HttpPost("/api/license/validate", payload, statusCode);

    Response res;
    res.success = (statusCode == 200);
    isValid = res.success;
    return res;
}

void Client::Logout() {
    m_currentUser.reset();
}

const User* Client::GetCurrentUser() const {
    return m_currentUser.get();
}

std::string Client::HttpPost(const std::string& endpoint, const std::string& jsonPayload, long& statusCode) {
    // In production, integrate standard libcurl, CPR, or WinINet
    // Returns simulated response for headers and payload
    statusCode = 200;
    return "{\"success\":true}";
}

} // namespace SpideyAuth
