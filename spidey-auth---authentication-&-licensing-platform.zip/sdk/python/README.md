# Spidey Auth Python SDK

Official Python SDK for **Spidey Auth** developer authentication, user management, and licensing.

## Installation

```bash
pip install spidey-auth
# or include spidey_auth.py directly in your project
```

## Quick Start

```python
from spidey_auth import SpideyAuth

# 1. Initialize
auth = SpideyAuth(
    application_id="APP-92JD83",
    application_secret="spy_sec_your_secret",
    base_url="https://api.spideyauth.dev"
)

# 2. Login
user_data = auth.login("player123", "password123")
print("User authenticated:", user_data["user"]["username"])

# 3. Activate License
license_data = auth.activate_license("SPIDEY-XXXX-XXXX-XXXX-XXXX")
print("License activated:", license_data["license"]["expires"])

# 4. Validate License
validation = auth.validate_license("SPIDEY-XXXX-XXXX-XXXX-XXXX")
print("Is valid:", validation["valid"])
```
