"""
KeyAuth Python Drop-in Client Module for Spidey Auth
Drop-in replacement for KeyAuth v1.x (v1.0 - v1.4)
Point to your Spidey Auth server endpoint: /api/1.3/
"""

from keyauth_compat import KeyAuth, api, UserData, AppData, ResponseData

__all__ = ["KeyAuth", "api", "UserData", "AppData", "ResponseData"]
