"""
Spidey Auth - KeyAuth v1.3 Compatible Python Client
Drop-in replacement for KeyAuth in Python applications and scripts.
Connect directly to Spidey Auth at /api/1.3/
"""

import os
import platform
import json
import urllib.request
import urllib.parse
import urllib.error
import time
from typing import Optional, Dict, Any, List

class KeyAuth:
    """
    KeyAuth v1.3 Drop-in Compatibility Client.
    Accepts both KeyAuth standard signatures:
    api(name, ownerid, secret, version, url)
    or api(name, ownerid, version, url)
    """
    def __init__(self, name: str, ownerid: str, *args, **kwargs):
        self.name = name
        self.ownerid = ownerid
        
        # Parse args flexibly for drop-in compatibility
        # If 4 positional args: (name, ownerid, secret, version)
        # If 3 positional args: (name, ownerid, version)
        if len(args) >= 2:
            self.secret = str(args[0])
            self.version = str(args[1])
            self.url = (args[2] if len(args) > 2 else kwargs.get("url", "http://localhost:3000/api/1.3/")).rstrip("/") + "/"
        elif len(args) == 1:
            self.secret = kwargs.get("secret", "")
            self.version = str(args[0])
            self.url = kwargs.get("url", "http://localhost:3000/api/1.3/").rstrip("/") + "/"
        else:
            self.secret = kwargs.get("secret", "")
            self.version = kwargs.get("version", kwargs.get("ver", "1.0"))
            self.url = kwargs.get("url", "http://localhost:3000/api/1.3/").rstrip("/") + "/"

        self.sessionid: Optional[str] = None
        self.initialized: bool = False

        self.user_data = UserData()
        self.app_data = AppData()
        self.response = ResponseData()

# Standard KeyAuth class alias
api = KeyAuth

    def _get_hwid(self) -> str:
        try:
            return platform.node() + "_" + (os.getenv("USERNAME") or os.getenv("USER") or "client")
        except Exception:
            return "HWID-PYTHON-CLIENT"

    def _req(self, data: Dict[str, Any]) -> Dict[str, Any]:
        encoded_data = urllib.parse.urlencode(data).encode("utf-8")
        req = urllib.request.Request(
            self.url,
            data=encoded_data,
            headers={
                "Content-Type": "application/x-www-form-urlencoded",
                "User-Agent": "KeyAuth-Python-Compat/1.3"
            },
            method="POST"
        )
        try:
            with urllib.request.urlopen(req) as resp:
                raw = resp.read().decode("utf-8")
                return json.loads(raw)
        except urllib.error.HTTPError as e:
            raw = e.read().decode("utf-8")
            try:
                return json.loads(raw)
            except Exception:
                return {"success": False, "message": f"HTTP {e.code}"}
        except Exception as e:
            return {"success": False, "message": str(e)}

    def init(self) -> None:
        payload = {
            "type": "init",
            "ver": self.version,
            "name": self.name,
            "ownerid": self.ownerid
        }
        res = self._req(payload)
        self.response.success = res.get("success", False)
        self.response.message = res.get("message", "")

        if res.get("success"):
            self.sessionid = res.get("sessionid")
            self.initialized = True
            appinfo = res.get("appinfo", {})
            self.app_data.numUsers = appinfo.get("numUsers", "0")
            self.app_data.numKeys = appinfo.get("numKeys", "0")
            self.app_data.version = appinfo.get("version", self.version)
            self.app_data.customerPanelLink = appinfo.get("customerPanelLink", "")
            self.app_data.downloadLink = appinfo.get("downloadLink", "")

    def check_init(self) -> None:
        if not self.initialized:
            raise RuntimeError("You must call KeyAuth.init() before invoking auth actions.")

    def login(self, username: str, password: str, hwid: Optional[str] = None) -> bool:
        self.check_init()
        payload = {
            "type": "login",
            "username": username,
            "pass": password,
            "hwid": hwid or self._get_hwid(),
            "sessionid": self.sessionid,
            "name": self.name,
            "ownerid": self.ownerid
        }
        res = self._req(payload)
        self.response.success = res.get("success", False)
        self.response.message = res.get("message", "")

        if res.get("success") and "info" in res:
            info = res["info"]
            self.user_data.username = info.get("username", username)
            self.user_data.ip = info.get("ip", "")
            self.user_data.hwid = info.get("hwid", "")
            self.user_data.createdate = info.get("createdate", "")
            self.user_data.lastlogin = info.get("lastlogin", "")
            self.user_data.subscriptions = info.get("subscriptions", [])
        return self.response.success

    def register(self, username: str, password: str, key: str = "", email: str = "", hwid: Optional[str] = None) -> bool:
        self.check_init()
        payload = {
            "type": "register",
            "username": username,
            "pass": password,
            "key": key,
            "email": email,
            "hwid": hwid or self._get_hwid(),
            "sessionid": self.sessionid,
            "name": self.name,
            "ownerid": self.ownerid
        }
        res = self._req(payload)
        self.response.success = res.get("success", False)
        self.response.message = res.get("message", "")

        if res.get("success") and "info" in res:
            info = res["info"]
            self.user_data.username = info.get("username", username)
            self.user_data.subscriptions = info.get("subscriptions", [])
        return self.response.success

    def license(self, key: str, hwid: Optional[str] = None) -> bool:
        self.check_init()
        payload = {
            "type": "license",
            "key": key,
            "hwid": hwid or self._get_hwid(),
            "sessionid": self.sessionid,
            "name": self.name,
            "ownerid": self.ownerid
        }
        res = self._req(payload)
        self.response.success = res.get("success", False)
        self.response.message = res.get("message", "")

        if res.get("success") and "info" in res:
            info = res["info"]
            self.user_data.username = info.get("username", "")
            self.user_data.subscriptions = info.get("subscriptions", [])
        return self.response.success

    def check(self) -> bool:
        self.check_init()
        res = self._req({
            "type": "check",
            "sessionid": self.sessionid,
            "name": self.name,
            "ownerid": self.ownerid
        })
        self.response.success = res.get("success", False)
        self.response.message = res.get("message", "")
        return self.response.success

    def upgrade(self, username: str, key: str) -> bool:
        self.check_init()
        res = self._req({
            "type": "upgrade",
            "username": username,
            "key": key,
            "sessionid": self.sessionid,
            "name": self.name,
            "ownerid": self.ownerid
        })
        self.response.success = res.get("success", False)
        self.response.message = res.get("message", "")
        return self.response.success

    def fetch_stats(self) -> Dict[str, Any]:
        self.check_init()
        res = self._req({
            "type": "fetchStats",
            "sessionid": self.sessionid,
            "name": self.name,
            "ownerid": self.ownerid
        })
        self.response.success = res.get("success", False)
        self.response.message = res.get("message", "")
        if res.get("success") and "appinfo" in res:
            appinfo = res["appinfo"]
            self.app_data.numUsers = appinfo.get("numUsers", "0")
            self.app_data.numKeys = appinfo.get("numKeys", "0")
        return res

    def log(self, message: str) -> None:
        self.check_init()
        self._req({
            "type": "log",
            "message": message,
            "sessionid": self.sessionid,
            "name": self.name,
            "ownerid": self.ownerid
        })

    def logout(self) -> None:
        if self.initialized and self.sessionid:
            self._req({
                "type": "logout",
                "sessionid": self.sessionid,
                "name": self.name,
                "ownerid": self.ownerid
            })
            self.initialized = False
            self.sessionid = None

class UserData:
    def __init__(self):
        self.username: str = ""
        self.ip: str = ""
        self.hwid: str = ""
        self.createdate: str = ""
        self.lastlogin: str = ""
        self.subscriptions: List[Dict[str, Any]] = []

class AppData:
    def __init__(self):
        self.numUsers: str = "0"
        self.numKeys: str = "0"
        self.version: str = "1.0.0"
        self.customerPanelLink: str = ""
        self.downloadLink: str = ""

class ResponseData:
    def __init__(self):
        self.success: bool = False
        self.message: str = ""
