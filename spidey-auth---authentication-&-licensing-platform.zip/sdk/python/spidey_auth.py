"""
Spidey Auth Python SDK
Official Python client library for Spidey Auth developer authentication and licensing.
"""

import os
import platform
import json
import urllib.request
import urllib.error
from typing import Optional, Dict, Any

class SpideyAuthException(Exception):
    def __init__(self, code: str, message: str):
        super().__init__(f"[{code}] {message}")
        self.code = code
        self.message = message

# Import KeyAuth compatibility class
try:
    from keyauth_compat import KeyAuth
except ImportError:
    pass

class SpideyAuth:
    def __init__(self, application_id: str, application_secret: str, base_url: str = "http://localhost:3000"):
        self.application_id = application_id
        self.application_secret = application_secret
        self.base_url = base_url.rstrip("/")
        self.current_user: Optional[Dict[str, Any]] = None
        self.current_license: Optional[Dict[str, Any]] = None

    def _post(self, endpoint: str, payload: Dict[str, Any]) -> Dict[str, Any]:
        url = f"{self.base_url}{endpoint}"
        full_payload = {
            "applicationId": self.application_id,
            "applicationSecret": self.application_secret,
            **payload
        }

        data = json.dumps(full_payload).encode("utf-8")
        req = urllib.request.Request(
            url,
            data=data,
            headers={
                "Content-Type": "application/json",
                "x-application-id": self.application_id,
                "x-application-secret": self.application_secret,
                "User-Agent": "SpideyAuth-Python-SDK/1.0.0"
            },
            method="POST"
        )

        try:
            with urllib.request.urlopen(req) as response:
                body = response.read().decode("utf-8")
                return json.loads(body)
        except urllib.error.HTTPError as e:
            err_body = e.read().decode("utf-8")
            try:
                err_json = json.loads(err_body)
                err_info = err_json.get("error", {})
                raise SpideyAuthException(
                    code=err_info.get("code", "HTTP_ERROR"),
                    message=err_info.get("message", str(e))
                )
            except json.JSONDecodeError:
                raise SpideyAuthException(code=f"HTTP_{e.code}", message=str(e))
        except urllib.error.URLError as e:
            raise SpideyAuthException(code="NETWORK_ERROR", message=str(e.reason))

    def login(self, username: str, password: str, hwid: Optional[str] = None) -> Dict[str, Any]:
        """Authenticate an application user."""
        client_hwid = hwid or platform.node()
        result = self._post("/api/user/login", {
            "username": username,
            "password": password,
            "hwid": client_hwid
        })
        self.current_user = result.get("user")
        return result

    def register(self, username: str, password: str, email: Optional[str] = None, license_key: Optional[str] = None) -> Dict[str, Any]:
        """Register a new user inside this application."""
        result = self._post("/api/user/register", {
            "username": username,
            "password": password,
            "email": email or "",
            "licenseKey": license_key or ""
        })
        self.current_user = result.get("user")
        return result

    def activate_license(self, license_key: str, username: Optional[str] = None, hwid: Optional[str] = None) -> Dict[str, Any]:
        """Activate a Spidey Auth license key."""
        result = self._post("/api/license/activate", {
            "licenseKey": license_key,
            "username": username or (self.current_user.get("username") if self.current_user else None),
            "hwid": hwid or platform.node()
        })
        self.current_license = result.get("license")
        return result

    def validate_license(self, license_key: str) -> Dict[str, Any]:
        """Validate if a license key is currently active."""
        return self._post("/api/license/validate", {
            "licenseKey": license_key
        })

    def logout(self) -> None:
        """Clear cached session details."""
        self.current_user = None
        self.current_license = None
