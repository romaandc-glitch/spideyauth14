#!/usr/bin/env python3
"""
Spidey Auth Python Integration Example
"""

from spidey_auth import SpideyAuth, SpideyAuthException

def main():
    # Initialize SDK
    auth = SpideyAuth(
        application_id="APP-92JD83",
        application_secret="spy_sec_your_app_secret",
        base_url="http://localhost:3000"
    )

    print("Authenticating user...")
    try:
        res = auth.login("player123", "playerPassword123!")
        print("Login Success!")
        print("User:", res["user"]["username"])
        print("Role:", res["user"]["subscriptionRole"])
    except SpideyAuthException as e:
        print(f"Login failed: {e}")

    print("\nActivating license key...")
    try:
        lic = auth.activate_license("SPIDEY-AX91-KL84-99P2-44QR")
        print("License Activated:", lic["license"])
    except SpideyAuthException as e:
        print(f"Activation failed: {e}")

if __name__ == "__main__":
    main()
