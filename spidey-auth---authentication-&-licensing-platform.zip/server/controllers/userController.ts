import { Request, Response } from 'express';
import crypto from 'crypto';
import { query, queryOne, execute } from '../db/database';
import { hashPassword, comparePassword } from '../utils/crypto';

// ==========================================
// DEVELOPER MANAGEMENT OF APP USERS
// ==========================================

export const listApplicationUsers = async (req: Request, res: Response): Promise<void> => {
  try {
    const authUser = (req as any).user;
    const { appId } = req.params;
    const { search, status, page = '1', limit = '10' } = req.query;

    // Verify app ownership
    const app = queryOne<any>(`SELECT id FROM applications WHERE id = ? AND owner_id = ?`, [appId, authUser.id]);
    if (!app) {
      res.status(404).json({ success: false, error: { code: 'NOT_FOUND', message: 'Application not found or unauthorized.' } });
      return;
    }

    let sql = `SELECT id, application_id, username, email, status, subscription_role, expires_at, notes, last_login_at, last_ip, created_at, updated_at FROM application_users WHERE application_id = ?`;
    const params: any[] = [appId];

    if (search) {
      sql += ` AND (LOWER(username) LIKE ? OR LOWER(email) LIKE ? OR LOWER(notes) LIKE ?)`;
      const term = `%${String(search).toLowerCase()}%`;
      params.push(term, term, term);
    }

    if (status && status !== 'all') {
      sql += ` AND status = ?`;
      params.push(status);
    }

    // Count
    const countSql = sql.replace('SELECT id, application_id, username, email, status, subscription_role, expires_at, notes, last_login_at, last_ip, created_at, updated_at', 'SELECT COUNT(*) as total');
    const totalCount = queryOne<{ total: number }>(countSql, params);

    // Pagination
    const pageNum = Math.max(1, parseInt(page as string, 10) || 1);
    const limitNum = Math.min(100, Math.max(1, parseInt(limit as string, 10) || 10));
    const offset = (pageNum - 1) * limitNum;

    sql += ` ORDER BY created_at DESC LIMIT ? OFFSET ?`;
    params.push(limitNum, offset);

    const users = query<any>(sql, params);

    res.json({
      success: true,
      users,
      pagination: {
        page: pageNum,
        limit: limitNum,
        total: totalCount?.total || 0,
        pages: Math.ceil((totalCount?.total || 0) / limitNum),
      },
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

export const createApplicationUser = async (req: Request, res: Response): Promise<void> => {
  try {
    const authUser = (req as any).user;
    const { appId } = req.params;
    const { username, password, email, subscriptionRole, expiresAt, notes } = req.body;

    const app = queryOne<any>(`SELECT id, name FROM applications WHERE id = ? AND owner_id = ?`, [appId, authUser.id]);
    if (!app) {
      res.status(404).json({ success: false, error: { code: 'NOT_FOUND', message: 'Application not found or unauthorized.' } });
      return;
    }

    if (!username || !password) {
      res.status(400).json({ success: false, error: { code: 'INVALID_INPUT', message: 'Username and password are required.' } });
      return;
    }

    // Check uniqueness within this application
    const existing = queryOne<any>(
      `SELECT id FROM application_users WHERE application_id = ? AND LOWER(username) = LOWER(?)`,
      [appId, username.trim()]
    );

    if (existing) {
      res.status(409).json({ success: false, error: { code: 'USERNAME_TAKEN', message: 'Username is already taken in this application.' } });
      return;
    }

    const userId = 'appusr_' + crypto.randomBytes(8).toString('hex');
    const passwordHash = await hashPassword(password);
    const now = new Date().toISOString();

    execute(`
      INSERT INTO application_users (id, application_id, username, password_hash, email, status, subscription_role, expires_at, notes, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, 'active', ?, ?, ?, ?, ?);
    `, [
      userId,
      appId,
      username.trim(),
      passwordHash,
      email?.trim() || '',
      subscriptionRole?.trim() || 'default',
      expiresAt || null,
      notes?.trim() || '',
      now,
      now,
    ]);

    execute(`
      INSERT INTO audit_logs (id, user_id, application_id, event_type, description, ip_address, created_at)
      VALUES (?, ?, ?, 'APP_USER_CREATED', ?, ?, ?);
    `, ['log_' + crypto.randomBytes(8).toString('hex'), authUser.id, appId, `Created application user "${username.trim()}" in ${app.name}`, req.ip || '127.0.0.1', now]);

    res.status(201).json({
      success: true,
      message: 'User created successfully.',
      user: {
        id: userId,
        application_id: appId,
        username: username.trim(),
        email: email?.trim() || '',
        status: 'active',
        subscription_role: subscriptionRole?.trim() || 'default',
        expires_at: expiresAt || null,
        notes: notes?.trim() || '',
        created_at: now,
      },
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

export const updateApplicationUser = async (req: Request, res: Response): Promise<void> => {
  try {
    const authUser = (req as any).user;
    const { appId, userId } = req.params;
    const { email, status, subscriptionRole, expiresAt, notes } = req.body;

    const app = queryOne<any>(`SELECT id FROM applications WHERE id = ? AND owner_id = ?`, [appId, authUser.id]);
    if (!app) {
      res.status(404).json({ success: false, error: { code: 'NOT_FOUND', message: 'Application not found or unauthorized.' } });
      return;
    }

    const user = queryOne<any>(`SELECT * FROM application_users WHERE id = ? AND application_id = ?`, [userId, appId]);
    if (!user) {
      res.status(404).json({ success: false, error: { code: 'USER_NOT_FOUND', message: 'User not found.' } });
      return;
    }

    const now = new Date().toISOString();
    execute(`
      UPDATE application_users
      SET email = COALESCE(?, email),
          status = COALESCE(?, status),
          subscription_role = COALESCE(?, subscription_role),
          expires_at = COALESCE(?, expires_at),
          notes = COALESCE(?, notes),
          updated_at = ?
      WHERE id = ? AND application_id = ?;
    `, [
      email !== undefined ? email.trim() : null,
      status || null,
      subscriptionRole || null,
      expiresAt !== undefined ? expiresAt : null,
      notes !== undefined ? notes.trim() : null,
      now,
      userId,
      appId,
    ]);

    execute(`
      INSERT INTO audit_logs (id, user_id, application_id, event_type, description, ip_address, created_at)
      VALUES (?, ?, ?, 'APP_USER_UPDATED', ?, ?, ?);
    `, ['log_' + crypto.randomBytes(8).toString('hex'), authUser.id, appId, `Updated application user "${user.username}"`, req.ip || '127.0.0.1', now]);

    res.json({ success: true, message: 'User updated successfully.' });
  } catch (err: any) {
    res.status(500).json({ success: false, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

export const resetApplicationUserPassword = async (req: Request, res: Response): Promise<void> => {
  try {
    const authUser = (req as any).user;
    const { appId, userId } = req.params;
    const { newPassword } = req.body;

    const app = queryOne<any>(`SELECT id FROM applications WHERE id = ? AND owner_id = ?`, [appId, authUser.id]);
    if (!app) {
      res.status(404).json({ success: false, error: { code: 'NOT_FOUND', message: 'Application not found or unauthorized.' } });
      return;
    }

    const user = queryOne<any>(`SELECT * FROM application_users WHERE id = ? AND application_id = ?`, [userId, appId]);
    if (!user) {
      res.status(404).json({ success: false, error: { code: 'USER_NOT_FOUND', message: 'User not found.' } });
      return;
    }

    const generatedPassword = newPassword?.trim() || 'pwd_' + crypto.randomBytes(6).toString('hex');
    const newHash = await hashPassword(generatedPassword);
    const now = new Date().toISOString();

    execute(`UPDATE application_users SET password_hash = ?, updated_at = ? WHERE id = ? AND application_id = ?`, [newHash, now, userId, appId]);

    execute(`
      INSERT INTO audit_logs (id, user_id, application_id, event_type, description, ip_address, created_at)
      VALUES (?, ?, ?, 'APP_USER_PASSWORD_RESET', ?, ?, ?);
    `, ['log_' + crypto.randomBytes(8).toString('hex'), authUser.id, appId, `Password reset for user "${user.username}"`, req.ip || '127.0.0.1', now]);

    res.json({
      success: true,
      message: 'Password reset successfully.',
      temporaryPassword: generatedPassword,
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

export const deleteApplicationUser = async (req: Request, res: Response): Promise<void> => {
  try {
    const authUser = (req as any).user;
    const { appId, userId } = req.params;

    const app = queryOne<any>(`SELECT id FROM applications WHERE id = ? AND owner_id = ?`, [appId, authUser.id]);
    if (!app) {
      res.status(404).json({ success: false, error: { code: 'NOT_FOUND', message: 'Application not found or unauthorized.' } });
      return;
    }

    const user = queryOne<any>(`SELECT username FROM application_users WHERE id = ? AND application_id = ?`, [userId, appId]);
    if (!user) {
      res.status(404).json({ success: false, error: { code: 'USER_NOT_FOUND', message: 'User not found.' } });
      return;
    }

    execute(`DELETE FROM application_users WHERE id = ? AND application_id = ?`, [userId, appId]);

    const now = new Date().toISOString();
    execute(`
      INSERT INTO audit_logs (id, user_id, application_id, event_type, description, ip_address, created_at)
      VALUES (?, ?, ?, 'APP_USER_DELETED', ?, ?, ?);
    `, ['log_' + crypto.randomBytes(8).toString('hex'), authUser.id, appId, `Deleted application user "${user.username}"`, req.ip || '127.0.0.1', now]);

    res.json({ success: true, message: 'User deleted successfully.' });
  } catch (err: any) {
    res.status(500).json({ success: false, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

// ==========================================
// DEVELOPER APPLICATION CLIENT / SDK API
// ==========================================

export const apiUserLogin = async (req: Request, res: Response): Promise<void> => {
  const startTime = Date.now();
  try {
    const app = (req as any).clientApp;
    const { username, password, hwid } = req.body;

    if (!username || !password) {
      res.status(400).json({
        success: false,
        error: { code: 'MISSING_CREDENTIALS', message: 'Username and password are required.' },
      });
      return;
    }

    const user = queryOne<any>(
      `SELECT * FROM application_users WHERE application_id = ? AND LOWER(username) = LOWER(?)`,
      [app.id, username.trim()]
    );

    if (!user) {
      // Record API request
      recordApiRequest(app.id, '/api/user/login', 'POST', 404, Date.now() - startTime, req.ip);
      res.status(404).json({
        success: false,
        error: { code: 'INVALID_USERNAME', message: 'User does not exist in this application.' },
      });
      return;
    }

    if (user.status === 'banned') {
      recordApiRequest(app.id, '/api/user/login', 'POST', 403, Date.now() - startTime, req.ip);
      res.status(403).json({
        success: false,
        error: { code: 'USER_BANNED', message: 'This user account has been banned from accessing the application.' },
      });
      return;
    }

    if (user.status === 'disabled') {
      recordApiRequest(app.id, '/api/user/login', 'POST', 403, Date.now() - startTime, req.ip);
      res.status(403).json({
        success: false,
        error: { code: 'USER_DISABLED', message: 'This user account is currently disabled.' },
      });
      return;
    }

    if (user.expires_at) {
      const expiry = new Date(user.expires_at).getTime();
      if (expiry < Date.now()) {
        recordApiRequest(app.id, '/api/user/login', 'POST', 403, Date.now() - startTime, req.ip);
        res.status(403).json({
          success: false,
          error: { code: 'USER_EXPIRED', message: 'User access period has expired.' },
        });
        return;
      }
    }

    const isMatch = await comparePassword(password, user.password_hash);
    if (!isMatch) {
      recordApiRequest(app.id, '/api/user/login', 'POST', 401, Date.now() - startTime, req.ip);
      res.status(401).json({
        success: false,
        error: { code: 'INVALID_PASSWORD', message: 'The password provided is incorrect.' },
      });
      return;
    }

    // Update last login
    const now = new Date().toISOString();
    execute(
      `UPDATE application_users SET last_login_at = ?, last_ip = ?, updated_at = ? WHERE id = ?`,
      [now, req.ip || '127.0.0.1', now, user.id]
    );

    recordApiRequest(app.id, '/api/user/login', 'POST', 200, Date.now() - startTime, req.ip);

    // Audit log
    execute(`
      INSERT INTO audit_logs (id, application_id, event_type, description, ip_address, created_at)
      VALUES (?, ?, 'SDK_USER_LOGIN', ?, ?, ?);
    `, ['log_' + crypto.randomBytes(8).toString('hex'), app.id, `User "${user.username}" authenticated successfully`, req.ip || '127.0.0.1', now]);

    res.json({
      success: true,
      user: {
        id: user.id,
        username: user.username,
        email: user.email || null,
        status: user.status,
        subscriptionRole: user.subscription_role,
        expiresAt: user.expires_at,
        lastLoginAt: now,
      },
      message: 'Authentication successful.',
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

export const apiUserRegister = async (req: Request, res: Response): Promise<void> => {
  const startTime = Date.now();
  try {
    const app = (req as any).clientApp;
    const { username, password, email, licenseKey } = req.body;

    if (!username || !password) {
      res.status(400).json({
        success: false,
        error: { code: 'MISSING_CREDENTIALS', message: 'Username and password are required.' },
      });
      return;
    }

    const existing = queryOne<any>(
      `SELECT id FROM application_users WHERE application_id = ? AND LOWER(username) = LOWER(?)`,
      [app.id, username.trim()]
    );

    if (existing) {
      recordApiRequest(app.id, '/api/user/register', 'POST', 409, Date.now() - startTime, req.ip);
      res.status(409).json({
        success: false,
        error: { code: 'USERNAME_TAKEN', message: 'Username is already taken.' },
      });
      return;
    }

    let subscriptionRole = 'default';
    let expiresAt: string | null = null;

    // Optional license key activation on register
    if (licenseKey) {
      const lic = queryOne<any>(
        `SELECT * FROM licenses WHERE application_id = ? AND key = ?`,
        [app.id, licenseKey.trim()]
      );

      if (!lic) {
        res.status(400).json({ success: false, error: { code: 'INVALID_LICENSE', message: 'The provided registration license key is invalid.' } });
        return;
      }

      if (lic.status !== 'ACTIVE') {
        res.status(400).json({ success: false, error: { code: 'LICENSE_NOT_ACTIVE', message: `License is ${lic.status.toLowerCase()}.` } });
        return;
      }

      if (lic.current_activations >= lic.max_activations) {
        res.status(400).json({ success: false, error: { code: 'ACTIVATION_LIMIT_REACHED', message: 'License key has reached its maximum activations.' } });
        return;
      }

      subscriptionRole = lic.subscription_type;
      expiresAt = lic.expires_at;

      // Update license activations
      const now = new Date().toISOString();
      const newCount = lic.current_activations + 1;
      const newStatus = newCount >= lic.max_activations ? 'USED' : 'ACTIVE';
      execute(`UPDATE licenses SET current_activations = ?, status = ?, updated_at = ? WHERE id = ?`, [newCount, newStatus, now, lic.id]);

      execute(`
        INSERT INTO license_activations (id, license_id, application_id, client_identifier, ip_address, username, activated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?);
      `, ['act_' + crypto.randomBytes(8).toString('hex'), lic.id, app.id, 'REGISTRATION', req.ip || '127.0.0.1', username.trim(), now]);
    }

    const userId = 'appusr_' + crypto.randomBytes(8).toString('hex');
    const passwordHash = await hashPassword(password);
    const now = new Date().toISOString();

    execute(`
      INSERT INTO application_users (id, application_id, username, password_hash, email, status, subscription_role, expires_at, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, 'active', ?, ?, ?, ?);
    `, [userId, app.id, username.trim(), passwordHash, email?.trim() || '', subscriptionRole, expiresAt, now, now]);

    recordApiRequest(app.id, '/api/user/register', 'POST', 201, Date.now() - startTime, req.ip);

    res.status(201).json({
      success: true,
      user: {
        id: userId,
        username: username.trim(),
        status: 'active',
        subscriptionRole,
        expiresAt,
      },
      message: 'User registered successfully.',
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

export const apiUserResetPassword = async (req: Request, res: Response): Promise<void> => {
  const startTime = Date.now();
  try {
    const app = (req as any).clientApp;
    const { username, currentPassword, newPassword } = req.body;

    if (!username || !currentPassword || !newPassword) {
      res.status(400).json({
        success: false,
        error: { code: 'MISSING_FIELDS', message: 'Username, current password, and new password are required.' },
      });
      return;
    }

    const user = queryOne<any>(
      `SELECT * FROM application_users WHERE application_id = ? AND LOWER(username) = LOWER(?)`,
      [app.id, username.trim()]
    );

    if (!user) {
      recordApiRequest(app.id, '/api/user/reset-password', 'POST', 404, Date.now() - startTime, req.ip);
      res.status(404).json({ success: false, error: { code: 'INVALID_USERNAME', message: 'User not found.' } });
      return;
    }

    const isMatch = await comparePassword(currentPassword, user.password_hash);
    if (!isMatch) {
      recordApiRequest(app.id, '/api/user/reset-password', 'POST', 401, Date.now() - startTime, req.ip);
      res.status(401).json({ success: false, error: { code: 'INVALID_PASSWORD', message: 'Current password is incorrect.' } });
      return;
    }

    const newHash = await hashPassword(newPassword);
    const now = new Date().toISOString();
    execute(`UPDATE application_users SET password_hash = ?, updated_at = ? WHERE id = ?`, [newHash, now, user.id]);

    recordApiRequest(app.id, '/api/user/reset-password', 'POST', 200, Date.now() - startTime, req.ip);

    res.json({
      success: true,
      message: 'Password updated successfully.',
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

export const apiGetUser = async (req: Request, res: Response): Promise<void> => {
  try {
    const app = (req as any).clientApp;
    const { username } = req.query;

    if (!username) {
      res.status(400).json({ success: false, error: { code: 'INVALID_INPUT', message: 'Username query parameter is required.' } });
      return;
    }

    const user = queryOne<any>(
      `SELECT id, username, email, status, subscription_role, expires_at, last_login_at, created_at FROM application_users WHERE application_id = ? AND LOWER(username) = LOWER(?)`,
      [app.id, String(username).trim()]
    );

    if (!user) {
      res.status(404).json({ success: false, error: { code: 'USER_NOT_FOUND', message: 'User does not exist in this application.' } });
      return;
    }

    res.json({ success: true, user });
  } catch (err: any) {
    res.status(500).json({ success: false, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

function recordApiRequest(appId: string, endpoint: string, method: string, statusCode: number, responseTimeMs: number, ip?: string): void {
  try {
    execute(`
      INSERT INTO api_requests (id, application_id, endpoint, method, status_code, response_time_ms, ip_address, created_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?);
    `, ['req_' + crypto.randomBytes(8).toString('hex'), appId, endpoint, method, statusCode, responseTimeMs, ip || '127.0.0.1', new Date().toISOString()]);
  } catch (e) {
    console.error('Failed to record API request log', e);
  }
}
