import { Request, Response } from 'express';
import crypto from 'crypto';
import { query, queryOne, execute } from '../db/database';

export const getAdminOverview = async (req: Request, res: Response): Promise<void> => {
  try {
    const totalUsers = queryOne<{ count: number }>(`SELECT COUNT(*) as count FROM users;`);
    const totalApps = queryOne<{ count: number }>(`SELECT COUNT(*) as count FROM applications;`);
    const totalLicenses = queryOne<{ count: number }>(`SELECT COUNT(*) as count FROM licenses;`);
    const totalAppUsers = queryOne<{ count: number }>(`SELECT COUNT(*) as count FROM application_users;`);
    const totalRequests = queryOne<{ count: number }>(`SELECT COUNT(*) as count FROM api_requests;`);
    const totalPremium = queryOne<{ count: number }>(`SELECT COUNT(*) as count FROM users WHERE subscription_tier = 'PREMIUM';`);

    const recentLogs = query<any>(`SELECT * FROM audit_logs ORDER BY created_at DESC LIMIT 10;`);
    const recentUsers = query<any>(`SELECT id, username, email, role, subscription_tier, is_suspended, created_at FROM users ORDER BY created_at DESC LIMIT 5;`);

    res.json({
      success: true,
      stats: {
        totalUsers: totalUsers?.count || 0,
        totalApps: totalApps?.count || 0,
        totalLicenses: totalLicenses?.count || 0,
        totalAppUsers: totalAppUsers?.count || 0,
        totalRequests: totalRequests?.count || 0,
        totalPremium: totalPremium?.count || 0,
      },
      recentLogs,
      recentUsers,
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

export const listAllUsers = async (req: Request, res: Response): Promise<void> => {
  try {
    const users = query<any>(`
      SELECT u.id, u.username, u.email, u.role, u.subscription_tier, u.is_suspended, u.created_at,
             (SELECT COUNT(*) FROM applications WHERE owner_id = u.id) as app_count
      FROM users u
      ORDER BY u.created_at DESC;
    `);

    res.json({ success: true, users });
  } catch (err: any) {
    res.status(500).json({ success: false, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

export const updateUserRole = async (req: Request, res: Response): Promise<void> => {
  try {
    const adminUser = (req as any).user;
    const { userId } = req.params;
    const { role } = req.body;

    if (!['USER', 'ADMIN'].includes(role)) {
      res.status(400).json({ success: false, error: { code: 'INVALID_ROLE', message: 'Role must be USER or ADMIN.' } });
      return;
    }

    const now = new Date().toISOString();
    execute(`UPDATE users SET role = ?, updated_at = ? WHERE id = ?`, [role, now, userId]);

    execute(`
      INSERT INTO audit_logs (id, user_id, event_type, description, ip_address, created_at)
      VALUES (?, ?, 'ADMIN_ROLE_CHANGE', ?, ?, ?);
    `, ['log_' + crypto.randomBytes(8).toString('hex'), adminUser.id, `Changed role of user ${userId} to ${role}`, req.ip || '127.0.0.1', now]);

    res.json({ success: true, message: `User role updated to ${role}.` });
  } catch (err: any) {
    res.status(500).json({ success: false, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

export const toggleUserSuspension = async (req: Request, res: Response): Promise<void> => {
  try {
    const adminUser = (req as any).user;
    const { userId } = req.params;
    const { isSuspended } = req.body;

    const user = queryOne<any>(`SELECT id, username FROM users WHERE id = ?`, [userId]);
    if (!user) {
      res.status(404).json({ success: false, error: { code: 'NOT_FOUND', message: 'User not found.' } });
      return;
    }

    const now = new Date().toISOString();
    const flag = isSuspended ? 1 : 0;
    execute(`UPDATE users SET is_suspended = ?, updated_at = ? WHERE id = ?`, [flag, now, userId]);

    execute(`
      INSERT INTO audit_logs (id, user_id, event_type, description, ip_address, created_at)
      VALUES (?, ?, 'ADMIN_SUSPENSION_CHANGE', ?, ?, ?);
    `, ['log_' + crypto.randomBytes(8).toString('hex'), adminUser.id, `${flag ? 'Suspended' : 'Unsuspended'} user "${user.username}"`, req.ip || '127.0.0.1', now]);

    res.json({ success: true, message: `User ${flag ? 'suspended' : 're-activated'} successfully.` });
  } catch (err: any) {
    res.status(500).json({ success: false, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

export const listAllApplications = async (req: Request, res: Response): Promise<void> => {
  try {
    const apps = query<any>(`
      SELECT a.*, u.username as owner_username, u.email as owner_email,
             (SELECT COUNT(*) FROM application_users WHERE application_id = a.id) as user_count,
             (SELECT COUNT(*) FROM licenses WHERE application_id = a.id) as license_count,
             (SELECT COUNT(*) FROM api_requests WHERE application_id = a.id) as request_count
      FROM applications a
      JOIN users u ON a.owner_id = u.id
      ORDER BY a.created_at DESC;
    `);

    res.json({ success: true, applications: apps });
  } catch (err: any) {
    res.status(500).json({ success: false, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

export const toggleAppStatus = async (req: Request, res: Response): Promise<void> => {
  try {
    const adminUser = (req as any).user;
    const { appId } = req.params;
    const { status } = req.body;

    if (!['ACTIVE', 'DISABLED'].includes(status)) {
      res.status(400).json({ success: false, error: { code: 'INVALID_STATUS', message: 'Status must be ACTIVE or DISABLED.' } });
      return;
    }

    const now = new Date().toISOString();
    execute(`UPDATE applications SET status = ?, updated_at = ? WHERE id = ?`, [status, now, appId]);

    execute(`
      INSERT INTO audit_logs (id, user_id, application_id, event_type, description, ip_address, created_at)
      VALUES (?, ?, ?, 'ADMIN_APP_STATUS_CHANGE', ?, ?, ?);
    `, ['log_' + crypto.randomBytes(8).toString('hex'), adminUser.id, appId, `Application ${appId} status changed to ${status}`, req.ip || '127.0.0.1', now]);

    res.json({ success: true, message: `Application status set to ${status}.` });
  } catch (err: any) {
    res.status(500).json({ success: false, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

export const getAllAuditLogs = async (req: Request, res: Response): Promise<void> => {
  try {
    const logs = query<any>(`SELECT * FROM audit_logs ORDER BY created_at DESC LIMIT 100;`);
    res.json({ success: true, logs });
  } catch (err: any) {
    res.status(500).json({ success: false, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};
