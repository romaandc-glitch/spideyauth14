import { Request, Response } from 'express';
import crypto from 'crypto';
import { query, queryOne, execute } from '../db/database';
import { generateApplicationId, generateOwnerId, generateRandomSecret, hashPassword, maskSecret } from '../utils/crypto';

export const listApplications = async (req: Request, res: Response): Promise<void> => {
  try {
    const authUser = (req as any).user;
    const apps = query<any>(
      `SELECT a.*,
              (SELECT COUNT(*) FROM application_users WHERE application_id = a.id) as user_count,
              (SELECT COUNT(*) FROM licenses WHERE application_id = a.id) as license_count,
              (SELECT COUNT(*) FROM licenses WHERE application_id = a.id AND status = 'ACTIVE') as active_license_count,
              (SELECT COUNT(*) FROM api_requests WHERE application_id = a.id) as request_count
       FROM applications a
       WHERE a.owner_id = ?
       ORDER BY a.created_at DESC`,
      [authUser.id]
    );

    // Attach secret masked for each app
    const enriched = apps.map((app) => {
      const secret = queryOne<any>(
        `SELECT secret_masked FROM application_secrets WHERE application_id = ? AND is_revoked = 0 ORDER BY created_at DESC LIMIT 1`,
        [app.id]
      );
      return {
        ...app,
        secretMasked: secret?.secret_masked || '••••••••••••••••',
      };
    });

    res.json({ success: true, applications: enriched });
  } catch (err: any) {
    res.status(500).json({ success: false, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

export const createApplication = async (req: Request, res: Response): Promise<void> => {
  try {
    const authUser = (req as any).user;
    const { name, description, version } = req.body;

    if (!name || name.trim().length === 0) {
      res.status(400).json({
        success: false,
        error: { code: 'INVALID_INPUT', message: 'Application name is required.' },
      });
      return;
    }

    const appId = generateApplicationId();
    const ownerCode = generateOwnerId();
    const rawSecret = generateRandomSecret();
    const secretHash = await hashPassword(rawSecret);
    const masked = maskSecret(rawSecret);
    const now = new Date().toISOString();

    // Insert App
    execute(`
      INSERT INTO applications (id, owner_id, owner_code, name, description, version, status, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, 'ACTIVE', ?, ?);
    `, [appId, authUser.id, ownerCode, name.trim(), description?.trim() || '', version?.trim() || '1.0.0', now, now]);

    // Insert Secret
    execute(`
      INSERT INTO application_secrets (id, application_id, secret_hash, secret_masked, secret_raw, is_revoked, created_at)
      VALUES (?, ?, ?, ?, ?, 0, ?);
    `, ['sec_' + crypto.randomBytes(8).toString('hex'), appId, secretHash, masked, rawSecret, now]);

    // Audit log
    execute(`
      INSERT INTO audit_logs (id, user_id, application_id, event_type, description, ip_address, created_at)
      VALUES (?, ?, ?, 'APPLICATION_CREATED', ?, ?, ?);
    `, ['log_' + crypto.randomBytes(8).toString('hex'), authUser.id, appId, `Application "${name.trim()}" created (${appId})`, req.ip || '127.0.0.1', now]);

    // Notification
    execute(`
      INSERT INTO notifications (id, user_id, title, message, type, is_read, created_at)
      VALUES (?, ?, ?, ?, 'success', 0, ?);
    `, ['notif_' + crypto.randomBytes(8).toString('hex'), authUser.id, 'Application Created', `Application "${name.trim()}" has been initialized.`, now]);

    res.status(201).json({
      success: true,
      message: 'Application created successfully.',
      application: {
        id: appId,
        owner_code: ownerCode,
        name: name.trim(),
        description: description?.trim() || '',
        version: version?.trim() || '1.0.0',
        status: 'ACTIVE',
        secret: rawSecret, // Returned once upon creation
        secretMasked: masked,
        created_at: now,
      },
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

export const getApplicationDetails = async (req: Request, res: Response): Promise<void> => {
  try {
    const authUser = (req as any).user;
    const { id } = req.params;

    const app = queryOne<any>(
      `SELECT * FROM applications WHERE id = ? AND owner_id = ?`,
      [id, authUser.id]
    );

    if (!app) {
      res.status(404).json({ success: false, error: { code: 'NOT_FOUND', message: 'Application not found.' } });
      return;
    }

    const secret = queryOne<any>(
      `SELECT secret_masked, created_at FROM application_secrets WHERE application_id = ? AND is_revoked = 0 ORDER BY created_at DESC LIMIT 1`,
      [id]
    );

    const userCount = queryOne<{ count: number }>(`SELECT COUNT(*) as count FROM application_users WHERE application_id = ?`, [id]);
    const licenseCount = queryOne<{ count: number }>(`SELECT COUNT(*) as count FROM licenses WHERE application_id = ?`, [id]);
    const activeLicenseCount = queryOne<{ count: number }>(`SELECT COUNT(*) as count FROM licenses WHERE application_id = ? AND status = 'ACTIVE'`, [id]);
    const requestCount = queryOne<{ count: number }>(`SELECT COUNT(*) as count FROM api_requests WHERE application_id = ?`, [id]);

    res.json({
      success: true,
      application: {
        ...app,
        secretMasked: secret?.secret_masked || '••••••••••••••••',
        user_count: userCount?.count || 0,
        license_count: licenseCount?.count || 0,
        active_license_count: activeLicenseCount?.count || 0,
        request_count: requestCount?.count || 0,
      },
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

export const updateApplication = async (req: Request, res: Response): Promise<void> => {
  try {
    const authUser = (req as any).user;
    const { id } = req.params;
    const { name, description, version, status } = req.body;

    const app = queryOne<any>(`SELECT * FROM applications WHERE id = ? AND owner_id = ?`, [id, authUser.id]);
    if (!app) {
      res.status(404).json({ success: false, error: { code: 'NOT_FOUND', message: 'Application not found.' } });
      return;
    }

    const now = new Date().toISOString();
    execute(`
      UPDATE applications
      SET name = COALESCE(?, name),
          description = COALESCE(?, description),
          version = COALESCE(?, version),
          status = COALESCE(?, status),
          updated_at = ?
      WHERE id = ? AND owner_id = ?;
    `, [name?.trim() || null, description !== undefined ? description.trim() : null, version?.trim() || null, status || null, now, id, authUser.id]);

    execute(`
      INSERT INTO audit_logs (id, user_id, application_id, event_type, description, ip_address, created_at)
      VALUES (?, ?, ?, 'APPLICATION_UPDATED', ?, ?, ?);
    `, ['log_' + crypto.randomBytes(8).toString('hex'), authUser.id, id, `Application settings updated for ${app.name}`, req.ip || '127.0.0.1', now]);

    res.json({ success: true, message: 'Application updated successfully.' });
  } catch (err: any) {
    res.status(500).json({ success: false, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

export const deleteApplication = async (req: Request, res: Response): Promise<void> => {
  try {
    const authUser = (req as any).user;
    const { id } = req.params;

    const app = queryOne<any>(`SELECT * FROM applications WHERE id = ? AND owner_id = ?`, [id, authUser.id]);
    if (!app) {
      res.status(404).json({ success: false, error: { code: 'NOT_FOUND', message: 'Application not found.' } });
      return;
    }

    // Cascade delete
    execute(`DELETE FROM applications WHERE id = ? AND owner_id = ?`, [id, authUser.id]);

    const now = new Date().toISOString();
    execute(`
      INSERT INTO audit_logs (id, user_id, event_type, description, ip_address, created_at)
      VALUES (?, ?, 'APPLICATION_DELETED', ?, ?, ?);
    `, ['log_' + crypto.randomBytes(8).toString('hex'), authUser.id, `Application "${app.name}" (${id}) was deleted`, req.ip || '127.0.0.1', now]);

    res.json({ success: true, message: 'Application deleted successfully.' });
  } catch (err: any) {
    res.status(500).json({ success: false, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

export const regenerateSecret = async (req: Request, res: Response): Promise<void> => {
  try {
    const authUser = (req as any).user;
    const { id } = req.params;

    const app = queryOne<any>(`SELECT * FROM applications WHERE id = ? AND owner_id = ?`, [id, authUser.id]);
    if (!app) {
      res.status(404).json({ success: false, error: { code: 'NOT_FOUND', message: 'Application not found.' } });
      return;
    }

    // Revoke previous secrets
    execute(`UPDATE application_secrets SET is_revoked = 1 WHERE application_id = ?`, [id]);

    const newSecret = generateRandomSecret();
    const newHash = await hashPassword(newSecret);
    const masked = maskSecret(newSecret);
    const now = new Date().toISOString();

    execute(`
      INSERT INTO application_secrets (id, application_id, secret_hash, secret_masked, secret_raw, is_revoked, created_at)
      VALUES (?, ?, ?, ?, ?, 0, ?);
    `, ['sec_' + crypto.randomBytes(8).toString('hex'), id, newHash, masked, newSecret, now]);

    execute(`
      INSERT INTO audit_logs (id, user_id, application_id, event_type, description, ip_address, created_at)
      VALUES (?, ?, ?, 'SECRET_REGENERATED', ?, ?, ?);
    `, ['log_' + crypto.randomBytes(8).toString('hex'), authUser.id, id, `Application secret was regenerated for ${app.name}`, req.ip || '127.0.0.1', now]);

    res.json({
      success: true,
      secret: newSecret,
      secretMasked: masked,
      message: 'Secret regenerated successfully.',
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

export const revealSecret = async (req: Request, res: Response): Promise<void> => {
  try {
    const authUser = (req as any).user;
    const { id } = req.params;

    const app = queryOne<any>(`SELECT * FROM applications WHERE id = ? AND owner_id = ?`, [id, authUser.id]);
    if (!app) {
      res.status(404).json({ success: false, error: { code: 'NOT_FOUND', message: 'Application not found.' } });
      return;
    }

    const secret = queryOne<any>(
      `SELECT secret_raw FROM application_secrets WHERE application_id = ? AND is_revoked = 0 ORDER BY created_at DESC LIMIT 1`,
      [id]
    );

    res.json({
      success: true,
      secret: secret?.secret_raw || '',
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

export const getStatistics = async (req: Request, res: Response): Promise<void> => {
  try {
    const authUser = (req as any).user;
    const { id } = req.params;

    const app = queryOne<any>(`SELECT * FROM applications WHERE id = ? AND owner_id = ?`, [id, authUser.id]);
    if (!app) {
      res.status(404).json({ success: false, error: { code: 'NOT_FOUND', message: 'Application not found.' } });
      return;
    }

    // Chart daily activity for last 7 days
    const dailyStats: any[] = [];
    for (let i = 6; i >= 0; i--) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      const dayStr = d.toISOString().split('T')[0];

      const reqCount = queryOne<{ count: number }>(
        `SELECT COUNT(*) as count FROM api_requests WHERE application_id = ? AND date(created_at) = ?`,
        [id, dayStr]
      );

      const userRegCount = queryOne<{ count: number }>(
        `SELECT COUNT(*) as count FROM application_users WHERE application_id = ? AND date(created_at) = ?`,
        [id, dayStr]
      );

      const licActCount = queryOne<{ count: number }>(
        `SELECT COUNT(*) as count FROM license_activations WHERE application_id = ? AND date(activated_at) = ?`,
        [id, dayStr]
      );

      dailyStats.push({
        date: dayStr,
        requests: reqCount?.count || 0,
        registrations: userRegCount?.count || 0,
        activations: licActCount?.count || 0,
      });
    }

    // Breakdown of licenses by status
    const licenseBreakdown = query<any>(
      `SELECT status, COUNT(*) as count FROM licenses WHERE application_id = ? GROUP BY status`,
      [id]
    );

    // Endpoint popularity
    const topEndpoints = query<any>(
      `SELECT endpoint, COUNT(*) as count FROM api_requests WHERE application_id = ? GROUP BY endpoint ORDER BY count DESC LIMIT 5`,
      [id]
    );

    res.json({
      success: true,
      dailyStats,
      licenseBreakdown,
      topEndpoints,
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};
