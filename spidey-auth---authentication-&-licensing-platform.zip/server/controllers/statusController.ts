import { Request, Response } from 'express';
import { queryOne } from '../db/database';

const SERVER_START_TIME = Date.now();

export const getSystemStatus = async (_req: Request, res: Response): Promise<void> => {
  let dbStatus = 'ONLINE';
  let latencyMs = 0;

  try {
    const t0 = Date.now();
    const test = queryOne<{ one: number }>(`SELECT 1 as one;`);
    latencyMs = Date.now() - t0;
    if (!test || test.one !== 1) {
      dbStatus = 'DEGRADED';
    }
  } catch (err) {
    dbStatus = 'OFFLINE';
  }

  const uptimeSeconds = Math.floor((Date.now() - SERVER_START_TIME) / 1000);

  res.json({
    success: true,
    platform: 'SPIDEY AUTH',
    version: '1.0.0',
    status: 'ONLINE',
    services: {
      api: {
        status: 'ONLINE',
        healthy: true,
      },
      database: {
        status: dbStatus,
        healthy: dbStatus === 'ONLINE',
        engine: 'SQLite (Relational)',
        latencyMs,
      },
      authentication: {
        status: 'ONLINE',
        healthy: true,
        features: ['JWT', 'Bcrypt', 'Google OAuth 2.0', 'RBAC'],
      },
      licensingEngine: {
        status: 'ONLINE',
        healthy: true,
      },
    },
    uptimeSeconds,
    timestamp: new Date().toISOString(),
  });
};
