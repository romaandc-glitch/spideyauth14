import { Request, Response } from 'express';
import { query, queryOne } from '../db/database';

export const getAppAuditLogs = async (req: Request, res: Response): Promise<void> => {
  try {
    const authUser = (req as any).user;
    const { appId } = req.params;
    const { limit = '50' } = req.query;

    const app = queryOne<any>(`SELECT id FROM applications WHERE id = ? AND owner_id = ?`, [appId, authUser.id]);
    if (!app) {
      res.status(404).json({ success: false, error: { code: 'NOT_FOUND', message: 'Application not found or unauthorized.' } });
      return;
    }

    const logs = query<any>(
      `SELECT * FROM audit_logs WHERE application_id = ? ORDER BY created_at DESC LIMIT ?`,
      [appId, Math.min(100, Math.max(1, parseInt(limit as string, 10) || 50))]
    );

    res.json({ success: true, logs });
  } catch (err: any) {
    res.status(500).json({ success: false, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

export const getUserAuditLogs = async (req: Request, res: Response): Promise<void> => {
  try {
    const authUser = (req as any).user;
    const { limit = '50' } = req.query;

    const logs = query<any>(
      `SELECT * FROM audit_logs WHERE user_id = ? ORDER BY created_at DESC LIMIT ?`,
      [authUser.id, Math.min(100, Math.max(1, parseInt(limit as string, 10) || 50))]
    );

    res.json({ success: true, logs });
  } catch (err: any) {
    res.status(500).json({ success: false, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};
