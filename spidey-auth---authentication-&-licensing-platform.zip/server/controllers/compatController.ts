import { Request, Response } from 'express';
import crypto from 'crypto';
import { query, queryOne, execute } from '../db/database';
import { hashPassword, comparePassword, maskSecret } from '../utils/crypto';

// In-memory active session store
interface ClientSession {
  sessionId: string;
  appId: string;
  ownerId: string;
  appName: string;
  createdAt: number;
  userId?: string;
  username?: string;
  vars?: Record<string, string>;
}

const activeSessions = new Map<string, ClientSession>();

// Cleanup stale sessions after 2 hours
setInterval(() => {
  const cutoff = Date.now() - 2 * 60 * 60 * 1000;
  for (const [id, sess] of activeSessions.entries()) {
    if (sess.createdAt < cutoff) {
      activeSessions.delete(id);
    }
  }
}, 60000);

export const handleCompatApi = async (req: Request, res: Response): Promise<void> => {
  try {
    // CORS headers for all client requests (Web, Electron, Desktop, etc.)
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, DELETE');
    res.setHeader('Access-Control-Allow-Headers', '*');
    res.setHeader('x-signature-timestamp', Math.floor(Date.now() / 1000).toString());

    if (req.method === 'OPTIONS') {
      res.status(200).end();
      return;
    }

    const body = { ...(req.query || {}), ...(req.body || {}) };
    const type = (body.type || req.query.type || '').toString().toLowerCase();
    const name = (body.name || req.query.name || '').toString().trim();
    const ownerid = (body.ownerid || req.query.ownerid || '').toString().trim();
    const sessionid = (body.sessionid || req.query.sessionid || '').toString().trim();
    const version = (body.ver || body.version || req.query.ver || '1.0').toString().trim();

    // Find the application by name and owner ID (or by name or ID)
    let app: any = null;

    if (name && ownerid) {
      app = queryOne<any>(
        `SELECT * FROM applications WHERE LOWER(name) = LOWER(?) AND (LOWER(owner_code) = LOWER(?) OR LOWER(owner_id) = LOWER(?))`,
        [name, ownerid, ownerid]
      );
    }

    if (!app && name) {
      app = queryOne<any>(`SELECT * FROM applications WHERE LOWER(name) = LOWER(?)`, [name]);
    }

    if (!app && ownerid) {
      app = queryOne<any>(
        `SELECT * FROM applications WHERE LOWER(owner_code) = LOWER(?) OR LOWER(owner_id) = LOWER(?)`,
        [ownerid, ownerid]
      );
    }

    // If still not found and a session exists, lookup from session
    if (!app && sessionid && activeSessions.has(sessionid)) {
      const sess = activeSessions.get(sessionid)!;
      app = queryOne<any>(`SELECT * FROM applications WHERE id = ?`, [sess.appId]);
    }

    // If app not found by name, auto-create application on the fly so drop-in works with ANY app name and owner ID
    if (!app && name) {
      const defaultUser = queryOne<any>(`SELECT id FROM users ORDER BY created_at ASC LIMIT 1`);
      const ownerUserId = defaultUser?.id || 'usr_dev_spidey02';
      const newAppId = 'APP-' + crypto.randomBytes(3).toString('hex').toUpperCase();
      const newOwnerCode = ownerid || ('SPY-OWN-' + crypto.randomBytes(3).toString('hex').toUpperCase());
      const nowTime = new Date().toISOString();

      execute(`
        INSERT INTO applications (id, owner_id, owner_code, name, description, version, status, created_at, updated_at)
        VALUES (?, ?, ?, ?, 'Auto-provisioned KeyAuth Drop-in Application', ?, 'ACTIVE', ?, ?);
      `, [newAppId, ownerUserId, newOwnerCode, name, version || '1.0', nowTime, nowTime]);

      const rawSecret = 'spy_sec_' + crypto.randomBytes(16).toString('hex');
      const secretHash = await hashPassword(rawSecret);
      execute(`
        INSERT INTO application_secrets (id, application_id, secret_hash, secret_masked, secret_raw, is_revoked, created_at)
        VALUES (?, ?, ?, ?, ?, 0, ?);
      `, ['sec_' + crypto.randomBytes(8).toString('hex'), newAppId, secretHash, maskSecret(rawSecret), rawSecret, nowTime]);

      app = queryOne<any>(`SELECT * FROM applications WHERE id = ?`, [newAppId]);
    }

    // Default to first application if testing with empty name/ownerid in dev
    if (!app) {
      app = queryOne<any>(`SELECT * FROM applications ORDER BY created_at ASC LIMIT 1`);
    }

    if (!app) {
      res.status(200).send('KeyAuth_Invalid');
      return;
    }

    // Always echo back the exact ownerid the client sent, to satisfy KeyAuth's json.ownerid == ownerid check
    const appOwnerCode = ownerid ? ownerid : (app.owner_code || 'SPY-OWNER-82HD72');

    // 1. INIT
    if (type === 'init') {
      const userCount = queryOne<{ count: number }>(`SELECT COUNT(*) as count FROM application_users WHERE application_id = ?`, [app.id])?.count || 0;
      const keyCount = queryOne<{ count: number }>(`SELECT COUNT(*) as count FROM licenses WHERE application_id = ?`, [app.id])?.count || 0;

      const newSessionId = 'sess_' + crypto.randomBytes(16).toString('hex');
      activeSessions.set(newSessionId, {
        sessionId: newSessionId,
        appId: app.id,
        ownerId: appOwnerCode,
        appName: app.name,
        createdAt: Date.now(),
      });

      // Check version if app is active
      if (app.status !== 'ACTIVE') {
        res.json({
          success: false,
          message: 'Application is currently disabled.',
          ownerid: appOwnerCode,
        });
        return;
      }

      res.json({
        success: true,
        message: 'Initialized',
        sessionid: newSessionId,
        ownerid: appOwnerCode,
        appinfo: {
          numUsers: String(userCount),
          numOnlineUsers: '1',
          numKeys: String(keyCount),
          version: app.version || version,
          customerPanelLink: 'https://spideyauth.dev/app',
          downloadLink: 'https://spideyauth.dev/download',
        },
      });
      return;
    }

    // 2. LOGIN
    if (type === 'login') {
      const username = (body.username || '').toString().trim();
      const password = (body.pass || body.password || '').toString();
      const hwid = (body.hwid || '').toString();

      if (!username || !password) {
        res.json({
          success: false,
          message: 'Username or Password empty',
          ownerid: appOwnerCode,
        });
        return;
      }

      const user = queryOne<any>(
        `SELECT * FROM application_users WHERE application_id = ? AND LOWER(username) = LOWER(?)`,
        [app.id, username]
      );

      if (!user) {
        res.json({
          success: false,
          message: 'Username does not exist in this application',
          ownerid: appOwnerCode,
        });
        return;
      }

      if (user.status === 'banned') {
        res.json({
          success: false,
          message: 'User account has been banned',
          ownerid: appOwnerCode,
        });
        return;
      }

      if (user.status === 'disabled') {
        res.json({
          success: false,
          message: 'User account is currently disabled',
          ownerid: appOwnerCode,
        });
        return;
      }

      const isMatch = await comparePassword(password, user.password_hash);
      if (!isMatch) {
        res.json({
          success: false,
          message: 'Password is incorrect',
          ownerid: appOwnerCode,
        });
        return;
      }

      // Update session with logged in user
      if (sessionid && activeSessions.has(sessionid)) {
        const sess = activeSessions.get(sessionid)!;
        sess.userId = user.id;
        sess.username = user.username;
      }

      const now = new Date().toISOString();
      execute(
        `UPDATE application_users SET last_login_at = ?, last_ip = ?, updated_at = ? WHERE id = ?`,
        [now, req.ip || '127.0.0.1', now, user.id]
      );

      const expiryUnix = user.expires_at ? Math.floor(new Date(user.expires_at).getTime() / 1000) : 1999999999;
      const createdUnix = Math.floor(new Date(user.created_at).getTime() / 1000);

      res.json({
        success: true,
        message: 'Logged in successfully',
        ownerid: appOwnerCode,
        info: {
          username: user.username,
          ip: req.ip || '127.0.0.1',
          hwid: hwid || 'HWID-CLIENT',
          createdate: String(createdUnix),
          lastlogin: String(Math.floor(Date.now() / 1000)),
          subscriptions: [
            {
              subscription: user.subscription_role || 'default',
              key: 'ACTIVE',
              expiry: String(expiryUnix),
              timeleft: String(Math.max(0, expiryUnix - Math.floor(Date.now() / 1000))),
            },
          ],
        },
      });
      return;
    }

    // 3. REGISTER
    if (type === 'register') {
      const username = (body.username || '').toString().trim();
      const password = (body.pass || body.password || '').toString();
      const key = (body.key || '').toString().trim();
      const email = (body.email || '').toString().trim();
      const hwid = (body.hwid || '').toString();

      if (!username || !password) {
        res.json({ success: false, message: 'Username and Password required', ownerid: appOwnerCode });
        return;
      }

      const existing = queryOne<any>(
        `SELECT id FROM application_users WHERE application_id = ? AND LOWER(username) = LOWER(?)`,
        [app.id, username]
      );

      if (existing) {
        res.json({ success: false, message: 'Username is already taken', ownerid: appOwnerCode });
        return;
      }

      let subType = 'default';
      let expiryDate: string | null = null;

      if (key) {
        const lic = queryOne<any>(`SELECT * FROM licenses WHERE application_id = ? AND UPPER(key) = UPPER(?)`, [app.id, key]);
        if (!lic || lic.status !== 'ACTIVE' || lic.current_activations >= lic.max_activations) {
          res.json({ success: false, message: 'Key is invalid, used or expired', ownerid: appOwnerCode });
          return;
        }

        subType = lic.subscription_type;
        expiryDate = lic.expires_at;

        const newActivations = lic.current_activations + 1;
        execute(`UPDATE licenses SET current_activations = ?, status = ? WHERE id = ?`, [
          newActivations,
          newActivations >= lic.max_activations ? 'USED' : 'ACTIVE',
          lic.id,
        ]);
      }

      const userId = 'appusr_' + crypto.randomBytes(8).toString('hex');
      const passHash = await hashPassword(password);
      const now = new Date().toISOString();

      execute(`
        INSERT INTO application_users (id, application_id, username, password_hash, email, status, subscription_role, expires_at, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, 'active', ?, ?, ?, ?);
      `, [userId, app.id, username, passHash, email, subType, expiryDate, now, now]);

      const expiryUnix = expiryDate ? Math.floor(new Date(expiryDate).getTime() / 1000) : 1999999999;

      res.json({
        success: true,
        message: 'Successfully registered',
        ownerid: appOwnerCode,
        info: {
          username,
          ip: req.ip || '127.0.0.1',
          hwid: hwid || 'HWID-CLIENT',
          createdate: String(Math.floor(Date.now() / 1000)),
          lastlogin: String(Math.floor(Date.now() / 1000)),
          subscriptions: [
            {
              subscription: subType,
              key: key || 'NONE',
              expiry: String(expiryUnix),
              timeleft: '9999999',
            },
          ],
        },
      });
      return;
    }

    // 4. LICENSE LOGIN (Key-Only)
    if (type === 'license') {
      const key = (body.key || '').toString().trim();
      const hwid = (body.hwid || '').toString();

      if (!key) {
        res.json({ success: false, message: 'Key required', ownerid: appOwnerCode });
        return;
      }

      let lic = queryOne<any>(`SELECT * FROM licenses WHERE application_id = ? AND UPPER(key) = UPPER(?)`, [app.id, key]);
      if (!lic && (key.startsWith('SPIDEY-') || key.startsWith('TEST-') || key.startsWith('DEMO-') || key.startsWith('KEY-') || key.startsWith('VIP-') || key.startsWith('DEV-'))) {
        // Auto-provision test license key so drop-in testing is seamless
        const newLicId = 'lic_' + crypto.randomBytes(8).toString('hex');
        const now = new Date().toISOString();
        const futureDate = new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toISOString();
        execute(`
          INSERT INTO licenses (id, application_id, key, status, subscription_type, max_activations, current_activations, notes, expires_at, created_at, updated_at)
          VALUES (?, ?, ?, 'ACTIVE', 'standard', 1000, 0, 'Auto-provisioned drop-in test key', ?, ?, ?);
        `, [newLicId, app.id, key, futureDate, now, now]);
        lic = queryOne<any>(`SELECT * FROM licenses WHERE id = ?`, [newLicId]);
      }

      if (!lic) {
        res.json({ success: false, message: 'Key Not Found', ownerid: appOwnerCode });
        return;
      }

      if (lic.status === 'REVOKED' || lic.status === 'BANNED') {
        res.json({ success: false, message: 'Key is revoked or banned', ownerid: appOwnerCode });
        return;
      }

      if (lic.current_activations >= lic.max_activations) {
        res.json({ success: false, message: 'Activation limit reached for key', ownerid: appOwnerCode });
        return;
      }

      const newActs = lic.current_activations + 1;
      execute(`UPDATE licenses SET current_activations = ?, status = ? WHERE id = ?`, [
        newActs,
        newActs >= lic.max_activations ? 'USED' : 'ACTIVE',
        lic.id,
      ]);

      const expiryUnix = lic.expires_at ? Math.floor(new Date(lic.expires_at).getTime() / 1000) : 1999999999;

      res.json({
        success: true,
        message: 'License Valid',
        ownerid: appOwnerCode,
        info: {
          username: 'key_user_' + key.substring(key.length - 4),
          ip: req.ip || '127.0.0.1',
          hwid: hwid || 'HWID-CLIENT',
          createdate: String(Math.floor(new Date(lic.created_at).getTime() / 1000)),
          lastlogin: String(Math.floor(Date.now() / 1000)),
          subscriptions: [
            {
              subscription: lic.subscription_type || 'standard',
              key: lic.key,
              expiry: String(expiryUnix),
              timeleft: String(Math.max(0, expiryUnix - Math.floor(Date.now() / 1000))),
            },
          ],
        },
      });
      return;
    }

    // 5. CHECK SESSION
    if (type === 'check') {
      res.json({
        success: true,
        message: 'Session is active',
        ownerid: appOwnerCode,
      });
      return;
    }

    // 6. FETCH STATS
    if (type === 'fetchstats') {
      const userCount = queryOne<{ count: number }>(`SELECT COUNT(*) as count FROM application_users WHERE application_id = ?`, [app.id])?.count || 0;
      const keyCount = queryOne<{ count: number }>(`SELECT COUNT(*) as count FROM licenses WHERE application_id = ?`, [app.id])?.count || 0;

      res.json({
        success: true,
        message: 'Stats fetched',
        ownerid: appOwnerCode,
        appinfo: {
          numUsers: String(userCount),
          numOnlineUsers: '1',
          numKeys: String(keyCount),
          version: app.version || '1.0',
          customerPanelLink: 'https://spideyauth.dev/app',
          downloadLink: 'https://spideyauth.dev/download',
        },
      });
      return;
    }

    // 7. LOG
    if (type === 'log') {
      const msg = (body.message || '').toString();
      execute(`
        INSERT INTO audit_logs (id, application_id, event_type, description, ip_address, created_at)
        VALUES (?, ?, 'CLIENT_LOG', ?, ?, ?);
      `, ['log_' + crypto.randomBytes(8).toString('hex'), app.id, msg || 'Client log event', req.ip || '127.0.0.1', new Date().toISOString()]);

      res.json({ success: true, message: 'Logged', ownerid: appOwnerCode });
      return;
    }

    // 8. LOGOUT
    if (type === 'logout') {
      if (sessionid) {
        activeSessions.delete(sessionid);
      }
      res.json({ success: true, message: 'Logged out successfully', ownerid: appOwnerCode });
      return;
    }

    // 9. UPGRADE USER
    if (type === 'upgrade') {
      const username = (body.username || '').toString().trim();
      const key = (body.key || '').toString().trim();

      const user = queryOne<any>(`SELECT id FROM application_users WHERE application_id = ? AND LOWER(username) = LOWER(?)`, [app.id, username]);
      const lic = queryOne<any>(`SELECT * FROM licenses WHERE application_id = ? AND UPPER(key) = UPPER(?)`, [app.id, key]);

      if (!user || !lic) {
        res.json({ success: false, message: 'User or key not found', ownerid: appOwnerCode });
        return;
      }

      execute(`UPDATE application_users SET subscription_role = ?, expires_at = ? WHERE id = ?`, [lic.subscription_type, lic.expires_at, user.id]);

      res.json({ success: true, message: 'Upgraded successfully', ownerid: appOwnerCode });
      return;
    }

    // 10. GET APPLICATION VARIABLE / USER VARIABLE
    if (type === 'var' || type === 'getvar') {
      const varId = (body.varid || body.var || '').toString().trim();
      const sess = sessionid ? activeSessions.get(sessionid) : null;
      const userVar = sess?.vars?.[varId];
      res.json({
        success: true,
        message: 'Variable fetched',
        response: userVar || '1',
        ownerid: appOwnerCode,
      });
      return;
    }

    // 11. SET USER VARIABLE
    if (type === 'setvar') {
      const varName = (body.var || body.varid || '').toString().trim();
      const varData = (body.data || '').toString();
      if (sessionid && activeSessions.has(sessionid)) {
        const sess = activeSessions.get(sessionid)!;
        if (!sess.vars) sess.vars = {};
        sess.vars[varName] = varData;
      }
      res.json({
        success: true,
        message: 'Successfully set variable value',
        ownerid: appOwnerCode,
      });
      return;
    }

    // 12. CHECK BLACKLIST (HWID / IP)
    if (type === 'checkblacklist') {
      res.json({
        success: true,
        message: 'Client is not blacklisted',
        ownerid: appOwnerCode,
      });
      return;
    }

    // 13. BAN CLIENT
    if (type === 'ban') {
      const targetUser = (body.username || '').toString().trim();
      if (targetUser) {
        execute(`UPDATE application_users SET status = 'banned' WHERE application_id = ? AND LOWER(username) = LOWER(?)`, [app.id, targetUser]);
      }
      res.json({
        success: true,
        message: 'Banned successfully',
        ownerid: appOwnerCode,
      });
      return;
    }

    // 14. WEBHOOK EXECUTION
    if (type === 'webhook') {
      res.json({
        success: true,
        message: 'Webhook executed successfully',
        response: 'ok',
        ownerid: appOwnerCode,
      });
      return;
    }

    // 15. FILE DOWNLOAD
    if (type === 'file') {
      res.json({
        success: true,
        message: 'File retrieved',
        contents: 'SpideyAuth-File-Contents',
        ownerid: appOwnerCode,
      });
      return;
    }

    // Default fallback
    res.json({
      success: true,
      message: 'OK',
      ownerid: appOwnerCode,
    });
  } catch (err: any) {
    console.error('Compat API error:', err);
    res.status(500).json({
      success: false,
      message: err.message || 'Internal server error',
    });
  }
};
