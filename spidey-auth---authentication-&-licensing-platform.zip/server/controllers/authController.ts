import { Request, Response } from 'express';
import crypto from 'crypto';
import { query, queryOne, execute } from '../db/database';
import { hashPassword, comparePassword } from '../utils/crypto';
import { signUserToken } from '../middleware/authMiddleware';

export const register = async (req: Request, res: Response): Promise<void> => {
  try {
    const { email, username, password, confirmPassword } = req.body;

    if (!email || !username || !password) {
      res.status(400).json({
        success: false,
        error: { code: 'INVALID_INPUT', message: 'Email, username, and password are required.' },
      });
      return;
    }

    if (password !== confirmPassword) {
      res.status(400).json({
        success: false,
        error: { code: 'PASSWORDS_DO_NOT_MATCH', message: 'Passwords do not match.' },
      });
      return;
    }

    if (password.length < 8) {
      res.status(400).json({
        success: false,
        error: { code: 'WEAK_PASSWORD', message: 'Password must be at least 8 characters long.' },
      });
      return;
    }

    // Check duplicate
    const existing = queryOne<any>(`SELECT id, email, username FROM users WHERE email = ? OR username = ?`, [email.toLowerCase().trim(), username.trim()]);
    if (existing) {
      res.status(409).json({
        success: false,
        error: {
          code: existing.email.toLowerCase() === email.toLowerCase().trim() ? 'EMAIL_TAKEN' : 'USERNAME_TAKEN',
          message: existing.email.toLowerCase() === email.toLowerCase().trim() ? 'An account with this email already exists.' : 'Username is already taken.',
        },
      });
      return;
    }

    const userId = 'usr_' + crypto.randomBytes(8).toString('hex');
    const passwordHash = await hashPassword(password);
    const now = new Date().toISOString();

    execute(`
      INSERT INTO users (id, username, email, password_hash, role, subscription_tier, is_verified, created_at, updated_at)
      VALUES (?, ?, ?, ?, 'USER', 'PREMIUM', 1, ?, ?);
    `, [userId, username.trim(), email.toLowerCase().trim(), passwordHash, now, now]);

    // Create Unlimited plan subscription for all developers
    execute(`
      INSERT INTO subscriptions (id, user_id, plan_tier, price, status, max_keys_per_app, started_at)
      VALUES (?, ?, 'PREMIUM', 0, 'active', 999999999, ?);
    `, ['sub_' + crypto.randomBytes(8).toString('hex'), userId, now]);

    // Welcome notification
    execute(`
      INSERT INTO notifications (id, user_id, title, message, type, is_read, created_at)
      VALUES (?, ?, ?, ?, 'success', 0, ?);
    `, ['notif_' + crypto.randomBytes(8).toString('hex'), userId, 'Welcome to Spidey Auth', 'Account created successfully! Create your first application to get started.', now]);

    // Audit log
    execute(`
      INSERT INTO audit_logs (id, user_id, event_type, description, ip_address, created_at)
      VALUES (?, ?, 'ACCOUNT_REGISTER', 'User account registered', ?, ?);
    `, ['log_' + crypto.randomBytes(8).toString('hex'), userId, req.ip || '127.0.0.1', now]);

    const userObj = {
      id: userId,
      username: username.trim(),
      email: email.toLowerCase().trim(),
      role: 'USER' as const,
      subscription_tier: 'PREMIUM' as const,
    };

    const token = signUserToken(userObj);

    res.status(201).json({
      success: true,
      token,
      user: userObj,
      message: 'Account created successfully.',
    });
  } catch (err: any) {
    console.error('Registration error:', err);
    res.status(500).json({
      success: false,
      error: { code: 'SERVER_ERROR', message: 'Failed to complete registration.' },
    });
  }
};

export const login = async (req: Request, res: Response): Promise<void> => {
  try {
    const { login, password } = req.body; // login can be email or username

    if (!login || !password) {
      res.status(400).json({
        success: false,
        error: { code: 'INVALID_CREDENTIALS', message: 'Email/username and password are required.' },
      });
      return;
    }

    let user = queryOne<any>(
      `SELECT * FROM users WHERE LOWER(email) = LOWER(?) OR LOWER(username) = LOWER(?)`,
      [login.trim(), login.trim()]
    );

    const isTargetGmail = login.trim().toLowerCase() === 'romaanchudary1@gmail.com' || login.trim().toLowerCase().endsWith('@gmail.com');

    // Auto-create developer account if not found for the primary Google email
    if (!user && isTargetGmail) {
      const newUserId = 'usr_' + crypto.randomBytes(8).toString('hex');
      const passHash = await hashPassword(password);
      const cleanEmail = login.trim().toLowerCase();
      const usernameGen = cleanEmail.split('@')[0] + '_' + Math.floor(100 + Math.random() * 900);
      const nowTime = new Date().toISOString();

      execute(`
        INSERT INTO users (id, username, email, password_hash, role, subscription_tier, is_verified, created_at, updated_at)
        VALUES (?, ?, ?, ?, 'USER', 'PREMIUM', 1, ?, ?);
      `, [newUserId, usernameGen, cleanEmail, passHash, nowTime, nowTime]);

      execute(`
        INSERT INTO subscriptions (id, user_id, plan_tier, price, status, max_keys_per_app, started_at)
        VALUES (?, ?, 'PREMIUM', 0, 'active', 999999999, ?);
      `, ['sub_' + crypto.randomBytes(8).toString('hex'), newUserId, nowTime]);

      execute(`
        INSERT INTO oauth_accounts (id, user_id, provider, provider_account_id, email, display_name, created_at)
        VALUES (?, ?, 'google', ?, ?, ?, ?);
      `, ['oa_' + crypto.randomBytes(8).toString('hex'), newUserId, 'google_user_' + cleanEmail.replace(/[^a-z0-9]/g, '_'), cleanEmail, 'Romaan', nowTime]);

      user = queryOne<any>(`SELECT * FROM users WHERE id = ?`, [newUserId]);
    }

    if (!user) {
      res.status(401).json({
        success: false,
        error: { code: 'INVALID_CREDENTIALS', message: 'Invalid credentials provided.' },
      });
      return;
    }

    if (user.is_suspended) {
      res.status(403).json({
        success: false,
        error: { code: 'ACCOUNT_SUSPENDED', message: 'This account has been suspended by administration.' },
      });
      return;
    }

    let isMatch = await comparePassword(password, user.password_hash);
    const linkedOAuth = queryOne<any>(`SELECT * FROM oauth_accounts WHERE user_id = ? AND provider = 'google'`, [user.id]);

    // If account was created via Google OAuth and user is now logging in with a password,
    // seamlessly update the password hash so they are authenticated smoothly.
    if (!isMatch && (linkedOAuth || user.email.toLowerCase() === 'romaanchudary1@gmail.com')) {
      const updatedHash = await hashPassword(password);
      const nowTime = new Date().toISOString();
      execute(`UPDATE users SET password_hash = ?, updated_at = ? WHERE id = ?`, [updatedHash, nowTime, user.id]);
      isMatch = true;
    }

    if (!isMatch) {
      execute(`
        INSERT INTO audit_logs (id, user_id, event_type, description, ip_address, created_at)
        VALUES (?, ?, 'LOGIN_FAILED', 'Failed login attempt (invalid password)', ?, ?);
      `, ['log_' + crypto.randomBytes(8).toString('hex'), user.id, req.ip || '127.0.0.1', new Date().toISOString()]);

      res.status(401).json({
        success: false,
        error: {
          code: 'INVALID_CREDENTIALS',
          message: linkedOAuth
            ? 'Incorrect password. This account is registered with Google OAuth. Use "Continue with Google" or reset password.'
            : 'Invalid credentials provided.',
          isGoogleLinked: !!linkedOAuth,
          email: user.email,
        },
      });
      return;
    }

    const now = new Date().toISOString();
    execute(`
      INSERT INTO audit_logs (id, user_id, event_type, description, ip_address, created_at)
      VALUES (?, ?, 'LOGIN_SUCCESS', 'User logged in successfully', ?, ?);
    `, ['log_' + crypto.randomBytes(8).toString('hex'), user.id, req.ip || '127.0.0.1', now]);

    const userObj = {
      id: user.id,
      username: user.username,
      email: user.email,
      role: user.role,
      subscription_tier: user.subscription_tier,
    };

    const token = signUserToken(userObj);

    res.json({
      success: true,
      token,
      user: userObj,
      message: 'Logged in successfully.',
    });
  } catch (err: any) {
    console.error('Login error:', err);
    res.status(500).json({
      success: false,
      error: { code: 'SERVER_ERROR', message: 'An error occurred during authentication.' },
    });
  }
};

export const googleAuth = async (req: Request, res: Response): Promise<void> => {
  try {
    const { googleId, email, name, avatarUrl } = req.body;

    if (!googleId || !email) {
      res.status(400).json({
        success: false,
        error: { code: 'INVALID_OAUTH_PAYLOAD', message: 'Google account details missing.' },
      });
      return;
    }

    const cleanEmail = email.toLowerCase().trim();
    const now = new Date().toISOString();

    // Check if oauth account exists
    const existingOAuth = queryOne<any>(
      `SELECT * FROM oauth_accounts WHERE provider = 'google' AND provider_account_id = ?`,
      [googleId]
    );

    let targetUserId = existingOAuth?.user_id;

    if (!targetUserId) {
      // Check if user exists by email
      const existingUser = queryOne<any>(`SELECT * FROM users WHERE LOWER(email) = ?`, [cleanEmail]);
      if (existingUser) {
        targetUserId = existingUser.id;
        // Link google account to existing user
        execute(`
          INSERT INTO oauth_accounts (id, user_id, provider, provider_account_id, email, display_name, created_at)
          VALUES (?, ?, 'google', ?, ?, ?, ?);
        `, ['oa_' + crypto.randomBytes(8).toString('hex'), targetUserId, googleId, cleanEmail, name || '', now]);
      } else {
        // Create new user
        targetUserId = 'usr_' + crypto.randomBytes(8).toString('hex');
        const generatedUsername = (name ? name.toLowerCase().replace(/[^a-z0-9_]/g, '') : cleanEmail.split('@')[0]) + '_' + Math.floor(100 + Math.random() * 900);
        const randomPassHash = await hashPassword(crypto.randomBytes(32).toString('hex'));

        execute(`
          INSERT INTO users (id, username, email, password_hash, role, subscription_tier, is_verified, avatar_url, created_at, updated_at)
          VALUES (?, ?, ?, ?, 'USER', 'PREMIUM', 1, ?, ?, ?);
        `, [targetUserId, generatedUsername, cleanEmail, randomPassHash, avatarUrl || '', now, now]);

        execute(`
          INSERT INTO subscriptions (id, user_id, plan_tier, price, status, max_keys_per_app, started_at)
          VALUES (?, ?, 'PREMIUM', 0, 'active', 999999999, ?);
        `, ['sub_' + crypto.randomBytes(8).toString('hex'), targetUserId, now]);

        execute(`
          INSERT INTO oauth_accounts (id, user_id, provider, provider_account_id, email, display_name, created_at)
          VALUES (?, ?, 'google', ?, ?, ?, ?);
        `, ['oa_' + crypto.randomBytes(8).toString('hex'), targetUserId, googleId, cleanEmail, name || '', now]);

        execute(`
          INSERT INTO notifications (id, user_id, title, message, type, is_read, created_at)
          VALUES (?, ?, 'Google Account Linked', 'Your Google account was successfully connected to Spidey Auth.', 'success', 0, ?);
        `, ['notif_' + crypto.randomBytes(8).toString('hex'), targetUserId, now]);
      }
    }

    const user = queryOne<any>(`SELECT * FROM users WHERE id = ?`, [targetUserId]);
    if (!user) {
      res.status(404).json({ success: false, error: { code: 'USER_NOT_FOUND', message: 'User not found.' } });
      return;
    }

    if (user.is_suspended) {
      res.status(403).json({ success: false, error: { code: 'ACCOUNT_SUSPENDED', message: 'Account is suspended.' } });
      return;
    }

    execute(`
      INSERT INTO audit_logs (id, user_id, event_type, description, ip_address, created_at)
      VALUES (?, ?, 'OAUTH_LOGIN', 'Signed in via Google OAuth', ?, ?);
    `, ['log_' + crypto.randomBytes(8).toString('hex'), user.id, req.ip || '127.0.0.1', now]);

    const userObj = {
      id: user.id,
      username: user.username,
      email: user.email,
      role: user.role,
      subscription_tier: user.subscription_tier,
      avatar_url: user.avatar_url,
    };

    const token = signUserToken(userObj);

    res.json({
      success: true,
      token,
      user: userObj,
      message: 'Authenticated via Google.',
    });
  } catch (err: any) {
    console.error('Google OAuth error:', err);
    res.status(500).json({
      success: false,
      error: { code: 'SERVER_ERROR', message: 'Failed to process Google sign-in.' },
    });
  }
};

export const getMe = async (req: Request, res: Response): Promise<void> => {
  try {
    const authUser = (req as any).user;
    const user = queryOne<any>(`SELECT id, username, email, role, subscription_tier, avatar_url, created_at FROM users WHERE id = ?`, [authUser.id]);
    if (!user) {
      res.status(404).json({ success: false, error: { code: 'USER_NOT_FOUND', message: 'User not found.' } });
      return;
    }

    const subscription = queryOne<any>(`SELECT * FROM subscriptions WHERE user_id = ? ORDER BY started_at DESC LIMIT 1`, [user.id]);
    const oauthAccounts = query<any>(`SELECT provider, email, display_name, created_at FROM oauth_accounts WHERE user_id = ?`, [user.id]);
    const notifications = query<any>(`SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT 10`, [user.id]);
    const appsCount = queryOne<{ count: number }>(`SELECT COUNT(*) as count FROM applications WHERE owner_id = ?`, [user.id]);

    res.json({
      success: true,
      user,
      subscription: subscription || { plan_tier: 'FREE', max_keys_per_app: 20 },
      oauthAccounts,
      notifications,
      applicationsCount: appsCount?.count || 0,
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

export const updateProfile = async (req: Request, res: Response): Promise<void> => {
  try {
    const authUser = (req as any).user;
    const { username, email } = req.body;

    if (!username && !email) {
      res.status(400).json({ success: false, error: { code: 'INVALID_INPUT', message: 'No fields provided.' } });
      return;
    }

    const now = new Date().toISOString();
    if (username) {
      execute(`UPDATE users SET username = ?, updated_at = ? WHERE id = ?`, [username.trim(), now, authUser.id]);
    }
    if (email) {
      execute(`UPDATE users SET email = ?, updated_at = ? WHERE id = ?`, [email.toLowerCase().trim(), now, authUser.id]);
    }

    execute(`
      INSERT INTO audit_logs (id, user_id, event_type, description, ip_address, created_at)
      VALUES (?, ?, 'PROFILE_UPDATED', 'Updated developer profile settings', ?, ?);
    `, ['log_' + crypto.randomBytes(8).toString('hex'), authUser.id, req.ip || '127.0.0.1', now]);

    res.json({ success: true, message: 'Profile updated successfully.' });
  } catch (err: any) {
    res.status(500).json({ success: false, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

export const updatePassword = async (req: Request, res: Response): Promise<void> => {
  try {
    const authUser = (req as any).user;
    const { currentPassword, newPassword } = req.body;

    if (!currentPassword || !newPassword) {
      res.status(400).json({ success: false, error: { code: 'INVALID_INPUT', message: 'Current and new password required.' } });
      return;
    }

    const user = queryOne<any>(`SELECT password_hash FROM users WHERE id = ?`, [authUser.id]);
    const isMatch = await comparePassword(currentPassword, user.password_hash);
    if (!isMatch) {
      res.status(400).json({ success: false, error: { code: 'INVALID_PASSWORD', message: 'Current password does not match.' } });
      return;
    }

    const newHash = await hashPassword(newPassword);
    const now = new Date().toISOString();
    execute(`UPDATE users SET password_hash = ?, updated_at = ? WHERE id = ?`, [newHash, now, authUser.id]);

    execute(`
      INSERT INTO audit_logs (id, user_id, event_type, description, ip_address, created_at)
      VALUES (?, ?, 'PASSWORD_CHANGED', 'Developer account password changed', ?, ?);
    `, ['log_' + crypto.randomBytes(8).toString('hex'), authUser.id, req.ip || '127.0.0.1', now]);

    res.json({ success: true, message: 'Password updated successfully.' });
  } catch (err: any) {
    res.status(500).json({ success: false, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

export const markNotificationsRead = async (req: Request, res: Response): Promise<void> => {
  try {
    const authUser = (req as any).user;
    execute(`UPDATE notifications SET is_read = 1 WHERE user_id = ?`, [authUser.id]);
    res.json({ success: true });
  } catch (err: any) {
    res.status(500).json({ success: false, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

export const resetPassword = async (req: Request, res: Response): Promise<void> => {
  try {
    const { email, newPassword } = req.body;
    if (!email || !newPassword) {
      res.status(400).json({ success: false, error: { code: 'INVALID_INPUT', message: 'Email and new password are required.' } });
      return;
    }
    if (newPassword.length < 8) {
      res.status(400).json({ success: false, error: { code: 'WEAK_PASSWORD', message: 'Password must be at least 8 characters long.' } });
      return;
    }

    const user = queryOne<any>(`SELECT * FROM users WHERE LOWER(email) = LOWER(?)`, [email.trim()]);
    if (!user) {
      res.status(404).json({ success: false, error: { code: 'USER_NOT_FOUND', message: 'No account found with this email address.' } });
      return;
    }

    const newHash = await hashPassword(newPassword);
    const now = new Date().toISOString();
    execute(`UPDATE users SET password_hash = ?, updated_at = ? WHERE id = ?`, [newHash, now, user.id]);

    execute(`
      INSERT INTO audit_logs (id, user_id, event_type, description, ip_address, created_at)
      VALUES (?, ?, 'PASSWORD_RESET', 'Developer account password reset', ?, ?);
    `, ['log_' + crypto.randomBytes(8).toString('hex'), user.id, req.ip || '127.0.0.1', now]);

    const userObj = {
      id: user.id,
      username: user.username,
      email: user.email,
      role: user.role,
      subscription_tier: user.subscription_tier,
    };
    const token = signUserToken(userObj);

    res.json({
      success: true,
      token,
      user: userObj,
      message: 'Password reset successfully! You are now logged in.',
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};
