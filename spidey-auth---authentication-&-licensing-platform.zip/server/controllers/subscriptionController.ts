import { Request, Response } from 'express';
import crypto from 'crypto';
import { queryOne, execute } from '../db/database';

export const getSubscription = async (req: Request, res: Response): Promise<void> => {
  try {
    const authUser = (req as any).user;
    const sub = queryOne<any>(
      `SELECT * FROM subscriptions WHERE user_id = ? ORDER BY started_at DESC LIMIT 1`,
      [authUser.id]
    );

    res.json({
      success: true,
      subscription: {
        plan_tier: 'UNLIMITED',
        price: 0,
        status: 'active',
        max_keys_per_app: 999999999,
      },
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

export const upgradeSubscription = async (req: Request, res: Response): Promise<void> => {
  try {
    const authUser = (req as any).user;
    const { paymentMethod = 'credit_card' } = req.body;
    const now = new Date().toISOString();
    const renewsAt = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString();

    // Update user record
    execute(
      `UPDATE users SET subscription_tier = 'PREMIUM', subscription_status = 'active', subscription_expires_at = ?, updated_at = ? WHERE id = ?`,
      [renewsAt, now, authUser.id]
    );

    // Update or insert subscription
    const existing = queryOne<any>(`SELECT id FROM subscriptions WHERE user_id = ?`, [authUser.id]);
    if (existing) {
      execute(
        `UPDATE subscriptions SET plan_tier = 'PREMIUM', price = 29.00, status = 'active', max_keys_per_app = 100000, started_at = ?, renews_at = ? WHERE id = ?`,
        [now, renewsAt, existing.id]
      );
    } else {
      execute(
        `INSERT INTO subscriptions (id, user_id, plan_tier, price, status, max_keys_per_app, started_at, renews_at)
         VALUES (?, ?, 'PREMIUM', 29.00, 'active', 100000, ?, ?);`,
        ['sub_' + crypto.randomBytes(8).toString('hex'), authUser.id, now, renewsAt]
      );
    }

    // Add audit log
    execute(`
      INSERT INTO audit_logs (id, user_id, event_type, description, ip_address, created_at)
      VALUES (?, ?, 'SUBSCRIPTION_UPGRADED', 'Upgraded to Spidey Auth Premium Plan', ?, ?);
    `, ['log_' + crypto.randomBytes(8).toString('hex'), authUser.id, req.ip || '127.0.0.1', now]);

    // Send in-app notification
    execute(`
      INSERT INTO notifications (id, user_id, title, message, type, is_read, created_at)
      VALUES (?, ?, 'Welcome to Premium!', 'You now have unlimited keys per app, priority API bandwidth, and advanced analytics.', 'success', 0, ?);
    `, ['notif_' + crypto.randomBytes(8).toString('hex'), authUser.id, now]);

    res.json({
      success: true,
      message: 'Successfully upgraded to Premium Plan!',
      subscription: {
        plan_tier: 'PREMIUM',
        price: 29.0,
        status: 'active',
        max_keys_per_app: 100000,
        renews_at: renewsAt,
      },
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

export const downgradeSubscription = async (req: Request, res: Response): Promise<void> => {
  try {
    const authUser = (req as any).user;
    const now = new Date().toISOString();

    execute(
      `UPDATE users SET subscription_tier = 'FREE', subscription_status = 'active', subscription_expires_at = NULL, updated_at = ? WHERE id = ?`,
      [now, authUser.id]
    );

    execute(
      `UPDATE subscriptions SET plan_tier = 'FREE', price = 0, status = 'active', max_keys_per_app = 20, started_at = ?, renews_at = NULL WHERE user_id = ?`,
      [now, authUser.id]
    );

    execute(`
      INSERT INTO audit_logs (id, user_id, event_type, description, ip_address, created_at)
      VALUES (?, ?, 'SUBSCRIPTION_DOWNGRADED', 'Switched back to Free Tier', ?, ?);
    `, ['log_' + crypto.randomBytes(8).toString('hex'), authUser.id, req.ip || '127.0.0.1', now]);

    res.json({
      success: true,
      message: 'Plan changed to Free Tier.',
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};
