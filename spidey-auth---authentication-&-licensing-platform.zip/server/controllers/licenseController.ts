import { Request, Response } from 'express';
import crypto from 'crypto';
import { query, queryOne, execute } from '../db/database';
import { generateLicenseKey } from '../utils/crypto';

// ==========================================
// DEVELOPER MANAGEMENT OF LICENSES
// ==========================================

export const listApplicationLicenses = async (req: Request, res: Response): Promise<void> => {
  try {
    const authUser = (req as any).user;
    const { appId } = req.params;
    const { search, status, type, page = '1', limit = '10' } = req.query;

    const app = queryOne<any>(`SELECT id FROM applications WHERE id = ? AND owner_id = ?`, [appId, authUser.id]);
    if (!app) {
      res.status(404).json({ success: false, error: { code: 'NOT_FOUND', message: 'Application not found or unauthorized.' } });
      return;
    }

    let sql = `SELECT * FROM licenses WHERE application_id = ?`;
    const params: any[] = [appId];

    if (search) {
      sql += ` AND (LOWER(key) LIKE ? OR LOWER(notes) LIKE ?)`;
      const term = `%${String(search).toLowerCase()}%`;
      params.push(term, term);
    }

    if (status && status !== 'all') {
      sql += ` AND status = ?`;
      params.push(status);
    }

    if (type && type !== 'all') {
      sql += ` AND subscription_type = ?`;
      params.push(type);
    }

    const countSql = sql.replace('SELECT *', 'SELECT COUNT(*) as total');
    const totalCount = queryOne<{ total: number }>(countSql, params);

    const pageNum = Math.max(1, parseInt(page as string, 10) || 1);
    const limitNum = Math.min(100, Math.max(1, parseInt(limit as string, 10) || 10));
    const offset = (pageNum - 1) * limitNum;

    sql += ` ORDER BY created_at DESC LIMIT ? OFFSET ?`;
    params.push(limitNum, offset);

    const licenses = query<any>(sql, params);

    // Get current total keys for Free plan limit indicator
    const currentTotal = queryOne<{ count: number }>(`SELECT COUNT(*) as count FROM licenses WHERE application_id = ?`, [appId]);

    res.json({
      success: true,
      licenses,
      totalKeysInApp: currentTotal?.count || 0,
      pagination: {
        page: pageNum,
        limit: limitNum,
        total: totalCount?.total || 0,
        pages: Math.ceil((totalCount?.total || 0) / limitNum),
      },
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

export const generateSingleLicense = async (req: Request, res: Response): Promise<void> => {
  try {
    const authUser = (req as any).user;
    const { appId } = req.params;
    const { prefix = 'SPIDEY', subscriptionType = 'standard', maxActivations = 1, expiresAt, notes } = req.body;

    const app = queryOne<any>(`SELECT id, name FROM applications WHERE id = ? AND owner_id = ?`, [appId, authUser.id]);
    if (!app) {
      res.status(404).json({ success: false, error: { code: 'NOT_FOUND', message: 'Application not found or unauthorized.' } });
      return;
    }

    // Unlimited keys for all developers - no subscription limits enforced
    const key = generateLicenseKey(prefix?.toUpperCase().replace(/[^A-Z0-9]/g, '') || 'SPIDEY');
    const licId = 'lic_' + crypto.randomBytes(8).toString('hex');
    const now = new Date().toISOString();

    execute(`
      INSERT INTO licenses (id, application_id, key, status, subscription_type, max_activations, current_activations, notes, expires_at, created_at, updated_at)
      VALUES (?, ?, ?, 'ACTIVE', ?, ?, 0, ?, ?, ?, ?);
    `, [
      licId,
      appId,
      key,
      subscriptionType,
      Math.max(1, parseInt(maxActivations, 10) || 1),
      notes?.trim() || '',
      expiresAt || null,
      now,
      now,
    ]);

    execute(`
      INSERT INTO audit_logs (id, user_id, application_id, event_type, description, ip_address, created_at)
      VALUES (?, ?, ?, 'LICENSE_GENERATED', ?, ?, ?);
    `, ['log_' + crypto.randomBytes(8).toString('hex'), authUser.id, appId, `Generated license key ${key}`, req.ip || '127.0.0.1', now]);

    res.status(201).json({
      success: true,
      message: 'License generated successfully.',
      license: {
        id: licId,
        application_id: appId,
        key,
        status: 'ACTIVE',
        subscription_type: subscriptionType,
        max_activations: Math.max(1, parseInt(maxActivations, 10) || 1),
        current_activations: 0,
        notes: notes?.trim() || '',
        expires_at: expiresAt || null,
        created_at: now,
      },
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

export const generateBulkLicenses = async (req: Request, res: Response): Promise<void> => {
  try {
    const authUser = (req as any).user;
    const { appId } = req.params;
    const { count = 5, prefix = 'SPIDEY', subscriptionType = 'standard', maxActivations = 1, expiresAt, notes } = req.body;

    const app = queryOne<any>(`SELECT id, name FROM applications WHERE id = ? AND owner_id = ?`, [appId, authUser.id]);
    if (!app) {
      res.status(404).json({ success: false, error: { code: 'NOT_FOUND', message: 'Application not found or unauthorized.' } });
      return;
    }

    const requestedCount = Math.min(100, Math.max(1, parseInt(count, 10) || 1));

    // Unlimited keys for all developers - no plan limits
    const createdKeys: any[] = [];
    const now = new Date().toISOString();

    for (let i = 0; i < requestedCount; i++) {
      const key = generateLicenseKey(prefix?.toUpperCase().replace(/[^A-Z0-9]/g, '') || 'SPIDEY');
      const licId = 'lic_' + crypto.randomBytes(8).toString('hex');

      execute(`
        INSERT INTO licenses (id, application_id, key, status, subscription_type, max_activations, current_activations, notes, expires_at, created_at, updated_at)
        VALUES (?, ?, ?, 'ACTIVE', ?, ?, 0, ?, ?, ?, ?);
      `, [
        licId,
        appId,
        key,
        subscriptionType,
        Math.max(1, parseInt(maxActivations, 10) || 1),
        notes?.trim() || '',
        expiresAt || null,
        now,
        now,
      ]);

      createdKeys.push({
        id: licId,
        key,
        subscription_type: subscriptionType,
        max_activations: Math.max(1, parseInt(maxActivations, 10) || 1),
      });
    }

    execute(`
      INSERT INTO audit_logs (id, user_id, application_id, event_type, description, ip_address, created_at)
      VALUES (?, ?, ?, 'KEYS_GENERATED', ?, ?, ?);
    `, ['log_' + crypto.randomBytes(8).toString('hex'), authUser.id, appId, `Bulk generated ${requestedCount} licenses`, req.ip || '127.0.0.1', now]);

    res.status(201).json({
      success: true,
      message: `Generated ${requestedCount} licenses successfully.`,
      count: requestedCount,
      keys: createdKeys,
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

export const updateLicense = async (req: Request, res: Response): Promise<void> => {
  try {
    const authUser = (req as any).user;
    const { appId, licenseId } = req.params;
    const { status, subscriptionType, maxActivations, expiresAt, notes } = req.body;

    const app = queryOne<any>(`SELECT id FROM applications WHERE id = ? AND owner_id = ?`, [appId, authUser.id]);
    if (!app) {
      res.status(404).json({ success: false, error: { code: 'NOT_FOUND', message: 'Application not found or unauthorized.' } });
      return;
    }

    const lic = queryOne<any>(`SELECT * FROM licenses WHERE id = ? AND application_id = ?`, [licenseId, appId]);
    if (!lic) {
      res.status(404).json({ success: false, error: { code: 'NOT_FOUND', message: 'License not found.' } });
      return;
    }

    const now = new Date().toISOString();
    execute(`
      UPDATE licenses
      SET status = COALESCE(?, status),
          subscription_type = COALESCE(?, subscription_type),
          max_activations = COALESCE(?, max_activations),
          expires_at = COALESCE(?, expires_at),
          notes = COALESCE(?, notes),
          updated_at = ?
      WHERE id = ? AND application_id = ?;
    `, [
      status || null,
      subscriptionType || null,
      maxActivations ? parseInt(maxActivations, 10) : null,
      expiresAt !== undefined ? expiresAt : null,
      notes !== undefined ? notes.trim() : null,
      now,
      licenseId,
      appId,
    ]);

    execute(`
      INSERT INTO audit_logs (id, user_id, application_id, event_type, description, ip_address, created_at)
      VALUES (?, ?, ?, 'LICENSE_UPDATED', ?, ?, ?);
    `, ['log_' + crypto.randomBytes(8).toString('hex'), authUser.id, appId, `Updated license ${lic.key}`, req.ip || '127.0.0.1', now]);

    res.json({ success: true, message: 'License updated successfully.' });
  } catch (err: any) {
    res.status(500).json({ success: false, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

export const deleteLicense = async (req: Request, res: Response): Promise<void> => {
  try {
    const authUser = (req as any).user;
    const { appId, licenseId } = req.params;

    const app = queryOne<any>(`SELECT id FROM applications WHERE id = ? AND owner_id = ?`, [appId, authUser.id]);
    if (!app) {
      res.status(404).json({ success: false, error: { code: 'NOT_FOUND', message: 'Application not found or unauthorized.' } });
      return;
    }

    const lic = queryOne<any>(`SELECT key FROM licenses WHERE id = ? AND application_id = ?`, [licenseId, appId]);
    if (!lic) {
      res.status(404).json({ success: false, error: { code: 'NOT_FOUND', message: 'License not found.' } });
      return;
    }

    execute(`DELETE FROM licenses WHERE id = ? AND application_id = ?`, [licenseId, appId]);

    const now = new Date().toISOString();
    execute(`
      INSERT INTO audit_logs (id, user_id, application_id, event_type, description, ip_address, created_at)
      VALUES (?, ?, ?, 'LICENSE_DELETED', ?, ?, ?);
    `, ['log_' + crypto.randomBytes(8).toString('hex'), authUser.id, appId, `Deleted license ${lic.key}`, req.ip || '127.0.0.1', now]);

    res.json({ success: true, message: 'License deleted successfully.' });
  } catch (err: any) {
    res.status(500).json({ success: false, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

// ==========================================
// DEVELOPER APPLICATION CLIENT / SDK API
// ==========================================

export const apiActivateLicense = async (req: Request, res: Response): Promise<void> => {
  const startTime = Date.now();
  try {
    const app = (req as any).clientApp;
    const { licenseKey, hwid, username } = req.body;

    if (!licenseKey) {
      res.status(400).json({
        success: false,
        error: { code: 'MISSING_FIELDS', message: 'License key is required.' },
      });
      return;
    }

    const lic = queryOne<any>(
      `SELECT * FROM licenses WHERE application_id = ? AND UPPER(key) = UPPER(?)`,
      [app.id, licenseKey.trim()]
    );

    if (!lic) {
      recordApiRequest(app.id, '/api/license/activate', 'POST', 404, Date.now() - startTime, req.ip);
      res.status(404).json({
        success: false,
        error: { code: 'INVALID_LICENSE', message: 'The license key is invalid.' },
      });
      return;
    }

    if (lic.status === 'REVOKED') {
      recordApiRequest(app.id, '/api/license/activate', 'POST', 403, Date.now() - startTime, req.ip);
      res.status(403).json({
        success: false,
        error: { code: 'REVOKED_LICENSE', message: 'This license key has been revoked.' },
      });
      return;
    }

    if (lic.status === 'BANNED') {
      recordApiRequest(app.id, '/api/license/activate', 'POST', 403, Date.now() - startTime, req.ip);
      res.status(403).json({
        success: false,
        error: { code: 'BANNED_LICENSE', message: 'This license key is banned.' },
      });
      return;
    }

    if (lic.expires_at) {
      const expiry = new Date(lic.expires_at).getTime();
      if (expiry < Date.now()) {
        recordApiRequest(app.id, '/api/license/activate', 'POST', 403, Date.now() - startTime, req.ip);
        res.status(403).json({
          success: false,
          error: { code: 'EXPIRED_LICENSE', message: 'This license key has expired.' },
        });
        return;
      }
    }

    if (lic.current_activations >= lic.max_activations) {
      recordApiRequest(app.id, '/api/license/activate', 'POST', 403, Date.now() - startTime, req.ip);
      res.status(403).json({
        success: false,
        error: { code: 'ACTIVATION_LIMIT_REACHED', message: 'License activation limit reached.' },
      });
      return;
    }

    const now = new Date().toISOString();
    const newActivations = lic.current_activations + 1;
    const newStatus = newActivations >= lic.max_activations ? 'USED' : 'ACTIVE';

    execute(
      `UPDATE licenses SET current_activations = ?, status = ?, updated_at = ? WHERE id = ?`,
      [newActivations, newStatus, now, lic.id]
    );

    const actId = 'act_' + crypto.randomBytes(8).toString('hex');
    execute(
      `INSERT INTO license_activations (id, license_id, application_id, client_identifier, ip_address, username, activated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?);`,
      [actId, lic.id, app.id, hwid || 'CLIENT_DEVICE', req.ip || '127.0.0.1', username || '', now]
    );

    recordApiRequest(app.id, '/api/license/activate', 'POST', 200, Date.now() - startTime, req.ip);

    // Audit log
    execute(`
      INSERT INTO audit_logs (id, application_id, event_type, description, ip_address, created_at)
      VALUES (?, ?, 'LICENSE_ACTIVATED', ?, ?, ?);
    `, ['log_' + crypto.randomBytes(8).toString('hex'), app.id, `License key ${lic.key} activated`, req.ip || '127.0.0.1', now]);

    res.json({
      success: true,
      message: 'License activated successfully.',
      license: {
        status: 'active',
        subscriptionType: lic.subscription_type,
        activations: newActivations,
        maxActivations: lic.max_activations,
        expires: lic.expires_at,
        activatedAt: now,
      },
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

export const apiValidateLicense = async (req: Request, res: Response): Promise<void> => {
  const startTime = Date.now();
  try {
    const app = (req as any).clientApp;
    const { licenseKey } = req.body;

    if (!licenseKey) {
      res.status(400).json({
        success: false,
        error: { code: 'MISSING_FIELDS', message: 'License key is required.' },
      });
      return;
    }

    const lic = queryOne<any>(
      `SELECT * FROM licenses WHERE application_id = ? AND UPPER(key) = UPPER(?)`,
      [app.id, licenseKey.trim()]
    );

    if (!lic) {
      recordApiRequest(app.id, '/api/license/validate', 'POST', 404, Date.now() - startTime, req.ip);
      res.status(404).json({
        success: false,
        error: { code: 'INVALID_LICENSE', message: 'License key is invalid.' },
      });
      return;
    }

    if (lic.status === 'REVOKED') {
      recordApiRequest(app.id, '/api/license/validate', 'POST', 403, Date.now() - startTime, req.ip);
      res.status(403).json({
        success: false,
        error: { code: 'REVOKED_LICENSE', message: 'License is revoked.' },
      });
      return;
    }

    if (lic.status === 'BANNED') {
      recordApiRequest(app.id, '/api/license/validate', 'POST', 403, Date.now() - startTime, req.ip);
      res.status(403).json({
        success: false,
        error: { code: 'BANNED_LICENSE', message: 'License is banned.' },
      });
      return;
    }

    let isExpired = false;
    if (lic.expires_at) {
      const expiry = new Date(lic.expires_at).getTime();
      if (expiry < Date.now()) {
        isExpired = true;
      }
    }

    recordApiRequest(app.id, '/api/license/validate', 'POST', 200, Date.now() - startTime, req.ip);

    res.json({
      success: true,
      valid: !isExpired && lic.status !== 'REVOKED' && lic.status !== 'BANNED',
      license: {
        key: lic.key,
        status: isExpired ? 'EXPIRED' : lic.status,
        subscriptionType: lic.subscription_type,
        currentActivations: lic.current_activations,
        maxActivations: lic.max_activations,
        expires: lic.expires_at,
      },
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

export const apiRevokeLicense = async (req: Request, res: Response): Promise<void> => {
  const startTime = Date.now();
  try {
    const app = (req as any).clientApp;
    const { licenseKey } = req.body;

    if (!licenseKey) {
      res.status(400).json({ success: false, error: { code: 'MISSING_FIELDS', message: 'License key is required.' } });
      return;
    }

    const lic = queryOne<any>(
      `SELECT * FROM licenses WHERE application_id = ? AND UPPER(key) = UPPER(?)`,
      [app.id, licenseKey.trim()]
    );

    if (!lic) {
      res.status(404).json({ success: false, error: { code: 'INVALID_LICENSE', message: 'License not found.' } });
      return;
    }

    const now = new Date().toISOString();
    execute(`UPDATE licenses SET status = 'REVOKED', updated_at = ? WHERE id = ?`, [now, lic.id]);

    recordApiRequest(app.id, '/api/license/revoke', 'POST', 200, Date.now() - startTime, req.ip);

    execute(`
      INSERT INTO audit_logs (id, application_id, event_type, description, ip_address, created_at)
      VALUES (?, ?, 'LICENSE_REVOKED', ?, ?, ?);
    `, ['log_' + crypto.randomBytes(8).toString('hex'), app.id, `License ${lic.key} revoked via API`, req.ip || '127.0.0.1', now]);

    res.json({ success: true, message: 'License revoked successfully.' });
  } catch (err: any) {
    res.status(500).json({ success: false, error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

function recordApiRequest(appId: string, endpoint: string, method: string, statusCode: number, responseTimeMs: number, ip?: string): void {
  try {
    execute(`
      INSERT INTO api_requests (id, application_id, endpoint, method, status_code, response_time_ms, ip_address, created_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?);
    `, ['req_' + crypto.randomBytes(8).toString('hex'), appId, endpoint, method, statusCode, responseTimeMs, ip || '127.0.0.1', new Date().toISOString()]);
  } catch (e) {
    console.error('Failed to record API request log', e);
  }
}
