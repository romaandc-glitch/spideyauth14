import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';
import { queryOne, execute } from '../db/database';
import { comparePassword } from '../utils/crypto';

const JWT_SECRET = process.env.JWT_SECRET || 'spidey-auth-jwt-super-secret-key-production';

export interface AuthenticatedUser {
  id: string;
  username: string;
  email: string;
  role: 'USER' | 'ADMIN';
  subscription_tier: 'FREE' | 'PREMIUM';
}

export interface AppAuthContext {
  id: string;
  owner_id: string;
  name: string;
  version: string;
  status: string;
}

export function signUserToken(user: AuthenticatedUser): string {
  return jwt.sign(
    {
      id: user.id,
      username: user.username,
      email: user.email,
      role: user.role,
      subscription_tier: user.subscription_tier,
    },
    JWT_SECRET,
    { expiresIn: '7d' }
  );
}

// Middleware for Spidey Auth Developer/Admin sessions
export function requireAuth(req: Request, res: Response, next: NextFunction): void {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    res.status(401).json({
      success: false,
      error: { code: 'UNAUTHORIZED', message: 'Authentication required. Please log in.' },
    });
    return;
  }

  const token = authHeader.substring(7);
  try {
    const decoded = jwt.verify(token, JWT_SECRET) as AuthenticatedUser;
    
    // Check if user is still active in DB
    const dbUser = queryOne<any>(`SELECT id, username, email, role, subscription_tier, is_suspended FROM users WHERE id = ?`, [decoded.id]);
    if (!dbUser) {
      res.status(401).json({
        success: false,
        error: { code: 'USER_NOT_FOUND', message: 'User account not found.' },
      });
      return;
    }

    if (dbUser.is_suspended) {
      res.status(403).json({
        success: false,
        error: { code: 'ACCOUNT_SUSPENDED', message: 'This developer account has been suspended by administration.' },
      });
      return;
    }

    (req as any).user = {
      id: dbUser.id,
      username: dbUser.username,
      email: dbUser.email,
      role: dbUser.role,
      subscription_tier: dbUser.subscription_tier,
    };
    next();
  } catch (err) {
    res.status(401).json({
      success: false,
      error: { code: 'INVALID_TOKEN', message: 'Session expired or invalid token.' },
    });
  }
}

// Middleware for Admin role protection
export function requireAdmin(req: Request, res: Response, next: NextFunction): void {
  requireAuth(req, res, () => {
    const user = (req as any).user as AuthenticatedUser;
    if (user.role !== 'ADMIN') {
      res.status(403).json({
        success: false,
        error: { code: 'FORBIDDEN', message: 'Administrator privileges required.' },
      });
      return;
    }
    next();
  });
}

// Middleware for SDK Application authentication
export async function requireAppAuth(req: Request, res: Response, next: NextFunction): Promise<void> {
  const appId = req.headers['x-application-id'] || req.body?.applicationId || req.query?.applicationId;
  const appSecret = req.headers['x-application-secret'] || req.body?.applicationSecret;

  if (!appId || !appSecret) {
    res.status(400).json({
      success: false,
      error: {
        code: 'MISSING_CREDENTIALS',
        message: 'Application ID and Application Secret are required.',
      },
    });
    return;
  }

  const app = queryOne<any>(`SELECT * FROM applications WHERE id = ?`, [appId]);
  if (!app) {
    res.status(404).json({
      success: false,
      error: { code: 'APPLICATION_NOT_FOUND', message: 'Application ID not recognized.' },
    });
    return;
  }

  if (app.status !== 'ACTIVE') {
    res.status(403).json({
      success: false,
      error: { code: 'APPLICATION_DISABLED', message: 'This application is currently disabled by its owner or administrator.' },
    });
    return;
  }

  // Verify secret against active secrets
  const secrets = queryOne<any>(`SELECT * FROM application_secrets WHERE application_id = ? AND is_revoked = 0 ORDER BY created_at DESC LIMIT 1`, [appId]);
  if (!secrets) {
    res.status(401).json({
      success: false,
      error: { code: 'INVALID_APPLICATION_SECRET', message: 'No valid secret found for application.' },
    });
    return;
  }

  const isValidSecret = await comparePassword(String(appSecret), secrets.secret_hash);
  if (!isValidSecret) {
    res.status(401).json({
      success: false,
      error: { code: 'INVALID_APPLICATION_SECRET', message: 'The provided application secret is incorrect.' },
    });
    return;
  }

  (req as any).clientApp = app;
  next();
}
