import { Request, Response, NextFunction } from 'express';

interface RateLimitRecord {
  count: number;
  resetAt: number;
}

const ipBuckets = new Map<string, RateLimitRecord>();

// Clean up stale buckets periodically
setInterval(() => {
  const now = Date.now();
  for (const [key, record] of ipBuckets.entries()) {
    if (record.resetAt <= now) {
      ipBuckets.delete(key);
    }
  }
}, 60000);

export function rateLimiter(limit = 60, windowMs = 60000) {
  return (req: Request, res: Response, next: NextFunction): void => {
    const ip = (req.headers['x-forwarded-for'] as string) || req.socket.remoteAddress || '127.0.0.1';
    const key = `${ip}:${req.baseUrl}${req.path}`;
    const now = Date.now();

    const record = ipBuckets.get(key);

    if (!record || record.resetAt <= now) {
      ipBuckets.set(key, { count: 1, resetAt: now + windowMs });
      next();
      return;
    }

    if (record.count >= limit) {
      res.status(429).json({
        success: false,
        error: {
          code: 'RATE_LIMITED',
          message: 'Rate limit exceeded. Please wait before making additional requests.',
          retryAfterMs: Math.max(0, record.resetAt - now),
        },
      });
      return;
    }

    record.count++;
    next();
  };
}
