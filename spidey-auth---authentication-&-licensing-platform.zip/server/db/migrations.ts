import { query, queryOne, execute, saveDatabase } from './database';
import { hashPassword, generateApplicationId, generateRandomSecret, maskSecret, generateLicenseKey } from '../utils/crypto';

export async function runMigrations(): Promise<void> {
  console.log('[MIGRATIONS] Checking and applying database schemas...');

  // 1. Users table
  execute(`
    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      username TEXT UNIQUE NOT NULL,
      email TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL,
      role TEXT NOT NULL DEFAULT 'USER',
      subscription_tier TEXT NOT NULL DEFAULT 'FREE',
      subscription_status TEXT NOT NULL DEFAULT 'active',
      subscription_expires_at TEXT,
      is_verified INTEGER NOT NULL DEFAULT 1,
      is_suspended INTEGER NOT NULL DEFAULT 0,
      avatar_url TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );
  `);

  // 2. OAuth accounts
  execute(`
    CREATE TABLE IF NOT EXISTS oauth_accounts (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      provider TEXT NOT NULL,
      provider_account_id TEXT NOT NULL,
      email TEXT NOT NULL,
      display_name TEXT,
      created_at TEXT NOT NULL,
      UNIQUE(provider, provider_account_id)
    );
  `);

  // 3. Applications
  execute(`
    CREATE TABLE IF NOT EXISTS applications (
      id TEXT PRIMARY KEY,
      owner_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      owner_code TEXT NOT NULL,
      name TEXT NOT NULL,
      description TEXT DEFAULT '',
      version TEXT DEFAULT '1.0.0',
      status TEXT NOT NULL DEFAULT 'ACTIVE',
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );
  `);

  // 4. Application Secrets
  execute(`
    CREATE TABLE IF NOT EXISTS application_secrets (
      id TEXT PRIMARY KEY,
      application_id TEXT NOT NULL REFERENCES applications(id) ON DELETE CASCADE,
      secret_hash TEXT NOT NULL,
      secret_masked TEXT NOT NULL,
      secret_raw TEXT NOT NULL,
      is_revoked INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL
    );
  `);

  // 5. Application Users (End-users managed by developers)
  execute(`
    CREATE TABLE IF NOT EXISTS application_users (
      id TEXT PRIMARY KEY,
      application_id TEXT NOT NULL REFERENCES applications(id) ON DELETE CASCADE,
      username TEXT NOT NULL,
      password_hash TEXT NOT NULL,
      email TEXT DEFAULT '',
      status TEXT NOT NULL DEFAULT 'active',
      subscription_role TEXT DEFAULT 'default',
      expires_at TEXT,
      notes TEXT DEFAULT '',
      last_login_at TEXT,
      last_ip TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      UNIQUE(application_id, username)
    );
  `);

  // 6. Licenses
  execute(`
    CREATE TABLE IF NOT EXISTS licenses (
      id TEXT PRIMARY KEY,
      application_id TEXT NOT NULL REFERENCES applications(id) ON DELETE CASCADE,
      key TEXT UNIQUE NOT NULL,
      status TEXT NOT NULL DEFAULT 'ACTIVE',
      subscription_type TEXT DEFAULT 'standard',
      max_activations INTEGER NOT NULL DEFAULT 1,
      current_activations INTEGER NOT NULL DEFAULT 0,
      notes TEXT DEFAULT '',
      expires_at TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );
  `);

  // 7. License Activations
  execute(`
    CREATE TABLE IF NOT EXISTS license_activations (
      id TEXT PRIMARY KEY,
      license_id TEXT NOT NULL REFERENCES licenses(id) ON DELETE CASCADE,
      application_id TEXT NOT NULL REFERENCES applications(id) ON DELETE CASCADE,
      client_identifier TEXT DEFAULT '',
      ip_address TEXT DEFAULT '',
      username TEXT DEFAULT '',
      activated_at TEXT NOT NULL
    );
  `);

  // 8. Subscriptions
  execute(`
    CREATE TABLE IF NOT EXISTS subscriptions (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      plan_tier TEXT NOT NULL DEFAULT 'FREE',
      price REAL NOT NULL DEFAULT 0,
      status TEXT NOT NULL DEFAULT 'active',
      max_keys_per_app INTEGER NOT NULL DEFAULT 20,
      started_at TEXT NOT NULL,
      renews_at TEXT
    );
  `);

  // 9. API Requests
  execute(`
    CREATE TABLE IF NOT EXISTS api_requests (
      id TEXT PRIMARY KEY,
      application_id TEXT REFERENCES applications(id) ON DELETE SET NULL,
      endpoint TEXT NOT NULL,
      method TEXT NOT NULL,
      status_code INTEGER NOT NULL,
      response_time_ms REAL NOT NULL,
      ip_address TEXT,
      created_at TEXT NOT NULL
    );
  `);

  // 10. Audit Logs
  execute(`
    CREATE TABLE IF NOT EXISTS audit_logs (
      id TEXT PRIMARY KEY,
      user_id TEXT REFERENCES users(id) ON DELETE SET NULL,
      application_id TEXT REFERENCES applications(id) ON DELETE SET NULL,
      event_type TEXT NOT NULL,
      description TEXT NOT NULL,
      ip_address TEXT,
      metadata_json TEXT,
      created_at TEXT NOT NULL
    );
  `);

  // 11. Notifications
  execute(`
    CREATE TABLE IF NOT EXISTS notifications (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      title TEXT NOT NULL,
      message TEXT NOT NULL,
      type TEXT NOT NULL DEFAULT 'info',
      is_read INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL
    );
  `);

  // Create Indexes
  execute(`CREATE INDEX IF NOT EXISTS idx_apps_owner ON applications(owner_id);`);
  execute(`CREATE INDEX IF NOT EXISTS idx_app_users_app ON application_users(application_id);`);
  execute(`CREATE INDEX IF NOT EXISTS idx_licenses_app ON licenses(application_id);`);
  execute(`CREATE INDEX IF NOT EXISTS idx_licenses_key ON licenses(key);`);
  execute(`CREATE INDEX IF NOT EXISTS idx_api_req_app ON api_requests(application_id);`);
  execute(`CREATE INDEX IF NOT EXISTS idx_audit_user ON audit_logs(user_id);`);
  execute(`CREATE INDEX IF NOT EXISTS idx_audit_app ON audit_logs(application_id);`);
  execute(`CREATE INDEX IF NOT EXISTS idx_notif_user ON notifications(user_id);`);

  console.log('[MIGRATIONS] Schemas initialized. Checking seed data...');

  // Seed default admin and developer if empty
  const userCount = queryOne<{ count: number }>(`SELECT COUNT(*) as count FROM users;`);
  if (!userCount || userCount.count === 0) {
    console.log('[SEED] Seeding initial Spidey Auth accounts and demo data...');
    const now = new Date().toISOString();

    // 1. Admin User
    const adminPass = await hashPassword('SpideyAdmin2026!');
    const adminId = 'usr_admin_spidey01';
    execute(`
      INSERT INTO users (id, username, email, password_hash, role, subscription_tier, is_verified, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?);
    `, [adminId, 'spidey_admin', 'admin@spideyauth.dev', adminPass, 'ADMIN', 'PREMIUM', 1, now, now]);

    execute(`
      INSERT INTO subscriptions (id, user_id, plan_tier, price, status, max_keys_per_app, started_at)
      VALUES (?, ?, ?, ?, ?, ?, ?);
    `, ['sub_admin_01', adminId, 'PREMIUM', 29.00, 'active', 100000, now]);

    // 2. Demo Developer User
    const devPass = await hashPassword('SpideyDev2026!');
    const devId = 'usr_dev_spidey02';
    execute(`
      INSERT INTO users (id, username, email, password_hash, role, subscription_tier, is_verified, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?);
    `, [devId, 'spidey_developer', 'developer@spideyauth.dev', devPass, 'USER', 'FREE', 1, now, now]);

    execute(`
      INSERT INTO subscriptions (id, user_id, plan_tier, price, status, max_keys_per_app, started_at)
      VALUES (?, ?, ?, ?, ?, ?, ?);
    `, ['sub_dev_01', devId, 'FREE', 0.00, 'active', 20, now]);

    // 3. Demo Application
    const appId = 'APP-92JD83';
    const ownerCode = 'SPY-OWNER-82HD72';
    execute(`
      INSERT INTO applications (id, owner_id, owner_code, name, description, version, status, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?);
    `, [appId, devId, ownerCode, 'Apex Velocity', 'High-performance desktop game client and launcher platform', '2.4.0', 'ACTIVE', now, now]);

    // App Secret
    const rawSecret = 'spy_sec_99a84f3e1cb482dc77e092147bbfa';
    const secretHash = await hashPassword(rawSecret);
    execute(`
      INSERT INTO application_secrets (id, application_id, secret_hash, secret_masked, secret_raw, is_revoked, created_at)
      VALUES (?, ?, ?, ?, ?, ?, ?);
    `, ['sec_demo_01', appId, secretHash, maskSecret(rawSecret), rawSecret, 0, now]);

    // Application Users
    const appUserPass = await hashPassword('playerPassword123!');
    execute(`
      INSERT INTO application_users (id, application_id, username, password_hash, email, status, subscription_role, expires_at, notes, last_login_at, last_ip, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
    `, ['app_usr_01', appId, 'player123', appUserPass, 'player123@example.com', 'active', 'vip', '2027-12-31T23:59:59Z', 'Early beta tester', now, '127.0.0.1', now, now]);

    execute(`
      INSERT INTO application_users (id, application_id, username, password_hash, email, status, subscription_role, expires_at, notes, last_login_at, last_ip, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
    `, ['app_usr_02', appId, 'shadow_coder', appUserPass, 'shadow@example.com', 'active', 'premium', '2027-06-30T23:59:59Z', 'Active tournament player', now, '192.168.1.10', now, now]);

    // Application Licenses
    const sampleKeys = [
      { key: 'SPIDEY-AX91-KL84-99P2-44QR', type: 'lifetime', max: 2, curr: 1, status: 'ACTIVE', notes: 'VIP Tier Lifetime Pass' },
      { key: 'SPIDEY-MN42-OP89-22TR-77WS', type: 'standard', max: 1, curr: 1, status: 'ACTIVE', notes: 'Standard 1-Year License' },
      { key: 'SPIDEY-ZX11-BB90-88LK-33DF', type: 'trial', max: 1, curr: 0, status: 'ACTIVE', notes: '30-Day Evaluation Key' },
      { key: 'SPIDEY-RE55-KK12-99QQ-88ZX', type: 'standard', max: 1, curr: 1, status: 'REVOKED', notes: 'Chargeback disputed key' }
    ];

    for (let i = 0; i < sampleKeys.length; i++) {
      const k = sampleKeys[i];
      const licId = `lic_seed_${i + 1}`;
      execute(`
        INSERT INTO licenses (id, application_id, key, status, subscription_type, max_activations, current_activations, notes, expires_at, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
      `, [licId, appId, k.key, k.status, k.type, k.max, k.curr, k.notes, '2027-12-31T23:59:59Z', now, now]);

      if (k.curr > 0) {
        execute(`
          INSERT INTO license_activations (id, license_id, application_id, client_identifier, ip_address, username, activated_at)
          VALUES (?, ?, ?, ?, ?, ?, ?);
        `, [`act_seed_${i + 1}`, licId, appId, `HWID-PC-${1000 + i}`, '192.168.1.100', 'player123', now]);
      }
    }

    // Seed some API requests for charts
    const endpoints = ['/api/user/login', '/api/license/validate', '/api/license/activate', '/api/user/register'];
    for (let d = 7; d >= 0; d--) {
      const date = new Date(Date.now() - d * 24 * 60 * 60 * 1000).toISOString();
      const count = Math.floor(Math.random() * 25) + 10;
      for (let j = 0; j < count; j++) {
        execute(`
          INSERT INTO api_requests (id, application_id, endpoint, method, status_code, response_time_ms, ip_address, created_at)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?);
        `, [`req_${d}_${j}`, appId, endpoints[j % endpoints.length], 'POST', 200, Math.floor(Math.random() * 40) + 12, '127.0.0.1', date]);
      }
    }

    // Audit logs
    execute(`
      INSERT INTO audit_logs (id, user_id, application_id, event_type, description, ip_address, created_at)
      VALUES (?, ?, ?, ?, ?, ?, ?);
    `, ['log_seed_01', devId, appId, 'APPLICATION_CREATED', 'Application "Apex Velocity" initialized with version 1.0.0', '127.0.0.1', now]);

    execute(`
      INSERT INTO audit_logs (id, user_id, application_id, event_type, description, ip_address, created_at)
      VALUES (?, ?, ?, ?, ?, ?, ?);
    `, ['log_seed_02', devId, appId, 'KEYS_GENERATED', 'Generated 4 initialization license keys', '127.0.0.1', now]);

    // Initial Notification
    execute(`
      INSERT INTO notifications (id, user_id, title, message, type, is_read, created_at)
      VALUES (?, ?, ?, ?, ?, ?, ?);
    `, ['notif_seed_01', devId, 'Welcome to Spidey Auth', 'Your developer account is ready. Start by checking out the SDKs or creating users.', 'success', 0, now]);

    saveDatabase();
    console.log('[SEED] Database seed completed successfully.');
  }
}
