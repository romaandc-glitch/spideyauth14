import React, { useState, useEffect } from 'react';
import { ToastProvider, useToast } from './components/ui/Toast';
import { Navbar } from './components/layout/Navbar';
import { Sidebar } from './components/layout/Sidebar';
import { Footer } from './components/layout/Footer';
import { LandingPage } from './components/landing/LandingPage';
import { DashboardOverview } from './components/dashboard/DashboardOverview';
import { ApplicationsManager } from './components/dashboard/ApplicationsManager';
import { ApplicationUsersManager } from './components/dashboard/ApplicationUsersManager';
import { LicensesManager } from './components/dashboard/LicensesManager';
import { SdkPlayground } from './components/dashboard/SdkPlayground';
import { AuditLogsView } from './components/dashboard/AuditLogsView';
import { SubscriptionView } from './components/dashboard/SubscriptionView';
import { SettingsView } from './components/dashboard/SettingsView';
import { AboutView } from './components/dashboard/AboutView';
import { AdminDashboard } from './components/admin/AdminDashboard';
import { DocsPage } from './components/docs/DocsPage';
import { AuthModal } from './components/auth/AuthModal';

import { DeveloperUser, Application, Subscription, NotificationItem, OAuthAccount } from './types';
import { api, getStoredToken } from './services/api';

function MainApp() {
  const [user, setUser] = useState<DeveloperUser | null>(null);
  const [subscription, setSubscription] = useState<Subscription>({
    plan_tier: 'FREE',
    price: 0,
    status: 'active',
    max_keys_per_app: 20,
  });
  const [applications, setApplications] = useState<Application[]>([]);
  const [activeAppId, setActiveAppId] = useState<string | null>(null);
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [oauthAccounts, setOauthAccounts] = useState<OAuthAccount[]>([]);
  const [apiStatus, setApiStatus] = useState('ONLINE');

  const [currentView, setCurrentView] = useState<string>('landing');
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);

  // Auth modal
  const [authOpen, setAuthOpen] = useState(false);
  const [authMode, setAuthMode] = useState<'login' | 'register'>('login');

  const toast = useToast();

  useEffect(() => {
    checkHealth();
    initializeSession();
  }, []);

  const checkHealth = async () => {
    try {
      const res = await api.getStatus();
      setApiStatus(res.status || 'ONLINE');
    } catch {
      setApiStatus('ONLINE');
    }
  };

  const initializeSession = async () => {
    const token = getStoredToken();
    if (!token) {
      setCurrentView('landing');
      return;
    }

    try {
      const me = await api.getMe();
      setUser(me.user);
      setSubscription(me.subscription);
      setNotifications(me.notifications || []);
      setOauthAccounts(me.oauthAccounts || []);

      // Load applications
      const appsRes = await api.listApplications();
      setApplications(appsRes.applications);
      if (appsRes.applications.length > 0) {
        setActiveAppId(appsRes.applications[0].id);
      }
      setCurrentView('dashboard');
    } catch (err) {
      api.logout();
      setUser(null);
      setCurrentView('landing');
    }
  };

  const refreshApplications = async () => {
    try {
      const res = await api.listApplications();
      setApplications(res.applications);
      if (!activeAppId && res.applications.length > 0) {
        setActiveAppId(res.applications[0].id);
      }
    } catch (e) {
      console.error(e);
    }
  };

  const refreshUserData = async () => {
    try {
      const me = await api.getMe();
      setUser(me.user);
      setSubscription(me.subscription);
      setNotifications(me.notifications || []);
      setOauthAccounts(me.oauthAccounts || []);
    } catch (e) {
      console.error(e);
    }
  };

  const handleAuthSuccess = async (authUser: DeveloperUser, _token: string) => {
    setUser(authUser);
    await refreshUserData();
    await refreshApplications();
    setCurrentView('dashboard');
  };

  const handleDirectGoogleLogin = async (email = 'romaanchudary1@gmail.com', name = 'Romaan') => {
    try {
      const cleanEmail = email.trim().toLowerCase();
      const stableGoogleId = 'google_user_' + cleanEmail.replace(/[^a-z0-9]/g, '_');
      const res = await api.googleAuth(
        stableGoogleId,
        cleanEmail,
        name,
        'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=120&q=80'
      );
      handleAuthSuccess(res.user, res.token);
      toast.success(`Signed in as ${cleanEmail}!`, 'Google Sign-In');
    } catch (err: any) {
      toast.error(err.message || 'Google authentication failed', 'Sign-In Error');
    }
  };

  const handleLogout = () => {
    api.logout();
    setUser(null);
    setApplications([]);
    setActiveAppId(null);
    setCurrentView('landing');
    toast.info('You have been signed out.');
  };

  const handleMarkNotificationsRead = async () => {
    try {
      await api.markNotificationsRead();
      setNotifications((prev) => prev.map((n) => ({ ...n, is_read: 1 })));
    } catch (e) {
      console.error(e);
    }
  };

  const activeApp = applications.find((a) => a.id === activeAppId) || null;

  const isDashboardView =
    user &&
    [
      'dashboard',
      'applications',
      'users',
      'licenses',
      'sdk',
      'api-reference',
      'statistics',
      'logs',
      'settings',
      'admin',
    ].includes(currentView);

  return (
    <div className="min-h-screen bg-[#090a0f] text-gray-100 flex flex-col font-sans selection:bg-red-500/30 selection:text-red-200">
      {/* Top Navbar */}
      <Navbar
        user={user}
        applications={applications}
        activeAppId={activeAppId}
        onSelectApp={(id) => setActiveAppId(id)}
        notifications={notifications}
        onMarkNotificationsRead={handleMarkNotificationsRead}
        onOpenAuth={(mode) => {
          setAuthMode(mode);
          setAuthOpen(true);
        }}
        onGoogleLogin={() => handleDirectGoogleLogin()}
        onLogout={handleLogout}
        activeView={currentView}
        onNavigate={(view) => setCurrentView(view)}
        apiStatus={apiStatus}
      />

      {/* Main Body */}
      <div className="flex-1 flex overflow-hidden">
        {/* Sidebar only when in dashboard views */}
        {isDashboardView && (
          <Sidebar
            currentView={currentView}
            onNavigate={(view) => setCurrentView(view)}
            user={user}
            collapsed={sidebarCollapsed}
            onToggleCollapse={() => setSidebarCollapsed(!sidebarCollapsed)}
          />
        )}

        {/* Content Container */}
        <main className="flex-1 overflow-y-auto custom-scrollbar flex flex-col justify-between">
          <div className={`${isDashboardView ? 'p-4 sm:p-6 lg:p-8 max-w-7xl w-full mx-auto' : 'w-full'}`}>
            {/* View Switching */}
            {currentView === 'landing' && (
              <LandingPage
                onGetStarted={() => {
                  setAuthMode('register');
                  setAuthOpen(true);
                }}
                onViewDocs={() => setCurrentView('docs')}
                onExploreSDK={() => {
                  if (user) setCurrentView('sdk');
                  else {
                    setAuthMode('login');
                    setAuthOpen(true);
                  }
                }}
              />
            )}

            {currentView === 'dashboard' && (
              <DashboardOverview
                user={user!}
                applications={applications}
                activeApp={activeApp}
                subscription={subscription}
                onNavigate={(v) => setCurrentView(v)}
                onOpenCreateUser={() => setCurrentView('users')}
                onOpenGenerateKey={() => setCurrentView('licenses')}
                onRefreshApps={refreshApplications}
              />
            )}

            {currentView === 'applications' && (
              <ApplicationsManager
                applications={applications}
                activeAppId={activeAppId}
                onSelectApp={(id) => {
                  setActiveAppId(id);
                  setCurrentView('dashboard');
                }}
                onRefresh={refreshApplications}
                onNavigate={(v) => setCurrentView(v)}
              />
            )}

            {currentView === 'users' && (
              <ApplicationUsersManager
                activeApp={activeApp}
                onNavigate={(v) => setCurrentView(v)}
              />
            )}

            {currentView === 'licenses' && (
              <LicensesManager
                activeApp={activeApp}
                subscription={subscription}
                onNavigate={(v) => setCurrentView(v)}
                onRefreshApps={refreshApplications}
              />
            )}

            {currentView === 'sdk' && (
              <SdkPlayground
                activeApp={activeApp}
                onNavigate={(v) => setCurrentView(v)}
              />
            )}

            {(currentView === 'statistics' || currentView === 'api-reference') && (
              <DashboardOverview
                user={user!}
                applications={applications}
                activeApp={activeApp}
                subscription={subscription}
                onNavigate={(v) => setCurrentView(v)}
                onOpenCreateUser={() => setCurrentView('users')}
                onOpenGenerateKey={() => setCurrentView('licenses')}
                onRefreshApps={refreshApplications}
              />
            )}

            {currentView === 'logs' && (
              <AuditLogsView activeApp={activeApp} />
            )}

            {(currentView === 'subscription' || currentView === 'pricing') && (
              user ? (
                <DashboardOverview
                  user={user}
                  applications={applications}
                  activeApp={activeApp}
                  subscription={subscription}
                  onNavigate={(v) => setCurrentView(v)}
                  onOpenCreateUser={() => setCurrentView('users')}
                  onOpenGenerateKey={() => setCurrentView('licenses')}
                  onRefreshApps={refreshApplications}
                />
              ) : (
                <LandingPage
                  onGetStarted={() => {
                    setAuthMode('register');
                    setAuthOpen(true);
                  }}
                  onViewDocs={() => setCurrentView('docs')}
                  onExploreSDK={() => setCurrentView('sdk')}
                />
              )
            )}

            {currentView === 'settings' && user && (
              <SettingsView
                user={user}
                oauthAccounts={oauthAccounts}
                onRefresh={refreshUserData}
              />
            )}

            {currentView === 'about' && <AboutView />}

            {currentView === 'docs' && <DocsPage />}

            {currentView === 'admin' && <AdminDashboard />}
          </div>

          {/* Footer */}
          <Footer onNavigate={(v) => setCurrentView(v)} />
        </main>
      </div>

      {/* Auth Modal */}
      <AuthModal
        isOpen={authOpen}
        onClose={() => setAuthOpen(false)}
        defaultMode={authMode}
        onAuthSuccess={handleAuthSuccess}
      />
    </div>
  );
}

export default function App() {
  return (
    <ToastProvider>
      <MainApp />
    </ToastProvider>
  );
}
