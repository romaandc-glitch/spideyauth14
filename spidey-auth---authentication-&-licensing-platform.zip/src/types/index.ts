export interface DeveloperUser {
  id: string;
  username: string;
  email: string;
  role: 'USER' | 'ADMIN';
  subscription_tier: 'FREE' | 'PREMIUM';
  avatar_url?: string;
  created_at: string;
}

export interface Subscription {
  id?: string;
  plan_tier: 'FREE' | 'PREMIUM';
  price: number;
  status: string;
  max_keys_per_app: number;
  started_at?: string;
  renews_at?: string;
}

export interface NotificationItem {
  id: string;
  title: string;
  message: string;
  type: 'info' | 'success' | 'warning' | 'error';
  is_read: number;
  created_at: string;
}

export interface OAuthAccount {
  provider: string;
  email: string;
  display_name: string;
  created_at: string;
}

export interface Application {
  id: string;
  owner_id: string;
  owner_code: string;
  name: string;
  description: string;
  version: string;
  status: 'ACTIVE' | 'DISABLED';
  secretMasked?: string;
  secret?: string;
  user_count?: number;
  license_count?: number;
  active_license_count?: number;
  request_count?: number;
  created_at: string;
  updated_at: string;
}

export interface ApplicationUser {
  id: string;
  application_id: string;
  username: string;
  email?: string;
  status: 'active' | 'disabled' | 'banned';
  subscription_role: string;
  expires_at?: string;
  notes?: string;
  last_login_at?: string;
  last_ip?: string;
  created_at: string;
  updated_at: string;
}

export interface LicenseKey {
  id: string;
  application_id: string;
  key: string;
  status: 'ACTIVE' | 'USED' | 'EXPIRED' | 'REVOKED' | 'BANNED';
  subscription_type: string;
  max_activations: number;
  current_activations: number;
  notes?: string;
  expires_at?: string;
  created_at: string;
  updated_at: string;
}

export interface AuditLog {
  id: string;
  user_id?: string;
  application_id?: string;
  event_type: string;
  description: string;
  ip_address?: string;
  metadata_json?: string;
  created_at: string;
}

export interface SystemStatus {
  platform: string;
  version: string;
  status: string;
  services: {
    api: { status: string; healthy: boolean };
    database: { status: string; healthy: boolean; engine: string; latencyMs: number };
    authentication: { status: string; healthy: boolean; features: string[] };
    licensingEngine: { status: string; healthy: boolean };
  };
  uptimeSeconds: number;
  timestamp: string;
}
