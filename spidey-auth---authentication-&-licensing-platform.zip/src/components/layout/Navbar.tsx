import React, { useState } from 'react';
import { Shield, Bell, Check, ExternalLink, User, LogOut, ChevronDown, Sparkles, Terminal, Settings } from 'lucide-react';
import { DeveloperUser, NotificationItem, Application } from '../../types';

interface NavbarProps {
  user: DeveloperUser | null;
  applications: Application[];
  activeAppId: string | null;
  onSelectApp: (appId: string) => void;
  notifications: NotificationItem[];
  onMarkNotificationsRead: () => void;
  onOpenAuth: (mode: 'login' | 'register') => void;
  onGoogleLogin?: () => void;
  onLogout: () => void;
  activeView: string;
  onNavigate: (view: string) => void;
  apiStatus: string;
}

export const Navbar: React.FC<NavbarProps> = ({
  user,
  applications,
  activeAppId,
  onSelectApp,
  notifications,
  onMarkNotificationsRead,
  onOpenAuth,
  onGoogleLogin,
  onLogout,
  activeView,
  onNavigate,
  apiStatus,
}) => {
  const [showNotifs, setShowNotifs] = useState(false);
  const [showProfileMenu, setShowProfileMenu] = useState(false);

  const unreadCount = notifications.filter((n) => !n.is_read).length;
  const activeApp = applications.find((a) => a.id === activeAppId);

  return (
    <header className="sticky top-0 z-40 w-full border-b border-zinc-800/80 bg-zinc-950/80 backdrop-blur-xl">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4">
        {/* Brand Logo */}
        <div className="flex items-center gap-6">
          <button
            onClick={() => onNavigate(user ? 'dashboard' : 'landing')}
            className="flex items-center gap-2.5 text-left group"
          >
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-red-500 to-red-700 flex items-center justify-center shadow-[0_0_20px_rgba(239,68,68,0.4)] group-hover:shadow-[0_0_25px_rgba(239,68,68,0.6)] transition-all duration-300">
              <Shield className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-extrabold text-base sm:text-lg tracking-wider text-white font-mono">
                  SPIDEY<span className="text-red-500">AUTH</span>
                </span>
                <span className="text-[10px] uppercase font-bold tracking-widest px-1.5 py-0.5 rounded bg-red-500/10 text-red-400 border border-red-500/20">
                  v1.0
                </span>
              </div>
            </div>
          </button>

          {/* Status Badge */}
          <div className="hidden md:flex items-center gap-2 px-2.5 py-1 rounded-full bg-zinc-900 border border-zinc-800 text-xs">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
            </span>
            <span className="text-zinc-400 font-medium text-[11px]">API: <strong className="text-zinc-200">{apiStatus}</strong></span>
          </div>
        </div>

        {/* Center / Application Selector if in Dashboard */}
        {user && applications.length > 0 && (
          <div className="hidden lg:flex items-center gap-2 bg-zinc-900/90 border border-zinc-800 px-3 py-1.5 rounded-xl">
            <span className="text-[11px] uppercase tracking-wider text-zinc-400 font-semibold">Active App:</span>
            <select
              value={activeAppId || ''}
              onChange={(e) => onSelectApp(e.target.value)}
              className="bg-transparent text-xs font-semibold text-white focus:outline-none cursor-pointer"
            >
              {applications.map((app) => (
                <option key={app.id} value={app.id} className="bg-zinc-900 text-zinc-100">
                  {app.name} ({app.id})
                </option>
              ))}
            </select>
          </div>
        )}

        {/* Right Navigation */}
        <div className="flex items-center gap-3">
          {/* Public Nav Links */}
          <nav className="hidden sm:flex items-center gap-1 mr-2 text-sm">
            <button
              onClick={() => onNavigate('docs')}
              className={`px-3 py-1.5 rounded-lg font-medium transition-colors ${
                activeView === 'docs' ? 'text-red-400 bg-red-500/10' : 'text-zinc-400 hover:text-white'
              }`}
            >
              Docs
            </button>
            <button
              onClick={() => onNavigate('sdk')}
              className={`px-3 py-1.5 rounded-lg font-medium transition-colors ${
                activeView === 'sdk' ? 'text-red-400 bg-red-500/10' : 'text-zinc-400 hover:text-white'
              }`}
            >
              KeyAuth v1 Drop-in
            </button>
            <button
              onClick={() => onNavigate('about')}
              className={`px-3 py-1.5 rounded-lg font-medium transition-colors ${
                activeView === 'about' ? 'text-red-400 bg-red-500/10' : 'text-zinc-400 hover:text-white'
              }`}
            >
              About
            </button>
          </nav>

          {user ? (
            <div className="flex items-center gap-2.5">
              {/* Notification Center */}
              <div className="relative">
                <button
                  onClick={() => {
                    setShowNotifs(!showNotifs);
                    if (unreadCount > 0) onMarkNotificationsRead();
                  }}
                  className="relative p-2 rounded-xl text-zinc-400 hover:text-white hover:bg-zinc-800/80 transition-colors"
                >
                  <Bell className="w-5 h-5" />
                  {unreadCount > 0 && (
                    <span className="absolute top-1.5 right-1.5 w-4 h-4 bg-red-500 text-white rounded-full text-[10px] font-bold flex items-center justify-center animate-pulse shadow-[0_0_8px_rgba(239,68,68,0.8)]">
                      {unreadCount}
                    </span>
                  )}
                </button>

                {/* Notifications Dropdown */}
                {showNotifs && (
                  <div className="absolute right-0 mt-2 w-80 sm:w-96 rounded-2xl bg-zinc-900 border border-zinc-800 shadow-2xl p-4 z-50 animate-in fade-in slide-in-from-top-2">
                    <div className="flex items-center justify-between pb-3 border-b border-zinc-800">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold uppercase tracking-wider text-white">Notifications</span>
                        <span className="text-[10px] bg-red-500/20 text-red-400 px-1.5 py-0.2 rounded font-mono">
                          {notifications.length}
                        </span>
                      </div>
                      <button
                        onClick={onMarkNotificationsRead}
                        className="text-xs text-zinc-400 hover:text-white flex items-center gap-1"
                      >
                        <Check className="w-3.5 h-3.5" /> Mark all read
                      </button>
                    </div>

                    <div className="mt-3 max-h-72 overflow-y-auto space-y-2.5 custom-scrollbar">
                      {notifications.length === 0 ? (
                        <p className="text-xs text-zinc-500 text-center py-6">No notifications yet.</p>
                      ) : (
                        notifications.map((n) => (
                          <div
                            key={n.id}
                            className={`p-3 rounded-xl border transition-colors ${
                              n.is_read ? 'bg-zinc-950/40 border-zinc-800/50' : 'bg-zinc-800/40 border-red-500/30'
                            }`}
                          >
                            <div className="flex items-center justify-between mb-1">
                              <h6 className="text-xs font-semibold text-white tracking-tight">{n.title}</h6>
                              <span className="text-[10px] text-zinc-400">
                                {new Date(n.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                              </span>
                            </div>
                            <p className="text-xs text-zinc-300 leading-relaxed">{n.message}</p>
                          </div>
                        ))
                      )}
                    </div>
                  </div>
                )}
              </div>

              {/* Profile Dropdown */}
              <div className="relative">
                <button
                  onClick={() => setShowProfileMenu(!showProfileMenu)}
                  className="flex items-center gap-2.5 p-1.5 rounded-xl border border-zinc-800 bg-zinc-900/60 hover:border-zinc-700 transition-colors"
                >
                  <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-red-600 to-red-800 flex items-center justify-center text-white text-xs font-bold font-mono">
                    {user.username.charAt(0).toUpperCase()}
                  </div>
                  <div className="hidden sm:block text-left text-xs">
                    <span className="font-semibold text-white block max-w-[100px] truncate">{user.username}</span>
                    <span className="text-[10px] text-emerald-400 uppercase font-mono font-bold">UNLIMITED</span>
                  </div>
                  <ChevronDown className="w-3.5 h-3.5 text-zinc-400" />
                </button>

                {showProfileMenu && (
                  <div className="absolute right-0 mt-2 w-56 rounded-2xl bg-zinc-900 border border-zinc-800 shadow-2xl p-2 z-50 animate-in fade-in slide-in-from-top-2">
                    <div className="p-2.5 border-b border-zinc-800 mb-1">
                      <p className="text-xs font-bold text-white truncate">{user.username}</p>
                      <p className="text-[11px] text-zinc-400 truncate">{user.email}</p>
                      <div className="mt-2 flex items-center gap-1.5">
                        <span className="text-[10px] px-2 py-0.5 rounded font-bold uppercase tracking-wider bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                          UNLIMITED KEYS & USERS
                        </span>
                        {user.role === 'ADMIN' && (
                          <span className="text-[10px] px-2 py-0.5 rounded font-bold bg-red-500/20 text-red-300 border border-red-500/30">
                            ADMIN
                          </span>
                        )}
                      </div>
                    </div>

                    <button
                      onClick={() => {
                        setShowProfileMenu(false);
                        onNavigate('dashboard');
                      }}
                      className="w-full text-left px-3 py-2 rounded-xl text-xs text-zinc-300 hover:text-white hover:bg-zinc-800/80 transition-colors flex items-center gap-2"
                    >
                      <User className="w-4 h-4 text-zinc-400" /> Developer Dashboard
                    </button>

                    <button
                      onClick={() => {
                        setShowProfileMenu(false);
                        onNavigate('sdk');
                      }}
                      className="w-full text-left px-3 py-2 rounded-xl text-xs text-zinc-300 hover:text-white hover:bg-zinc-800/80 transition-colors flex items-center gap-2"
                    >
                      <Terminal className="w-4 h-4 text-red-400" /> KeyAuth v1 & SDKs
                    </button>

                    <button
                      onClick={() => {
                        setShowProfileMenu(false);
                        onNavigate('settings');
                      }}
                      className="w-full text-left px-3 py-2 rounded-xl text-xs text-zinc-300 hover:text-white hover:bg-zinc-800/80 transition-colors flex items-center gap-2"
                    >
                      <Settings className="w-4 h-4 text-zinc-400" /> Settings & Accounts
                    </button>

                    {user.role === 'ADMIN' && (
                      <button
                        onClick={() => {
                          setShowProfileMenu(false);
                          onNavigate('admin');
                        }}
                        className="w-full text-left px-3 py-2 rounded-xl text-xs text-red-400 hover:text-red-300 hover:bg-red-500/10 transition-colors flex items-center gap-2 font-semibold"
                      >
                        <Shield className="w-4 h-4 text-red-400" /> Admin Control Panel
                      </button>
                    )}

                    <div className="pt-1 mt-1 border-t border-zinc-800">
                      <button
                        onClick={() => {
                          setShowProfileMenu(false);
                          onLogout();
                        }}
                        className="w-full text-left px-3 py-2 rounded-xl text-xs text-red-400 hover:text-red-300 hover:bg-red-500/10 transition-colors flex items-center gap-2"
                      >
                        <LogOut className="w-4 h-4" /> Sign Out
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          ) : (
            <div className="flex items-center gap-2">
              <button
                onClick={() => onGoogleLogin ? onGoogleLogin() : onOpenAuth('login')}
                className="hidden sm:flex items-center gap-2 text-xs font-semibold text-zinc-200 hover:text-white px-3 py-1.5 rounded-xl transition-all bg-zinc-900 hover:bg-zinc-800 border border-zinc-700/80 hover:border-red-500/40 shadow-sm"
                title="1-Click Instant Google Sign-In"
              >
                <svg className="w-3.5 h-3.5" viewBox="0 0 24 24">
                  <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                  <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                  <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
                  <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
                </svg>
                <span>Google Sign In</span>
              </button>
              <button
                onClick={() => onOpenAuth('login')}
                className="text-xs font-semibold text-zinc-300 hover:text-white px-3.5 py-2 rounded-xl transition-colors hover:bg-zinc-800/60"
              >
                Sign In
              </button>
              <button
                onClick={() => onOpenAuth('register')}
                className="text-xs font-bold text-white bg-red-600 hover:bg-red-500 px-4 py-2 rounded-xl shadow-[0_0_20px_rgba(239,68,68,0.3)] hover:shadow-[0_0_25px_rgba(239,68,68,0.5)] transition-all duration-300 flex items-center gap-1.5"
              >
                Get Started
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};
