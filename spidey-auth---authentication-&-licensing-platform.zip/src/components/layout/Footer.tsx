import React from 'react';
import { Shield, Heart, Terminal, Lock, ExternalLink } from 'lucide-react';

interface FooterProps {
  onNavigate: (view: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate }) => {
  return (
    <footer className="border-t border-zinc-800/80 bg-zinc-950/90 text-zinc-400 py-12 px-4 sm:px-6 lg:px-8 relative overflow-hidden">
      {/* Background glow */}
      <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-96 h-24 bg-red-600/5 blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-12">
          {/* Brand Info */}
          <div className="md:col-span-1 space-y-3">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-red-600 flex items-center justify-center text-white shadow-[0_0_15px_rgba(239,68,68,0.4)]">
                <Shield className="w-4 h-4" />
              </div>
              <span className="font-extrabold text-base tracking-wider text-white font-mono">
                SPIDEY<span className="text-red-500">AUTH</span>
              </span>
            </div>
            <p className="text-xs text-zinc-400 leading-relaxed">
              Spidey Auth is a modern authentication and licensing platform designed to help developers securely manage users, applications, licenses and API access.
            </p>
            <div className="pt-2">
              <span className="inline-flex items-center gap-1.5 text-xs text-red-400 font-semibold bg-red-500/10 border border-red-500/20 px-2.5 py-1 rounded-full">
                <Lock className="w-3 h-3" /> End-to-End Multi-Tenant Isolation
              </span>
            </div>
          </div>

          {/* Solutions & Product */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-white mb-3">Product</h4>
            <ul className="space-y-2 text-xs">
              <li>
                <button onClick={() => onNavigate('dashboard')} className="hover:text-red-400 transition-colors">
                  Developer Dashboard
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('applications')} className="hover:text-red-400 transition-colors">
                  Application Management
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('users')} className="hover:text-red-400 transition-colors">
                  End-User Authentication
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('licenses')} className="hover:text-red-400 transition-colors">
                  License Key System
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('sdk')} className="hover:text-red-400 transition-colors">
                  KeyAuth v1 Drop-in API
                </button>
              </li>
            </ul>
          </div>

          {/* SDKs & Resources */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-white mb-3">Developer SDKs</h4>
            <ul className="space-y-2 text-xs">
              <li>
                <button onClick={() => onNavigate('sdk')} className="hover:text-red-400 transition-colors flex items-center gap-1.5">
                  <Terminal className="w-3.5 h-3.5 text-red-400" /> C# / .NET SDK
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('sdk')} className="hover:text-red-400 transition-colors flex items-center gap-1.5">
                  <Terminal className="w-3.5 h-3.5 text-red-400" /> C++ Native SDK
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('sdk')} className="hover:text-red-400 transition-colors flex items-center gap-1.5">
                  <Terminal className="w-3.5 h-3.5 text-red-400" /> Python SDK
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('sdk')} className="hover:text-red-400 transition-colors flex items-center gap-1.5">
                  <Terminal className="w-3.5 h-3.5 text-red-400" /> TypeScript / JavaScript SDK
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('docs')} className="hover:text-red-400 transition-colors">
                  REST API Documentation
                </button>
              </li>
            </ul>
          </div>

          {/* Company & Status */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-white mb-3">Platform</h4>
            <ul className="space-y-2 text-xs">
              <li>
                <button onClick={() => onNavigate('about')} className="hover:text-red-400 transition-colors">
                  About Spidey Auth
                </button>
              </li>
              <li>
                <a href="/status" target="_blank" rel="noreferrer" className="hover:text-red-400 transition-colors flex items-center gap-1">
                  API Status Monitor <ExternalLink className="w-3 h-3" />
                </a>
              </li>
              <li>
                <button onClick={() => onNavigate('docs')} className="hover:text-red-400 transition-colors">
                  Security Architecture
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('docs')} className="hover:text-red-400 transition-colors">
                  Error Code Directory
                </button>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Banner */}
        <div className="pt-8 border-t border-zinc-800/80 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs">
          <p className="text-zinc-500">
            © {new Date().getFullYear()} Spidey Auth. All rights reserved.
          </p>

          <div className="flex items-center gap-2 text-zinc-300 font-medium">
            <span className="text-zinc-500">Developed with</span>
            <span className="text-red-500 font-bold">SPIDEY AUTH</span>
            <span className="text-zinc-500">•</span>
            <span className="text-white font-mono font-bold tracking-wider">Built by Spidey</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
