import React from 'react';
import {
  LayoutDashboard,
  Layers,
  Users,
  KeyRound,
  Terminal,
  Code2,
  BarChart3,
  ScrollText,
  Sparkles,
  BookOpen,
  Settings,
  Info,
  ShieldAlert,
  ChevronLeft,
  ChevronRight,
} from 'lucide-react';
import { DeveloperUser } from '../../types';

interface SidebarProps {
  currentView: string;
  onNavigate: (view: string) => void;
  user: DeveloperUser | null;
  collapsed: boolean;
  onToggleCollapse: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentView,
  onNavigate,
  user,
  collapsed,
  onToggleCollapse,
}) => {
  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'applications', label: 'Applications', icon: Layers },
    { id: 'users', label: 'Users', icon: Users },
    { id: 'licenses', label: 'Licenses', icon: KeyRound },
    { id: 'sdk', label: 'SDK & KeyAuth v1', icon: Terminal },
    { id: 'api-reference', label: 'API Reference', icon: Code2 },
    { id: 'statistics', label: 'Statistics', icon: BarChart3 },
    { id: 'logs', label: 'Audit Logs', icon: ScrollText },
    { id: 'docs', label: 'Documentation', icon: BookOpen },
    { id: 'settings', label: 'Settings', icon: Settings },
    { id: 'about', label: 'About', icon: Info },
  ];

  if (user?.role === 'ADMIN') {
    navItems.push({ id: 'admin', label: 'Admin Panel', icon: ShieldAlert });
  }

  return (
    <aside
      className={`relative z-20 border-r border-zinc-800/80 bg-zinc-950/80 backdrop-blur-xl flex flex-col transition-all duration-300 ${
        collapsed ? 'w-20' : 'w-64'
      }`}
    >
      {/* Collapse Toggle Button */}
      <button
        onClick={onToggleCollapse}
        className="absolute -right-3 top-6 w-6 h-6 rounded-full bg-zinc-900 border border-zinc-700 text-zinc-400 hover:text-white flex items-center justify-center shadow-lg transition-transform hover:scale-110 z-30"
        title={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
      >
        {collapsed ? <ChevronRight className="w-3.5 h-3.5" /> : <ChevronLeft className="w-3.5 h-3.5" />}
      </button>

      {/* Nav List */}
      <div className="flex-1 py-4 px-3 space-y-1 overflow-y-auto custom-scrollbar">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentView === item.id;
          const isAdminItem = item.id === 'admin';

          return (
            <button
              key={item.id}
              onClick={() => onNavigate(item.id)}
              title={collapsed ? item.label : undefined}
              className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-semibold transition-all duration-200 group relative ${
                isActive
                  ? isAdminItem
                    ? 'bg-red-500/15 text-red-400 border border-red-500/30 shadow-[0_0_15px_rgba(239,68,68,0.15)]'
                    : 'bg-red-600/15 text-white border border-red-500/30 shadow-[0_0_20px_rgba(239,68,68,0.15)] font-bold'
                  : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-900/60'
              } ${collapsed ? 'justify-center px-0' : ''}`}
            >
              <Icon
                className={`w-4 h-4 shrink-0 transition-colors ${
                  isActive
                    ? 'text-red-400'
                    : isAdminItem
                    ? 'text-red-400/70 group-hover:text-red-400'
                    : 'text-zinc-400 group-hover:text-zinc-200'
                }`}
              />
              {!collapsed && (
                <span className="truncate tracking-tight flex-1 text-left">
                  {item.label}
                </span>
              )}
              {collapsed && isActive && (
                <span className="absolute left-1 w-1 h-5 bg-red-500 rounded-r-full" />
              )}
            </button>
          );
        })}
      </div>

      {/* Bottom Unlimited Access Status */}
      {!collapsed && user && (
        <div className="p-4 border-t border-zinc-800/80 bg-zinc-900/40 m-2 rounded-2xl">
          <div className="flex items-center justify-between mb-2">
            <span className="text-[11px] font-bold text-zinc-400 uppercase tracking-wider">Access</span>
            <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded uppercase bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
              UNLIMITED
            </span>
          </div>
          <div className="w-full bg-zinc-800 rounded-full h-1.5 mb-2 overflow-hidden">
            <div className="h-full rounded-full bg-emerald-400 w-full transition-all duration-500" />
          </div>
          <p className="text-[10px] text-zinc-400">
            Unlimited keys & users for all applications
          </p>
        </div>
      )}
    </aside>
  );
};
