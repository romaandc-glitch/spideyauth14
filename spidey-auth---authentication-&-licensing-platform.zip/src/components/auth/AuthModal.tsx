import React, { useState } from 'react';
import { Shield, Mail, Lock, User, ArrowRight, AlertCircle, CheckCircle2, KeyRound, Sparkles, X } from 'lucide-react';
import { Modal } from '../ui/Modal';
import { api } from '../../services/api';
import { DeveloperUser } from '../../types';
import { useToast } from '../ui/Toast';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  defaultMode?: 'login' | 'register';
  onAuthSuccess: (user: DeveloperUser, token: string) => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  defaultMode = 'login',
  onAuthSuccess,
}) => {
  const [mode, setMode] = useState<'login' | 'register' | 'reset-password'>(defaultMode);
  const [loginInput, setLoginInput] = useState('');
  const [email, setEmail] = useState('');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [googleLinkedPrompt, setGoogleLinkedPrompt] = useState<string | null>(null);

  // Google Account Chooser Modal State
  const [showGoogleChooser, setShowGoogleChooser] = useState(false);
  const [customGoogleEmail, setCustomGoogleEmail] = useState('');

  const toast = useToast();

  const detectedUserEmail = 'romaanchudary1@gmail.com';

  const handleGoogleAuthWithEmail = async (targetEmail: string, displayName = 'Romaan') => {
    setLoading(true);
    setErrorMsg(null);
    setGoogleLinkedPrompt(null);
    try {
      const cleanEmail = targetEmail.trim().toLowerCase();
      const stableGoogleId = 'google_user_' + cleanEmail.replace(/[^a-z0-9]/g, '_');

      const res = await api.googleAuth(
        stableGoogleId,
        cleanEmail,
        displayName,
        'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=120&q=80'
      );

      toast.success(`Signed in as ${cleanEmail}!`, 'Google OAuth');
      onAuthSuccess(res.user, res.token);
      setShowGoogleChooser(false);
      onClose();
    } catch (err: any) {
      setErrorMsg(err.message || 'Google authentication failed');
      toast.error(err.message || 'Google sign-in error', 'Authentication Error');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setGoogleLinkedPrompt(null);
    setLoading(true);

    try {
      if (mode === 'login') {
        if (!loginInput || !password) {
          throw new Error('Please enter your username/email and password.');
        }
        try {
          const res = await api.login(loginInput, password);
          toast.success(`Welcome back, ${res.user.username}!`, 'Authentication Success');
          onAuthSuccess(res.user, res.token);
          onClose();
        } catch (err: any) {
          if (err.details?.isGoogleLinked) {
            setGoogleLinkedPrompt(err.details.email || loginInput);
          }
          throw err;
        }
      } else if (mode === 'register') {
        if (!email || !username || !password || !confirmPassword) {
          throw new Error('All registration fields are required.');
        }
        if (password !== confirmPassword) {
          throw new Error('Passwords do not match.');
        }
        if (password.length < 8) {
          throw new Error('Password must be at least 8 characters long.');
        }
        const res = await api.register(email, username, password, confirmPassword);
        toast.success(`Account created! Welcome, ${res.user.username}!`, 'Registration Success');
        onAuthSuccess(res.user, res.token);
        onClose();
      } else if (mode === 'reset-password') {
        const resetTarget = email || loginInput;
        if (!resetTarget || !newPassword) {
          throw new Error('Email and new password are required.');
        }
        if (newPassword.length < 8) {
          throw new Error('New password must be at least 8 characters long.');
        }
        const res = await api.resetAccountPassword(resetTarget, newPassword);
        toast.success(res.message, 'Password Reset');
        onAuthSuccess(res.user, res.token);
        onClose();
      }
    } catch (err: any) {
      setErrorMsg(err.message || 'Authentication error');
      toast.error(err.message || 'Failed to authenticate');
    } finally {
      setLoading(false);
    }
  };

  const fillQuickDemo = (type: 'developer' | 'admin') => {
    setMode('login');
    if (type === 'developer') {
      setLoginInput('developer@spideyauth.dev');
      setPassword('SpideyDev2026!');
    } else {
      setLoginInput('admin@spideyauth.dev');
      setPassword('SpideyAdmin2026!');
    }
    setErrorMsg(null);
    setGoogleLinkedPrompt(null);
  };

  return (
    <>
      <Modal
        isOpen={isOpen && !showGoogleChooser}
        onClose={onClose}
        title={
          mode === 'login'
            ? 'Sign In to Spidey Auth'
            : mode === 'register'
            ? 'Create Spidey Auth Account'
            : 'Reset Account Password'
        }
        subtitle={
          mode === 'login'
            ? 'Access your developer console, manage apps and licensing.'
            : mode === 'register'
            ? 'Deploy applications, manage keys, and authenticate users.'
            : 'Set a new password for your email or Google-linked account.'
        }
        maxWidth="max-w-md"
      >
        {/* Mode Switcher */}
        <div className="flex p-1 bg-zinc-900 rounded-xl border border-zinc-800">
          <button
            type="button"
            onClick={() => {
              setMode('login');
              setErrorMsg(null);
              setGoogleLinkedPrompt(null);
            }}
            className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all ${
              mode === 'login' ? 'bg-red-600 text-white shadow-md' : 'text-zinc-400 hover:text-white'
            }`}
          >
            Sign In
          </button>
          <button
            type="button"
            onClick={() => {
              setMode('register');
              setErrorMsg(null);
              setGoogleLinkedPrompt(null);
            }}
            className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all ${
              mode === 'register' ? 'bg-red-600 text-white shadow-md' : 'text-zinc-400 hover:text-white'
            }`}
          >
            Create Account
          </button>
          <button
            type="button"
            onClick={() => {
              setMode('reset-password');
              setErrorMsg(null);
              setGoogleLinkedPrompt(null);
            }}
            className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all ${
              mode === 'reset-password' ? 'bg-red-600 text-white shadow-md' : 'text-zinc-400 hover:text-white'
            }`}
          >
            Reset Pass
          </button>
        </div>

        {/* PRIMARY GOOGLE SIGN-IN BUTTON */}
        <div className="mt-4 space-y-2">
          {/* Main Google Button - 1-Click Instant Sign In */}
          <button
            type="button"
            onClick={() => handleGoogleAuthWithEmail(loginInput.trim() && loginInput.includes('@') ? loginInput.trim() : detectedUserEmail, 'Romaan')}
            disabled={loading}
            className="w-full flex items-center justify-center gap-3 py-3 px-4 rounded-xl bg-zinc-900 hover:bg-zinc-800 border border-zinc-700/80 text-zinc-100 text-xs font-bold transition-all hover:border-zinc-500 shadow-sm group"
          >
            <svg className="w-4 h-4 shrink-0" viewBox="0 0 24 24">
              <path
                fill="#4285F4"
                d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
              />
              <path
                fill="#34A853"
                d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
              />
              <path
                fill="#FBBC05"
                d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
              />
              <path
                fill="#EA4335"
                d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
              />
            </svg>
            <span>Continue with Google</span>
          </button>

          {/* Quick-sign-in Pill for the detected user email */}
          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={() => handleGoogleAuthWithEmail(detectedUserEmail, 'Romaan')}
              disabled={loading}
              className="flex-1 flex items-center justify-between p-2.5 rounded-xl bg-red-500/10 hover:bg-red-500/20 border border-red-500/30 text-xs text-red-200 transition-colors text-left"
            >
              <div className="flex items-center gap-2 truncate">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse shrink-0" />
                <span className="truncate font-semibold">
                  Sign in as <strong>{detectedUserEmail}</strong>
                </span>
              </div>
              <span className="font-mono text-[11px] font-bold text-red-400 shrink-0">1-Click →</span>
            </button>
            <button
              type="button"
              onClick={() => setShowGoogleChooser(true)}
              className="p-2.5 rounded-xl bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-[11px] text-zinc-400 hover:text-white transition-colors shrink-0"
              title="Use another Google account"
            >
              Switch
            </button>
          </div>
        </div>

        <div className="relative flex py-2 items-center">
          <div className="flex-grow border-t border-zinc-800"></div>
          <span className="flex-shrink mx-3 text-[11px] uppercase tracking-wider text-zinc-500 font-mono">
            or use credentials
          </span>
          <div className="flex-grow border-t border-zinc-800"></div>
        </div>

        {/* GOOGLE LINKED ACCOUNT PROMPT */}
        {googleLinkedPrompt && (
          <div className="p-3.5 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-200 text-xs space-y-2">
            <div className="flex items-start gap-2">
              <AlertCircle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
              <div>
                <p className="font-bold text-amber-300">Google-Linked Account Detected</p>
                <p className="text-[11px] text-amber-200/90 mt-0.5">
                  <strong>{googleLinkedPrompt}</strong> is linked with Google OAuth. You can log in instantly with Google, or set a custom password below.
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2 pt-1">
              <button
                type="button"
                onClick={() => handleGoogleAuthWithEmail(googleLinkedPrompt)}
                className="flex-1 py-1.5 px-3 rounded-lg bg-amber-500 hover:bg-amber-400 text-black font-bold text-xs transition-colors"
              >
                Sign in with Google
              </button>
              <button
                type="button"
                onClick={() => {
                  setMode('reset-password');
                  setEmail(googleLinkedPrompt);
                  setGoogleLinkedPrompt(null);
                }}
                className="py-1.5 px-3 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-xs font-semibold transition-colors"
              >
                Set Password
              </button>
            </div>
          </div>
        )}

        {errorMsg && !googleLinkedPrompt && (
          <div className="p-3 rounded-xl bg-red-500/10 border border-red-500/30 text-red-300 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 text-red-400" />
            <span>{errorMsg}</span>
          </div>
        )}

        {/* FORMS */}
        <form onSubmit={handleSubmit} className="space-y-3.5">
          {mode === 'login' && (
            <>
              <div>
                <label className="block text-xs font-semibold text-zinc-300 mb-1.5">
                  Email or Username
                </label>
                <div className="relative">
                  <Mail className="absolute left-3 top-2.5 w-4 h-4 text-zinc-500" />
                  <input
                    type="text"
                    value={loginInput}
                    onChange={(e) => setLoginInput(e.target.value)}
                    placeholder="romaanchudary1@gmail.com or username"
                    className="w-full bg-zinc-900 border border-zinc-800 rounded-xl py-2 pl-9 pr-3 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-red-500 transition-colors"
                    required
                  />
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="block text-xs font-semibold text-zinc-300">Password</label>
                  <button
                    type="button"
                    onClick={() => {
                      setMode('reset-password');
                      setEmail(loginInput);
                    }}
                    className="text-[11px] text-red-400 hover:text-red-300 transition-colors"
                  >
                    Forgot password?
                  </button>
                </div>
                <div className="relative">
                  <Lock className="absolute left-3 top-2.5 w-4 h-4 text-zinc-500" />
                  <input
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••••••"
                    className="w-full bg-zinc-900 border border-zinc-800 rounded-xl py-2 pl-9 pr-3 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-red-500 transition-colors"
                    required
                  />
                </div>
              </div>
            </>
          )}

          {mode === 'register' && (
            <>
              <div>
                <label className="block text-xs font-semibold text-zinc-300 mb-1.5">Email Address</label>
                <div className="relative">
                  <Mail className="absolute left-3 top-2.5 w-4 h-4 text-zinc-500" />
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="romaanchudary1@gmail.com"
                    className="w-full bg-zinc-900 border border-zinc-800 rounded-xl py-2 pl-9 pr-3 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-red-500 transition-colors"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-zinc-300 mb-1.5">Developer Username</label>
                <div className="relative">
                  <User className="absolute left-3 top-2.5 w-4 h-4 text-zinc-500" />
                  <input
                    type="text"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    placeholder="spidey_dev"
                    className="w-full bg-zinc-900 border border-zinc-800 rounded-xl py-2 pl-9 pr-3 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-red-500 transition-colors"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs font-semibold text-zinc-300 mb-1.5">Password</label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-2.5 w-4 h-4 text-zinc-500" />
                    <input
                      type="password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="Min 8 chars"
                      className="w-full bg-zinc-900 border border-zinc-800 rounded-xl py-2 pl-9 pr-3 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-red-500 transition-colors"
                      required
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-zinc-300 mb-1.5">Confirm</label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-2.5 w-4 h-4 text-zinc-500" />
                    <input
                      type="password"
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      placeholder="Repeat"
                      className="w-full bg-zinc-900 border border-zinc-800 rounded-xl py-2 pl-9 pr-3 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-red-500 transition-colors"
                      required
                    />
                  </div>
                </div>
              </div>
            </>
          )}

          {mode === 'reset-password' && (
            <>
              <div>
                <label className="block text-xs font-semibold text-zinc-300 mb-1.5">Email Address</label>
                <div className="relative">
                  <Mail className="absolute left-3 top-2.5 w-4 h-4 text-zinc-500" />
                  <input
                    type="email"
                    value={email || loginInput}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="romaanchudary1@gmail.com"
                    className="w-full bg-zinc-900 border border-zinc-800 rounded-xl py-2 pl-9 pr-3 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-red-500 transition-colors"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-zinc-300 mb-1.5">New Password (Min 8 characters)</label>
                <div className="relative">
                  <Lock className="absolute left-3 top-2.5 w-4 h-4 text-zinc-500" />
                  <input
                    type="password"
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    placeholder="Enter new secure password"
                    className="w-full bg-zinc-900 border border-zinc-800 rounded-xl py-2 pl-9 pr-3 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-red-500 transition-colors"
                    required
                  />
                </div>
              </div>
            </>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full mt-2 py-2.5 px-4 rounded-xl bg-red-600 hover:bg-red-500 text-white text-xs font-bold shadow-[0_0_20px_rgba(239,68,68,0.3)] hover:shadow-[0_0_25px_rgba(239,68,68,0.5)] transition-all flex items-center justify-center gap-2 disabled:opacity-50"
          >
            {loading ? (
              <span className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full" />
            ) : (
              <>
                {mode === 'login'
                  ? 'Sign In to Dashboard'
                  : mode === 'register'
                  ? 'Create Free Account'
                  : 'Save New Password & Sign In'}
                <ArrowRight className="w-4 h-4" />
              </>
            )}
          </button>
        </form>

        {/* Quick Demo Logins for instant review */}
        <div className="mt-5 pt-4 border-t border-zinc-800/80">
          <span className="text-[10px] uppercase font-bold tracking-wider text-zinc-400 block mb-2 font-mono">
            ⚡ Instant Demo Access
          </span>
          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={() => fillQuickDemo('developer')}
              className="p-2 rounded-xl bg-zinc-900 border border-zinc-800 hover:border-red-500/40 text-left transition-colors text-[11px]"
            >
              <div className="font-semibold text-zinc-200">Developer Demo</div>
              <div className="text-[10px] text-zinc-400">spidey_developer (Free)</div>
            </button>
            <button
              type="button"
              onClick={() => fillQuickDemo('admin')}
              className="p-2 rounded-xl bg-zinc-900 border border-zinc-800 hover:border-red-500/40 text-left transition-colors text-[11px]"
            >
              <div className="font-semibold text-red-400">Admin Demo</div>
              <div className="text-[10px] text-zinc-400">spidey_admin (Premium)</div>
            </button>
          </div>
        </div>
      </Modal>

      {/* GOOGLE OAUTH ACCOUNT SELECTOR MODAL */}
      <Modal
        isOpen={showGoogleChooser}
        onClose={() => setShowGoogleChooser(false)}
        title="Sign in with Google"
        subtitle="Choose an account to continue to Spidey Auth"
        maxWidth="max-w-md"
      >
        <div className="space-y-4">
          <div className="text-center py-2">
            <div className="w-12 h-12 rounded-full bg-white flex items-center justify-center mx-auto shadow-md">
              <svg className="w-6 h-6" viewBox="0 0 24 24">
                <path
                  fill="#4285F4"
                  d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                />
                <path
                  fill="#34A853"
                  d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                />
                <path
                  fill="#FBBC05"
                  d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                />
                <path
                  fill="#EA4335"
                  d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                />
              </svg>
            </div>
            <h4 className="text-base font-bold text-white mt-3">Choose an account</h4>
            <p className="text-xs text-zinc-400">to proceed to Spidey Auth developer portal</p>
          </div>

          {/* Account 1: Romaan's Google Account */}
          <button
            type="button"
            onClick={() => handleGoogleAuthWithEmail(detectedUserEmail, 'Romaan')}
            className="w-full p-3.5 rounded-2xl bg-zinc-900/90 hover:bg-zinc-800 border border-zinc-700/80 hover:border-red-500/40 transition-all flex items-center justify-between text-left group"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-blue-500 to-indigo-600 flex items-center justify-center text-white font-bold text-sm shadow-sm">
                R
              </div>
              <div>
                <h5 className="text-xs font-bold text-white">Romaan</h5>
                <p className="text-[11px] text-zinc-400 font-mono">{detectedUserEmail}</p>
                <span className="text-[10px] text-emerald-400 font-semibold flex items-center gap-1 mt-0.5">
                  <CheckCircle2 className="w-3 h-3" /> Signed in (Current Session)
                </span>
              </div>
            </div>
            <ArrowRight className="w-4 h-4 text-zinc-500 group-hover:text-red-400 group-hover:translate-x-1 transition-all" />
          </button>

          {/* Or enter another Google Account */}
          <div className="p-4 rounded-2xl bg-zinc-950/60 border border-zinc-800 space-y-3">
            <label className="block text-xs font-semibold text-zinc-300">
              Use another Google Account
            </label>
            <div className="flex items-center gap-2">
              <input
                type="email"
                value={customGoogleEmail}
                onChange={(e) => setCustomGoogleEmail(e.target.value)}
                placeholder="another-account@gmail.com"
                className="flex-1 bg-zinc-900 border border-zinc-800 rounded-xl py-2 px-3 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-red-500"
              />
              <button
                type="button"
                onClick={() => {
                  if (customGoogleEmail.trim()) {
                    handleGoogleAuthWithEmail(customGoogleEmail.trim());
                  }
                }}
                disabled={!customGoogleEmail.trim() || loading}
                className="px-3.5 py-2 rounded-xl bg-red-600 hover:bg-red-500 disabled:opacity-50 text-white font-bold text-xs transition-colors shrink-0"
              >
                Continue
              </button>
            </div>
          </div>

          <div className="text-center pt-2">
            <button
              type="button"
              onClick={() => setShowGoogleChooser(false)}
              className="text-xs text-zinc-400 hover:text-white transition-colors"
            >
              Cancel and return to password login
            </button>
          </div>
        </div>
      </Modal>
    </>
  );
};
