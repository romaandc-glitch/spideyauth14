import React, { useState, useEffect } from 'react';
import {
  ShieldAlert,
  Users,
  Layers,
  KeyRound,
  Activity,
  Sparkles,
  Ban,
  CheckCircle2,
  RefreshCw,
  Search,
  Power,
  Shield,
  Eye,
} from 'lucide-react';
import { api } from '../../services/api';
import { useToast } from '../ui/Toast';

export const AdminDashboard: React.FC = () => {
  const [tab, setTab] = useState<'overview' | 'users' | 'apps' | 'logs'>('overview');
  const [overview, setOverview] = useState<any>(null);
  const [users, setUsers] = useState<any[]>([]);
  const [apps, setApps] = useState<any[]>([]);
  const [logs, setLogs] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [search, setSearch] = useState('');

  const toast = useToast();

  useEffect(() => {
    loadData();
  }, [tab]);

  const loadData = async () => {
    setLoading(true);
    try {
      if (tab === 'overview') {
        const res = await api.getAdminOverview();
        setOverview(res);
      } else if (tab === 'users') {
        const res = await api.listAllUsers();
        setUsers(res.users);
      } else if (tab === 'apps') {
        const res = await api.listAllApps();
        setApps(res.applications);
      } else if (tab === 'logs') {
        const res = await api.getAllAuditLogs();
        setLogs(res.logs);
      }
    } catch (err: any) {
      toast.error(err.message || 'Failed to load administrator data');
    } finally {
      setLoading(false);
    }
  };

  const handleToggleSuspend = async (userId: string, currentSuspended: number) => {
    try {
      await api.toggleUserSuspension(userId, currentSuspended === 0);
      toast.success(`User ${currentSuspended === 0 ? 'suspended' : 'unsuspended'} successfully.`);
      loadData();
    } catch (err: any) {
      toast.error(err.message || 'Failed to update suspension');
    }
  };

  const handleToggleRole = async (userId: string, currentRole: string) => {
    const newRole = currentRole === 'ADMIN' ? 'USER' : 'ADMIN';
    try {
      await api.updateUserRole(userId, newRole);
      toast.success(`User role changed to ${newRole}.`);
      loadData();
    } catch (err: any) {
      toast.error(err.message || 'Failed to update role');
    }
  };

  const handleToggleAppStatus = async (appId: string, currentStatus: string) => {
    const newStatus = currentStatus === 'ACTIVE' ? 'DISABLED' : 'ACTIVE';
    try {
      await api.toggleAppStatus(appId, newStatus);
      toast.success(`Application status changed to ${newStatus}.`);
      loadData();
    } catch (err: any) {
      toast.error(err.message || 'Failed to toggle app status');
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-red-400 tracking-tight flex items-center gap-2">
            <ShieldAlert className="w-5 h-5 text-red-500" />
            Administrator Control Center
          </h2>
          <p className="text-xs text-zinc-400 mt-1">
            Platform-wide governance, security enforcement, developer accounts, and infrastructure health.
          </p>
        </div>

        <button
          onClick={loadData}
          className="p-2 rounded-xl bg-zinc-900 border border-zinc-800 text-zinc-400 hover:text-white transition-colors"
          title="Refresh"
        >
          <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
        </button>
      </div>

      {/* Admin Tabs */}
      <div className="flex items-center gap-2 border-b border-zinc-800 pb-2">
        {(['overview', 'users', 'apps', 'logs'] as const).map((t) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={`px-4 py-2 rounded-xl text-xs font-bold uppercase tracking-wider transition-colors ${
              tab === t
                ? 'bg-red-600 text-white shadow-[0_0_15px_rgba(239,68,68,0.3)]'
                : 'text-zinc-400 hover:text-white hover:bg-zinc-900'
            }`}
          >
            {t}
          </button>
        ))}
      </div>

      {/* TAB: OVERVIEW */}
      {tab === 'overview' && overview && (
        <div className="space-y-6">
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            <div className="p-4 rounded-2xl bg-zinc-900/50 border border-zinc-800">
              <span className="text-[10px] text-zinc-500 uppercase font-mono block">Total Developers</span>
              <span className="text-2xl font-bold font-mono text-white mt-1 block">{overview.stats.totalUsers}</span>
            </div>
            <div className="p-4 rounded-2xl bg-zinc-900/50 border border-zinc-800">
              <span className="text-[10px] text-zinc-500 uppercase font-mono block">Total Applications</span>
              <span className="text-2xl font-bold font-mono text-white mt-1 block">{overview.stats.totalApps}</span>
            </div>
            <div className="p-4 rounded-2xl bg-zinc-900/50 border border-zinc-800">
              <span className="text-[10px] text-zinc-500 uppercase font-mono block">Total Licenses</span>
              <span className="text-2xl font-bold font-mono text-red-400 mt-1 block">{overview.stats.totalLicenses}</span>
            </div>
            <div className="p-4 rounded-2xl bg-zinc-900/50 border border-zinc-800">
              <span className="text-[10px] text-zinc-500 uppercase font-mono block">End Users</span>
              <span className="text-2xl font-bold font-mono text-white mt-1 block">{overview.stats.totalAppUsers}</span>
            </div>
            <div className="p-4 rounded-2xl bg-zinc-900/50 border border-zinc-800">
              <span className="text-[10px] text-zinc-500 uppercase font-mono block">Total API Calls</span>
              <span className="text-2xl font-bold font-mono text-white mt-1 block">{overview.stats.totalRequests}</span>
            </div>
            <div className="p-4 rounded-2xl bg-zinc-900/50 border border-zinc-800">
              <span className="text-[10px] text-zinc-500 uppercase font-mono block">Pro Subscribers</span>
              <span className="text-2xl font-bold font-mono text-amber-400 mt-1 block">{overview.stats.totalPremium}</span>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="p-6 rounded-2xl bg-zinc-900/40 border border-zinc-800">
              <h4 className="text-xs font-bold text-white uppercase font-mono mb-4">Latest Registered Developers</h4>
              <div className="space-y-3">
                {overview.recentUsers.map((u: any) => (
                  <div key={u.id} className="flex items-center justify-between p-3 rounded-xl bg-zinc-950/60 border border-zinc-800 text-xs">
                    <div>
                      <span className="font-bold text-white block">{u.username}</span>
                      <span className="text-[11px] text-zinc-400">{u.email}</span>
                    </div>
                    <div className="text-right">
                      <span className="text-[10px] px-2 py-0.5 rounded font-mono uppercase bg-zinc-800 text-zinc-300">
                        {u.role}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="p-6 rounded-2xl bg-zinc-900/40 border border-zinc-800">
              <h4 className="text-xs font-bold text-white uppercase font-mono mb-4">Platform Security Activity</h4>
              <div className="space-y-3">
                {overview.recentLogs.map((l: any) => (
                  <div key={l.id} className="p-3 rounded-xl bg-zinc-950/60 border border-zinc-800 text-xs">
                    <div className="flex justify-between items-center mb-1">
                      <span className="text-red-400 font-mono font-bold text-[11px]">{l.event_type}</span>
                      <span className="text-zinc-500 text-[10px]">{new Date(l.created_at).toLocaleTimeString()}</span>
                    </div>
                    <p className="text-zinc-300 text-xs">{l.description}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB: ALL USERS */}
      {tab === 'users' && (
        <div className="rounded-2xl border border-zinc-800/80 bg-zinc-900/30 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-zinc-950/60 border-b border-zinc-800 text-zinc-400 font-mono uppercase text-[10px]">
                <tr>
                  <th className="p-3.5">Developer</th>
                  <th className="p-3.5">Email</th>
                  <th className="p-3.5">Role</th>
                  <th className="p-3.5">Plan</th>
                  <th className="p-3.5">Apps</th>
                  <th className="p-3.5">Status</th>
                  <th className="p-3.5 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-800/60 text-zinc-300">
                {users.map((u) => (
                  <tr key={u.id} className="hover:bg-zinc-800/20">
                    <td className="p-3.5 font-bold text-white font-mono">{u.username}</td>
                    <td className="p-3.5 text-zinc-400">{u.email}</td>
                    <td className="p-3.5 font-mono">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${u.role === 'ADMIN' ? 'bg-red-500/20 text-red-300' : 'bg-zinc-800 text-zinc-300'}`}>
                        {u.role}
                      </span>
                    </td>
                    <td className="p-3.5 font-mono text-zinc-400 uppercase text-[11px]">{u.subscription_tier}</td>
                    <td className="p-3.5 font-mono">{u.app_count}</td>
                    <td className="p-3.5">
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${u.is_suspended ? 'bg-red-500/10 text-red-400' : 'bg-emerald-500/10 text-emerald-400'}`}>
                        {u.is_suspended ? 'SUSPENDED' : 'ACTIVE'}
                      </span>
                    </td>
                    <td className="p-3.5 text-right">
                      <div className="flex items-center justify-end gap-2">
                        <button
                          onClick={() => handleToggleRole(u.id, u.role)}
                          className="px-2.5 py-1 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-300 text-[10px] font-semibold"
                        >
                          Make {u.role === 'ADMIN' ? 'User' : 'Admin'}
                        </button>
                        <button
                          onClick={() => handleToggleSuspend(u.id, u.is_suspended)}
                          className={`px-2.5 py-1 rounded-lg text-[10px] font-semibold ${
                            u.is_suspended
                              ? 'bg-emerald-600 hover:bg-emerald-500 text-white'
                              : 'bg-red-600 hover:bg-red-500 text-white'
                          }`}
                        >
                          {u.is_suspended ? 'Unsuspend' : 'Suspend'}
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB: ALL APPLICATIONS */}
      {tab === 'apps' && (
        <div className="rounded-2xl border border-zinc-800/80 bg-zinc-900/30 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-zinc-950/60 border-b border-zinc-800 text-zinc-400 font-mono uppercase text-[10px]">
                <tr>
                  <th className="p-3.5">Application</th>
                  <th className="p-3.5">Owner</th>
                  <th className="p-3.5">App ID</th>
                  <th className="p-3.5">Users</th>
                  <th className="p-3.5">Licenses</th>
                  <th className="p-3.5">Status</th>
                  <th className="p-3.5 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-800/60 text-zinc-300">
                {apps.map((a) => (
                  <tr key={a.id} className="hover:bg-zinc-800/20">
                    <td className="p-3.5 font-bold text-white">{a.name}</td>
                    <td className="p-3.5 text-zinc-400">{a.owner_username} ({a.owner_email})</td>
                    <td className="p-3.5 font-mono text-zinc-300">{a.id}</td>
                    <td className="p-3.5 font-mono">{a.user_count}</td>
                    <td className="p-3.5 font-mono">{a.license_count}</td>
                    <td className="p-3.5">
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${a.status === 'ACTIVE' ? 'bg-emerald-500/10 text-emerald-400' : 'bg-red-500/10 text-red-400'}`}>
                        {a.status}
                      </span>
                    </td>
                    <td className="p-3.5 text-right">
                      <button
                        onClick={() => handleToggleAppStatus(a.id, a.status)}
                        className={`px-3 py-1 rounded-lg text-[10px] font-bold ${
                          a.status === 'ACTIVE'
                            ? 'bg-amber-600 hover:bg-amber-500 text-white'
                            : 'bg-emerald-600 hover:bg-emerald-500 text-white'
                        }`}
                      >
                        {a.status === 'ACTIVE' ? 'Disable App' : 'Enable App'}
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB: AUDIT LOGS */}
      {tab === 'logs' && (
        <div className="rounded-2xl border border-zinc-800/80 bg-zinc-900/30 overflow-hidden font-mono text-xs">
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead className="bg-zinc-950/60 border-b border-zinc-800 text-zinc-400 uppercase text-[10px]">
                <tr>
                  <th className="p-3.5">Event</th>
                  <th className="p-3.5">Description</th>
                  <th className="p-3.5">IP</th>
                  <th className="p-3.5 text-right">Timestamp</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-800/60 text-zinc-300">
                {logs.map((l) => (
                  <tr key={l.id}>
                    <td className="p-3.5 text-red-400 font-bold">{l.event_type}</td>
                    <td className="p-3.5 text-zinc-200 font-sans text-xs">{l.description}</td>
                    <td className="p-3.5 text-zinc-500">{l.ip_address || '127.0.0.1'}</td>
                    <td className="p-3.5 text-right text-zinc-500">{new Date(l.created_at).toLocaleString()}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
