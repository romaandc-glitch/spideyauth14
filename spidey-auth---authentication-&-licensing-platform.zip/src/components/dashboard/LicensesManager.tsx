import React, { useState, useEffect } from 'react';
import {
  KeyRound,
  Plus,
  Layers,
  Search,
  Filter,
  Copy,
  Check,
  RefreshCw,
  Trash2,
  Ban,
  CheckCircle2,
  Calendar,
  AlertTriangle,
  Sparkles,
  ChevronLeft,
  ChevronRight,
  ShieldAlert,
} from 'lucide-react';
import { Application, LicenseKey, Subscription } from '../../types';
import { Modal } from '../ui/Modal';
import { api } from '../../services/api';
import { useToast } from '../ui/Toast';

interface LicensesManagerProps {
  activeApp: Application | null;
  subscription: Subscription;
  onNavigate: (view: string) => void;
  onRefreshApps: () => void;
}

export const LicensesManager: React.FC<LicensesManagerProps> = ({
  activeApp,
  subscription,
  onNavigate,
  onRefreshApps,
}) => {
  const [licenses, setLicenses] = useState<LicenseKey[]>([]);
  const [loading, setLoading] = useState(false);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [typeFilter, setTypeFilter] = useState('all');
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [totalCount, setTotalCount] = useState(0);
  const [totalKeysInApp, setTotalKeysInApp] = useState(0);

  // Modals
  const [isSingleOpen, setIsSingleOpen] = useState(false);
  const [isBulkOpen, setIsBulkOpen] = useState(false);
  const [selectedKey, setSelectedKey] = useState<LicenseKey | null>(null);
  const [isDeleteOpen, setIsDeleteOpen] = useState(false);

  // Generation form fields
  const [prefix, setPrefix] = useState('SPIDEY');
  const [subscriptionType, setSubscriptionType] = useState('standard');
  const [maxActivations, setMaxActivations] = useState(1);
  const [expiresAt, setExpiresAt] = useState('');
  const [notes, setNotes] = useState('');
  const [bulkCount, setBulkCount] = useState(5);

  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  const toast = useToast();

  const maxLimit = 100000;

  useEffect(() => {
    if (activeApp) {
      loadLicenses();
    }
  }, [activeApp?.id, page, statusFilter, typeFilter]);

  const loadLicenses = async () => {
    if (!activeApp) return;
    setLoading(true);
    try {
      const res = await api.listLicenses(activeApp.id, {
        search,
        status: statusFilter,
        type: typeFilter,
        page,
        limit: 10,
      });
      setLicenses(res.licenses);
      setTotalKeysInApp(res.totalKeysInApp);
      setTotalPages(res.pagination.pages || 1);
      setTotalCount(res.pagination.total || 0);
    } catch (err: any) {
      toast.error(err.message || 'Failed to fetch licenses');
    } finally {
      setLoading(false);
    }
  };

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setPage(1);
    loadLicenses();
  };

  const handleGenerateSingle = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeApp) return;

    setLoading(true);
    try {
      const res = await api.generateSingleLicense(activeApp.id, {
        prefix,
        subscriptionType,
        maxActivations,
        expiresAt: expiresAt ? new Date(expiresAt).toISOString() : undefined,
        notes: notes.trim() || undefined,
      });

      toast.success(`License ${res.license.key} generated successfully!`, 'Key Generated');
      setIsSingleOpen(false);
      resetForm();
      loadLicenses();
      onRefreshApps();
    } catch (err: any) {
      toast.error(err.message || 'Failed to generate license');
    } finally {
      setLoading(false);
    }
  };

  const handleGenerateBulk = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeApp) return;

    setLoading(true);
    try {
      const res = await api.generateBulkLicenses(activeApp.id, {
        count: bulkCount,
        prefix,
        subscriptionType,
        maxActivations,
        expiresAt: expiresAt ? new Date(expiresAt).toISOString() : undefined,
        notes: notes.trim() || undefined,
      });

      toast.success(`Generated ${res.count} license keys successfully!`, 'Bulk Keys Created');
      setIsBulkOpen(false);
      resetForm();
      loadLicenses();
      onRefreshApps();
    } catch (err: any) {
      toast.error(err.message || 'Failed to generate bulk licenses');
    } finally {
      setLoading(false);
    }
  };

  const handleToggleRevoke = async (lic: LicenseKey) => {
    if (!activeApp) return;
    const newStatus = lic.status === 'REVOKED' ? 'ACTIVE' : 'REVOKED';
    try {
      await api.updateLicense(activeApp.id, lic.id, { status: newStatus as any });
      toast.success(`License status is now ${newStatus}.`);
      loadLicenses();
    } catch (err: any) {
      toast.error(err.message || 'Failed to update license status');
    }
  };

  const handleDeleteLicense = async () => {
    if (!activeApp || !selectedKey) return;
    setLoading(true);
    try {
      await api.deleteLicense(activeApp.id, selectedKey.id);
      toast.success(`License ${selectedKey.key} deleted.`);
      setIsDeleteOpen(false);
      loadLicenses();
      onRefreshApps();
    } catch (err: any) {
      toast.error(err.message || 'Failed to delete license');
    } finally {
      setLoading(false);
    }
  };

  const copyKey = (key: string) => {
    navigator.clipboard.writeText(key);
    setCopiedKey(key);
    toast.success('License key copied to clipboard!');
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const resetForm = () => {
    setPrefix('SPIDEY');
    setSubscriptionType('standard');
    setMaxActivations(1);
    setExpiresAt('');
    setNotes('');
    setBulkCount(5);
  };

  if (!activeApp) {
    return (
      <div className="p-8 text-center bg-zinc-900/30 border border-zinc-800 rounded-3xl">
        <KeyRound className="w-12 h-12 text-zinc-500 mx-auto mb-4" />
        <h3 className="text-lg font-bold text-white mb-2">No Application Selected</h3>
        <p className="text-xs text-zinc-400 mb-4">Select or create an application to generate and manage license keys.</p>
        <button
          onClick={() => onNavigate('applications')}
          className="px-5 py-2 rounded-xl bg-red-600 text-white text-xs font-bold uppercase tracking-wider"
        >
          View Applications
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
            <KeyRound className="w-5 h-5 text-red-500" />
            License Key Management
          </h2>
          <p className="text-xs text-zinc-400 mt-1">
            Generate and monitor software licenses for <strong className="text-zinc-200">{activeApp.name}</strong>.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => {
              resetForm();
              setIsSingleOpen(true);
            }}
            className="px-3.5 py-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-white font-bold text-xs uppercase tracking-wider flex items-center gap-1.5 border border-zinc-700/60 transition-colors"
          >
            <Plus className="w-4 h-4 text-red-400" /> GENERATE KEY
          </button>
          <button
            onClick={() => {
              resetForm();
              setIsBulkOpen(true);
            }}
            className="px-3.5 py-2 rounded-xl bg-red-600 hover:bg-red-500 text-white font-bold text-xs uppercase tracking-wider flex items-center gap-1.5 shadow-[0_0_20px_rgba(239,68,68,0.3)] transition-colors"
          >
            <Layers className="w-4 h-4" /> GENERATE MULTIPLE
          </button>
        </div>
      </div>

      {/* Unlimited Keys Banner */}
      <div className="p-3.5 rounded-2xl bg-zinc-900/40 border border-zinc-800/80 text-zinc-300 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-xl bg-emerald-500/20 text-emerald-400">
            <KeyRound className="w-4 h-4" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold uppercase tracking-wider text-white">Unlimited License Keys Enabled</span>
              <span className="text-[10px] font-mono font-bold bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded border border-emerald-500/30 uppercase">
                Free Forever
              </span>
            </div>
            <p className="text-xs text-zinc-400 mt-0.5">
              Create unlimited single or bulk license keys with zero limits. Works directly with KeyAuth v1 drop-in SDKs.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <span className="text-xs font-mono font-bold bg-zinc-950 px-3 py-1 rounded-xl border border-zinc-800 text-zinc-200">
            {totalKeysInApp} Total Keys
          </span>
        </div>
      </div>

      {/* Search and Filters */}
      <div className="p-4 rounded-2xl bg-zinc-900/40 border border-zinc-800/80 backdrop-blur-xl flex flex-col sm:flex-row items-center justify-between gap-3">
        <form onSubmit={handleSearchSubmit} className="relative w-full sm:w-80">
          <Search className="absolute left-3 top-2.5 w-4 h-4 text-zinc-500" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search key or notes..."
            className="w-full bg-zinc-950/80 border border-zinc-800 rounded-xl py-2 pl-9 pr-3 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-red-500 font-mono"
          />
        </form>

        <div className="flex items-center gap-2 w-full sm:w-auto justify-end flex-wrap">
          <div className="flex items-center gap-1.5 bg-zinc-950/80 border border-zinc-800 px-3 py-1.5 rounded-xl text-xs">
            <span className="text-zinc-500">Status:</span>
            <select
              value={statusFilter}
              onChange={(e) => {
                setStatusFilter(e.target.value);
                setPage(1);
              }}
              className="bg-transparent text-zinc-300 font-semibold focus:outline-none cursor-pointer"
            >
              <option value="all" className="bg-zinc-900 text-white">All</option>
              <option value="ACTIVE" className="bg-zinc-900 text-white">ACTIVE</option>
              <option value="USED" className="bg-zinc-900 text-white">USED</option>
              <option value="EXPIRED" className="bg-zinc-900 text-white">EXPIRED</option>
              <option value="REVOKED" className="bg-zinc-900 text-white">REVOKED</option>
              <option value="BANNED" className="bg-zinc-900 text-white">BANNED</option>
            </select>
          </div>

          <div className="flex items-center gap-1.5 bg-zinc-950/80 border border-zinc-800 px-3 py-1.5 rounded-xl text-xs">
            <span className="text-zinc-500">Type:</span>
            <select
              value={typeFilter}
              onChange={(e) => {
                setTypeFilter(e.target.value);
                setPage(1);
              }}
              className="bg-transparent text-zinc-300 font-semibold focus:outline-none cursor-pointer"
            >
              <option value="all" className="bg-zinc-900 text-white">All Types</option>
              <option value="standard" className="bg-zinc-900 text-white">Standard</option>
              <option value="lifetime" className="bg-zinc-900 text-white">Lifetime</option>
              <option value="trial" className="bg-zinc-900 text-white">Trial</option>
              <option value="vip" className="bg-zinc-900 text-white">VIP</option>
            </select>
          </div>

          <button
            onClick={loadLicenses}
            className="p-2 rounded-xl bg-zinc-950/80 border border-zinc-800 text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors"
            title="Refresh keys"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          </button>
        </div>
      </div>

      {/* Licenses Table */}
      <div className="rounded-2xl border border-zinc-800/80 bg-zinc-900/30 backdrop-blur-xl overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-zinc-950/60 border-b border-zinc-800 text-zinc-400 font-mono uppercase text-[10px] tracking-wider">
              <tr>
                <th className="py-3 px-4">License Key</th>
                <th className="py-3 px-4">Type</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4">Activations</th>
                <th className="py-3 px-4">Created</th>
                <th className="py-3 px-4">Expiration</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-800/60 text-zinc-300 font-mono">
              {licenses.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-zinc-500 font-sans">
                    {loading ? 'Loading licenses...' : 'No license keys found. Click "GENERATE KEY" to create one.'}
                  </td>
                </tr>
              ) : (
                licenses.map((lic) => (
                  <tr key={lic.id} className="hover:bg-zinc-800/20 transition-colors group">
                    <td className="py-3.5 px-4 font-bold text-white flex items-center gap-2">
                      <span className="tracking-wider">{lic.key}</span>
                      <button
                        onClick={() => copyKey(lic.key)}
                        className="text-zinc-500 hover:text-white p-1 rounded hover:bg-zinc-800 transition-colors"
                        title="Copy key"
                      >
                        {copiedKey === lic.key ? (
                          <Check className="w-3.5 h-3.5 text-emerald-400" />
                        ) : (
                          <Copy className="w-3.5 h-3.5" />
                        )}
                      </button>
                    </td>

                    <td className="py-3.5 px-4">
                      <span className="text-[11px] px-2 py-0.5 rounded bg-zinc-800 text-zinc-300 uppercase font-semibold">
                        {lic.subscription_type}
                      </span>
                    </td>

                    <td className="py-3.5 px-4">
                      <span
                        className={`text-[10px] font-bold px-2 py-0.5 rounded-full border uppercase ${
                          lic.status === 'ACTIVE'
                            ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
                            : lic.status === 'USED'
                            ? 'bg-blue-500/10 text-blue-400 border-blue-500/30'
                            : lic.status === 'EXPIRED'
                            ? 'bg-zinc-800 text-zinc-400 border-zinc-700'
                            : 'bg-red-500/10 text-red-400 border-red-500/30'
                        }`}
                      >
                        {lic.status}
                      </span>
                    </td>

                    <td className="py-3.5 px-4 text-zinc-200">
                      {lic.current_activations} / {lic.max_activations}
                    </td>

                    <td className="py-3.5 px-4 text-[11px] text-zinc-400">
                      {new Date(lic.created_at).toLocaleDateString()}
                    </td>

                    <td className="py-3.5 px-4 text-[11px] text-zinc-400">
                      {lic.expires_at ? new Date(lic.expires_at).toLocaleDateString() : 'Never'}
                    </td>

                    <td className="py-3.5 px-4 text-right">
                      <div className="flex items-center justify-end gap-1 font-sans">
                        <button
                          onClick={() => handleToggleRevoke(lic)}
                          className={`p-1.5 rounded-lg transition-colors ${
                            lic.status === 'REVOKED'
                              ? 'text-emerald-400 hover:bg-emerald-500/10'
                              : 'text-amber-400 hover:bg-amber-500/10'
                          }`}
                          title={lic.status === 'REVOKED' ? 'Reactivate key' : 'Revoke key'}
                        >
                          <Ban className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => {
                            setSelectedKey(lic);
                            setIsDeleteOpen(true);
                          }}
                          className="p-1.5 rounded-lg text-red-400 hover:text-red-300 hover:bg-red-500/10 transition-colors"
                          title="Delete key"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="p-4 border-t border-zinc-800 flex items-center justify-between text-xs text-zinc-400 font-sans">
            <span>
              Showing {licenses.length} of {totalCount} keys
            </span>
            <div className="flex items-center gap-2 font-mono">
              <button
                disabled={page <= 1}
                onClick={() => setPage((p) => Math.max(1, p - 1))}
                className="p-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 disabled:opacity-40 transition-colors"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <span className="text-white font-bold">
                {page} / {totalPages}
              </span>
              <button
                disabled={page >= totalPages}
                onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
                className="p-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 disabled:opacity-40 transition-colors"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}
      </div>

      {/* GENERATE SINGLE KEY MODAL */}
      <Modal
        isOpen={isSingleOpen}
        onClose={() => setIsSingleOpen(false)}
        title="Generate License Key"
        subtitle={`Generate a new key for ${activeApp.name}`}
      >
        <form onSubmit={handleGenerateSingle} className="space-y-3.5">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-zinc-300 mb-1">Key Prefix</label>
              <input
                type="text"
                value={prefix}
                onChange={(e) => setPrefix(e.target.value.toUpperCase())}
                placeholder="SPIDEY"
                className="w-full bg-zinc-900 border border-zinc-800 rounded-xl py-2 px-3 text-xs text-white font-mono uppercase focus:outline-none focus:border-red-500"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-zinc-300 mb-1">Subscription Type</label>
              <select
                value={subscriptionType}
                onChange={(e) => setSubscriptionType(e.target.value)}
                className="w-full bg-zinc-900 border border-zinc-800 rounded-xl py-2 px-3 text-xs text-white focus:outline-none focus:border-red-500"
              >
                <option value="standard">Standard</option>
                <option value="lifetime">Lifetime</option>
                <option value="trial">Trial (30-day)</option>
                <option value="vip">VIP</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-zinc-300 mb-1">Max Activations</label>
              <input
                type="number"
                min="1"
                max="50"
                value={maxActivations}
                onChange={(e) => setMaxActivations(parseInt(e.target.value, 10) || 1)}
                className="w-full bg-zinc-900 border border-zinc-800 rounded-xl py-2 px-3 text-xs text-white font-mono focus:outline-none focus:border-red-500"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-zinc-300 mb-1">Expiration Date</label>
              <input
                type="date"
                value={expiresAt}
                onChange={(e) => setExpiresAt(e.target.value)}
                className="w-full bg-zinc-900 border border-zinc-800 rounded-xl py-2 px-3 text-xs text-white focus:outline-none focus:border-red-500"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-zinc-300 mb-1">Notes (Optional)</label>
            <input
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="e.g. VIP Giveaway winner"
              className="w-full bg-zinc-900 border border-zinc-800 rounded-xl py-2 px-3 text-xs text-white focus:outline-none focus:border-red-500"
            />
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setIsSingleOpen(false)}
              className="px-4 py-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-300 text-xs font-semibold"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={loading}
              className="px-5 py-2 rounded-xl bg-red-600 hover:bg-red-500 text-white text-xs font-bold uppercase tracking-wider"
            >
              {loading ? 'Generating...' : 'Generate Key'}
            </button>
          </div>
        </form>
      </Modal>

      {/* GENERATE MULTIPLE KEYS MODAL */}
      <Modal
        isOpen={isBulkOpen}
        onClose={() => setIsBulkOpen(false)}
        title="Generate Multiple Licenses"
        subtitle={`Bulk key generation for ${activeApp.name}`}
      >
        <form onSubmit={handleGenerateBulk} className="space-y-3.5">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-zinc-300 mb-1">Key Count (1 - 100)</label>
              <input
                type="number"
                min="1"
                max={100}
                value={bulkCount}
                onChange={(e) => setBulkCount(parseInt(e.target.value, 10) || 1)}
                className="w-full bg-zinc-900 border border-zinc-800 rounded-xl py-2 px-3 text-xs text-white font-mono focus:outline-none focus:border-red-500"
                required
              />
              <span className="text-[10px] text-emerald-400 mt-1 block">
                Unlimited keys allowed (batch up to 100)
              </span>
            </div>

            <div>
              <label className="block text-xs font-semibold text-zinc-300 mb-1">Prefix</label>
              <input
                type="text"
                value={prefix}
                onChange={(e) => setPrefix(e.target.value.toUpperCase())}
                placeholder="SPIDEY"
                className="w-full bg-zinc-900 border border-zinc-800 rounded-xl py-2 px-3 text-xs text-white font-mono uppercase focus:outline-none focus:border-red-500"
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-zinc-300 mb-1">Subscription Type</label>
              <select
                value={subscriptionType}
                onChange={(e) => setSubscriptionType(e.target.value)}
                className="w-full bg-zinc-900 border border-zinc-800 rounded-xl py-2 px-3 text-xs text-white focus:outline-none focus:border-red-500"
              >
                <option value="standard">Standard</option>
                <option value="lifetime">Lifetime</option>
                <option value="trial">Trial</option>
                <option value="vip">VIP</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-zinc-300 mb-1">Max Activations</label>
              <input
                type="number"
                min="1"
                max="25"
                value={maxActivations}
                onChange={(e) => setMaxActivations(parseInt(e.target.value, 10) || 1)}
                className="w-full bg-zinc-900 border border-zinc-800 rounded-xl py-2 px-3 text-xs text-white font-mono focus:outline-none focus:border-red-500"
                required
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-zinc-300 mb-1">Expiration Date (Optional)</label>
            <input
              type="date"
              value={expiresAt}
              onChange={(e) => setExpiresAt(e.target.value)}
              className="w-full bg-zinc-900 border border-zinc-800 rounded-xl py-2 px-3 text-xs text-white focus:outline-none focus:border-red-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-zinc-300 mb-1">Batch Notes</label>
            <input
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="e.g. Tournament batch"
              className="w-full bg-zinc-900 border border-zinc-800 rounded-xl py-2 px-3 text-xs text-white focus:outline-none focus:border-red-500"
            />
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setIsBulkOpen(false)}
              className="px-4 py-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-300 text-xs font-semibold"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={loading}
              className="px-5 py-2 rounded-xl bg-red-600 hover:bg-red-500 text-white text-xs font-bold uppercase tracking-wider"
            >
              {loading ? 'Generating...' : `Generate ${bulkCount} Keys`}
            </button>
          </div>
        </form>
      </Modal>

      {/* DELETE KEY CONFIRMATION MODAL */}
      <Modal
        isOpen={isDeleteOpen}
        onClose={() => setIsDeleteOpen(false)}
        title="Delete License Key"
        subtitle={`Remove key ${selectedKey?.key}`}
      >
        <div className="space-y-4">
          <p className="text-xs text-zinc-300">
            Are you sure you want to delete license key <strong className="font-mono text-white">{selectedKey?.key}</strong>?
            Any client device currently activated with this license key will no longer validate successfully.
          </p>
          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setIsDeleteOpen(false)}
              className="px-4 py-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-300 text-xs font-semibold"
            >
              Cancel
            </button>
            <button
              onClick={handleDeleteLicense}
              disabled={loading}
              className="px-5 py-2 rounded-xl bg-red-600 hover:bg-red-500 text-white text-xs font-bold uppercase tracking-wider"
            >
              {loading ? 'Deleting...' : 'Delete Key'}
            </button>
          </div>
        </div>
      </Modal>
    </div>
  );
};
