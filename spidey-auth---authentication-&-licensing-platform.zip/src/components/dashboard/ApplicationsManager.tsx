import React, { useState } from 'react';
import {
  Layers,
  Plus,
  RefreshCw,
  Copy,
  Check,
  Eye,
  EyeOff,
  Edit2,
  Trash2,
  Power,
  KeyRound,
  Users,
  Activity,
  Shield,
  ArrowRight,
  Zap,
} from 'lucide-react';
import { Application } from '../../types';
import { Modal } from '../ui/Modal';
import { api } from '../../services/api';
import { useToast } from '../ui/Toast';

interface ApplicationsManagerProps {
  applications: Application[];
  activeAppId: string | null;
  onSelectApp: (id: string) => void;
  onRefresh: () => void;
  onNavigate: (view: string) => void;
}

export const ApplicationsManager: React.FC<ApplicationsManagerProps> = ({
  applications,
  activeAppId,
  onSelectApp,
  onRefresh,
  onNavigate,
}) => {
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [isEditOpen, setIsEditOpen] = useState(false);
  const [isDeleteOpen, setIsDeleteOpen] = useState(false);
  const [isRegenerateOpen, setIsRegenerateOpen] = useState(false);
  const [selectedApp, setSelectedApp] = useState<Application | null>(null);
  const [keyAuthApp, setKeyAuthApp] = useState<Application | null>(null);

  // Form states
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [version, setVersion] = useState('1.0.0');
  const [status, setStatus] = useState<'ACTIVE' | 'DISABLED'>('ACTIVE');
  const [loading, setLoading] = useState(false);

  // Secret display
  const [revealedSecrets, setRevealedSecrets] = useState<Record<string, string>>({});
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const toast = useToast();

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    setLoading(true);
    try {
      const res = await api.createApplication(name, description, version);
      toast.success(`Application "${res.application.name}" created successfully!`, 'App Created');
      setIsCreateOpen(false);
      setName('');
      setDescription('');
      setVersion('1.0.0');
      onRefresh();
      onSelectApp(res.application.id);
    } catch (err: any) {
      toast.error(err.message || 'Failed to create application');
    } finally {
      setLoading(false);
    }
  };

  const handleEdit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedApp) return;

    setLoading(true);
    try {
      await api.updateApplication(selectedApp.id, { name, description, version, status });
      toast.success('Application updated successfully!');
      setIsEditOpen(false);
      onRefresh();
    } catch (err: any) {
      toast.error(err.message || 'Failed to update application');
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async () => {
    if (!selectedApp) return;
    setLoading(true);
    try {
      await api.deleteApplication(selectedApp.id);
      toast.success(`Application "${selectedApp.name}" deleted.`);
      setIsDeleteOpen(false);
      onRefresh();
    } catch (err: any) {
      toast.error(err.message || 'Failed to delete application');
    } finally {
      setLoading(false);
    }
  };

  const handleRegenerateSecret = async () => {
    if (!selectedApp) return;
    setLoading(true);
    try {
      const res = await api.regenerateSecret(selectedApp.id);
      toast.success('Application secret regenerated!');
      setRevealedSecrets((prev) => ({ ...prev, [selectedApp.id]: res.secret }));
      setIsRegenerateOpen(false);
      onRefresh();
    } catch (err: any) {
      toast.error(err.message || 'Failed to regenerate secret');
    } finally {
      setLoading(false);
    }
  };

  const handleToggleRevealSecret = async (appId: string) => {
    if (revealedSecrets[appId]) {
      setRevealedSecrets((prev) => {
        const copy = { ...prev };
        delete copy[appId];
        return copy;
      });
      return;
    }

    try {
      const res = await api.revealSecret(appId);
      setRevealedSecrets((prev) => ({ ...prev, [appId]: res.secret }));
    } catch (err: any) {
      toast.error(err.message || 'Failed to retrieve secret');
    }
  };

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(label);
    toast.success(`Copied ${label} to clipboard!`);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const openEditModal = (app: Application) => {
    setSelectedApp(app);
    setName(app.name);
    setDescription(app.description || '');
    setVersion(app.version || '1.0.0');
    setStatus(app.status);
    setIsEditOpen(true);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
            <Layers className="w-5 h-5 text-red-500" />
            Developer Applications
          </h2>
          <p className="text-xs text-zinc-400 mt-1">
            Create and isolate client software environments. Each application possesses its own users, license keys, and API secrets.
          </p>
        </div>

        <button
          onClick={() => {
            setName('');
            setDescription('');
            setVersion('1.0.0');
            setIsCreateOpen(true);
          }}
          className="px-4 py-2 rounded-xl bg-red-600 hover:bg-red-500 text-white font-bold text-xs uppercase tracking-wider flex items-center gap-1.5 shadow-[0_0_20px_rgba(239,68,68,0.3)] transition-colors"
        >
          <Plus className="w-4 h-4" /> CREATE APPLICATION
        </button>
      </div>

      {/* Applications Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {applications.map((app) => {
          const isActive = app.id === activeAppId;
          const secret = revealedSecrets[app.id] || app.secretMasked || '••••••••••••••••';

          return (
            <div
              key={app.id}
              className={`p-6 rounded-2xl border backdrop-blur-xl transition-all duration-300 relative flex flex-col justify-between ${
                isActive
                  ? 'bg-zinc-900/80 border-red-500/40 shadow-[0_0_30px_rgba(239,68,68,0.12)]'
                  : 'bg-zinc-900/40 border-zinc-800/80 hover:border-zinc-700'
              }`}
            >
              <div>
                <div className="flex items-start justify-between gap-2 mb-3">
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="text-base font-bold text-white tracking-tight">{app.name}</h3>
                      <span className="text-[10px] font-mono text-zinc-400 bg-zinc-800 px-1.5 py-0.5 rounded">
                        v{app.version}
                      </span>
                    </div>
                    {app.description && (
                      <p className="text-xs text-zinc-400 mt-1 line-clamp-2">{app.description}</p>
                    )}
                  </div>

                  <span
                    className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded-full border ${
                      app.status === 'ACTIVE'
                        ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
                        : 'bg-red-500/10 text-red-400 border-red-500/30'
                    }`}
                  >
                    {app.status}
                  </span>
                </div>

                {/* Credentials */}
                <div className="space-y-2 my-4 font-mono text-xs">
                  <div className="flex items-center justify-between p-2 rounded-xl bg-zinc-950/60 border border-zinc-800">
                    <span className="text-[11px] text-zinc-500">App ID:</span>
                    <div className="flex items-center gap-1.5">
                      <span className="text-zinc-200 font-bold">{app.id}</span>
                      <button
                        onClick={() => copyToClipboard(app.id, app.id)}
                        className="text-zinc-400 hover:text-white p-1 rounded"
                      >
                        {copiedId === app.id ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                      </button>
                    </div>
                  </div>

                  <div className="flex items-center justify-between p-2 rounded-xl bg-zinc-950/60 border border-zinc-800">
                    <span className="text-[11px] text-zinc-500">Owner ID:</span>
                    <div className="flex items-center gap-1.5">
                      <span className="text-zinc-200 font-bold">{app.owner_code}</span>
                      <button
                        onClick={() => copyToClipboard(app.owner_code, app.owner_code)}
                        className="text-zinc-400 hover:text-white p-1 rounded"
                      >
                        {copiedId === app.owner_code ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                      </button>
                    </div>
                  </div>

                  <div className="flex items-center justify-between p-2 rounded-xl bg-zinc-950/60 border border-zinc-800">
                    <span className="text-[11px] text-zinc-500">App Secret:</span>
                    <div className="flex items-center gap-1.5 truncate max-w-[210px]">
                      <span className="text-red-400 font-bold truncate block">{secret}</span>
                      <button
                        onClick={() => handleToggleRevealSecret(app.id)}
                        className="text-zinc-400 hover:text-white p-1 rounded"
                      >
                        {revealedSecrets[app.id] ? <EyeOff className="w-3.5 h-3.5 text-amber-400" /> : <Eye className="w-3.5 h-3.5" />}
                      </button>
                      <button
                        onClick={() => copyToClipboard(revealedSecrets[app.id] || '', 'Secret')}
                        className="text-zinc-400 hover:text-white p-1 rounded"
                      >
                        {copiedId === 'Secret' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                      </button>
                    </div>
                  </div>
                </div>

                {/* Quick App Stats */}
                <div className="grid grid-cols-3 gap-2 py-3 border-t border-zinc-800/60 text-center font-mono">
                  <div className="p-2 rounded-lg bg-zinc-950/40">
                    <span className="text-[10px] text-zinc-500 block uppercase">Users</span>
                    <span className="text-xs font-bold text-white">{app.user_count || 0}</span>
                  </div>
                  <div className="p-2 rounded-lg bg-zinc-950/40">
                    <span className="text-[10px] text-zinc-500 block uppercase">Keys</span>
                    <span className="text-xs font-bold text-white">{app.license_count || 0}</span>
                  </div>
                  <div className="p-2 rounded-lg bg-zinc-950/40">
                    <span className="text-[10px] text-zinc-500 block uppercase">Calls</span>
                    <span className="text-xs font-bold text-white">{app.request_count || 0}</span>
                  </div>
                </div>
              </div>

              {/* Action buttons */}
              <div className="mt-4 pt-3 border-t border-zinc-800/80 flex items-center justify-between gap-2">
                <div className="flex items-center gap-1.5">
                  <button
                    onClick={() => setKeyAuthApp(app)}
                    className="p-1.5 rounded-lg text-amber-400 hover:text-amber-300 hover:bg-amber-500/10 transition-colors"
                    title="KeyAuth Drop-In Credentials & Code"
                  >
                    <Zap className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => openEditModal(app)}
                    className="p-1.5 rounded-lg text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors"
                    title="Edit application"
                  >
                    <Edit2 className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => {
                      setSelectedApp(app);
                      setIsRegenerateOpen(true);
                    }}
                    className="p-1.5 rounded-lg text-amber-400/80 hover:text-amber-300 hover:bg-amber-500/10 transition-colors"
                    title="Regenerate application secret"
                  >
                    <RefreshCw className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => {
                      setSelectedApp(app);
                      setIsDeleteOpen(true);
                    }}
                    className="p-1.5 rounded-lg text-red-400/80 hover:text-red-300 hover:bg-red-500/10 transition-colors"
                    title="Delete application"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>

                {isActive ? (
                  <span className="text-xs font-bold text-red-400 flex items-center gap-1 font-mono">
                    ACTIVE SELECTED ✓
                  </span>
                ) : (
                  <button
                    onClick={() => onSelectApp(app.id)}
                    className="px-3 py-1.5 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-white text-xs font-semibold transition-colors flex items-center gap-1"
                  >
                    Select App <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* CREATE APPLICATION MODAL */}
      <Modal
        isOpen={isCreateOpen}
        onClose={() => setIsCreateOpen(false)}
        title="Create New Application"
        subtitle="Provision an isolated developer application with automated cryptographic secrets."
      >
        <form onSubmit={handleCreate} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-zinc-300 mb-1.5">Application Name</label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g., Apex Velocity Launcher"
              className="w-full bg-zinc-900 border border-zinc-800 rounded-xl py-2 px-3 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-red-500"
              required
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-zinc-300 mb-1.5">Description (Optional)</label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Brief description of what this application does..."
              className="w-full bg-zinc-900 border border-zinc-800 rounded-xl py-2 px-3 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-red-500 h-20 resize-none"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-zinc-300 mb-1.5">Version</label>
            <input
              type="text"
              value={version}
              onChange={(e) => setVersion(e.target.value)}
              placeholder="1.0.0"
              className="w-full bg-zinc-900 border border-zinc-800 rounded-xl py-2 px-3 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-red-500 font-mono"
            />
          </div>

          <div className="p-3 rounded-xl bg-zinc-900/60 border border-zinc-800 text-[11px] text-zinc-400">
            Upon creation, an Owner ID, Application ID, and 256-bit cryptographically secure Secret will be automatically generated.
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setIsCreateOpen(false)}
              className="px-4 py-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-300 text-xs font-semibold"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={loading}
              className="px-5 py-2 rounded-xl bg-red-600 hover:bg-red-500 text-white text-xs font-bold uppercase tracking-wider"
            >
              {loading ? 'Creating...' : 'Create Application'}
            </button>
          </div>
        </form>
      </Modal>

      {/* EDIT APPLICATION MODAL */}
      <Modal
        isOpen={isEditOpen}
        onClose={() => setIsEditOpen(false)}
        title="Edit Application"
        subtitle={`Update configuration for ${selectedApp?.name}`}
      >
        <form onSubmit={handleEdit} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-zinc-300 mb-1.5">Application Name</label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full bg-zinc-900 border border-zinc-800 rounded-xl py-2 px-3 text-xs text-white focus:outline-none focus:border-red-500"
              required
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-zinc-300 mb-1.5">Description</label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full bg-zinc-900 border border-zinc-800 rounded-xl py-2 px-3 text-xs text-white focus:outline-none focus:border-red-500 h-20 resize-none"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-zinc-300 mb-1.5">Version</label>
              <input
                type="text"
                value={version}
                onChange={(e) => setVersion(e.target.value)}
                className="w-full bg-zinc-900 border border-zinc-800 rounded-xl py-2 px-3 text-xs text-white font-mono focus:outline-none focus:border-red-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-zinc-300 mb-1.5">Status</label>
              <select
                value={status}
                onChange={(e) => setStatus(e.target.value as any)}
                className="w-full bg-zinc-900 border border-zinc-800 rounded-xl py-2 px-3 text-xs text-white focus:outline-none focus:border-red-500"
              >
                <option value="ACTIVE">ACTIVE (Operational)</option>
                <option value="DISABLED">DISABLED (Reject API calls)</option>
              </select>
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setIsEditOpen(false)}
              className="px-4 py-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-300 text-xs font-semibold"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={loading}
              className="px-5 py-2 rounded-xl bg-red-600 hover:bg-red-500 text-white text-xs font-bold uppercase tracking-wider"
            >
              {loading ? 'Saving...' : 'Save Changes'}
            </button>
          </div>
        </form>
      </Modal>

      {/* REGENERATE SECRET MODAL */}
      <Modal
        isOpen={isRegenerateOpen}
        onClose={() => setIsRegenerateOpen(false)}
        title="Regenerate Application Secret"
        subtitle={`Generate a new cryptographic secret for ${selectedApp?.name}`}
      >
        <div className="space-y-4">
          <p className="text-xs text-zinc-300 leading-relaxed">
            Are you sure you want to regenerate the secret for <strong className="text-white">{selectedApp?.name}</strong>?
            Any client application using the old secret will need to be updated immediately with the newly generated secret. Existing users and license keys will remain intact.
          </p>

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setIsRegenerateOpen(false)}
              className="px-4 py-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-300 text-xs font-semibold"
            >
              Cancel
            </button>
            <button
              onClick={handleRegenerateSecret}
              disabled={loading}
              className="px-5 py-2 rounded-xl bg-amber-600 hover:bg-amber-500 text-white text-xs font-bold uppercase tracking-wider"
            >
              {loading ? 'Regenerating...' : 'Yes, Regenerate Secret'}
            </button>
          </div>
        </div>
      </Modal>

      {/* DELETE CONFIRMATION MODAL */}
      <Modal
        isOpen={isDeleteOpen}
        onClose={() => setIsDeleteOpen(false)}
        title="Delete Application"
        subtitle={`Permanently remove ${selectedApp?.name}`}
      >
        <div className="space-y-4">
          <p className="text-xs text-red-300 leading-relaxed bg-red-500/10 p-3 rounded-xl border border-red-500/20">
            Warning: Deleting this application will delete all associated application users, license keys, activations, and API logs. This action cannot be undone.
          </p>

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setIsDeleteOpen(false)}
              className="px-4 py-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-300 text-xs font-semibold"
            >
              Cancel
            </button>
            <button
              onClick={handleDelete}
              disabled={loading}
              className="px-5 py-2 rounded-xl bg-red-600 hover:bg-red-500 text-white text-xs font-bold uppercase tracking-wider"
            >
              {loading ? 'Deleting...' : 'Delete Application'}
            </button>
          </div>
        </div>
      </Modal>
      {/* KEYAUTH DROP-IN CREDENTIALS MODAL */}
      <Modal
        isOpen={!!keyAuthApp}
        onClose={() => setKeyAuthApp(null)}
        title="KeyAuth Drop-In Integration"
        subtitle={`Connect existing KeyAuth clients directly to ${keyAuthApp?.name}`}
      >
        <div className="space-y-4">
          <p className="text-xs text-zinc-300 leading-relaxed bg-zinc-950/60 p-3 rounded-xl border border-zinc-800">
            Spidey Auth exposes a native KeyAuth v1.3 compatibility gateway on <code className="text-amber-400 font-mono">/api/1.3/</code>.
            Drop these credentials directly into your existing KeyAuth client code:
          </p>

          <div className="space-y-2 font-mono text-xs">
            <div className="flex items-center justify-between p-2.5 rounded-xl bg-zinc-900 border border-zinc-800">
              <span className="text-zinc-500">Application Name:</span>
              <div className="flex items-center gap-2">
                <span className="text-white font-bold">{keyAuthApp?.name}</span>
                <button
                  onClick={() => copyToClipboard(keyAuthApp?.name || '', 'App Name')}
                  className="text-zinc-400 hover:text-white"
                >
                  {copiedId === 'App Name' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                </button>
              </div>
            </div>

            <div className="flex items-center justify-between p-2.5 rounded-xl bg-zinc-900 border border-zinc-800">
              <span className="text-zinc-500">Owner ID:</span>
              <div className="flex items-center gap-2">
                <span className="text-red-400 font-bold">{keyAuthApp?.owner_code}</span>
                <button
                  onClick={() => copyToClipboard(keyAuthApp?.owner_code || '', 'Owner Code')}
                  className="text-zinc-400 hover:text-white"
                >
                  {copiedId === 'Owner Code' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                </button>
              </div>
            </div>

            <div className="flex items-center justify-between p-2.5 rounded-xl bg-zinc-900 border border-zinc-800">
              <span className="text-zinc-500">Version:</span>
              <span className="text-zinc-200">{keyAuthApp?.version}</span>
            </div>

            <div className="flex items-center justify-between p-2.5 rounded-xl bg-zinc-900 border border-zinc-800">
              <span className="text-zinc-500">API Endpoint URL:</span>
              <div className="flex items-center gap-2">
                <span className="text-amber-300 font-bold">{typeof window !== 'undefined' ? `${window.location.origin}/api/1.3/` : 'http://localhost:3000/api/1.3/'}</span>
                <button
                  onClick={() => copyToClipboard(typeof window !== 'undefined' ? `${window.location.origin}/api/1.3/` : 'http://localhost:3000/api/1.3/', 'API URL')}
                  className="text-zinc-400 hover:text-white"
                >
                  {copiedId === 'API URL' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                </button>
              </div>
            </div>
          </div>

          <div className="p-3 rounded-xl bg-zinc-950 border border-zinc-800 space-y-1">
            <span className="text-[10px] text-zinc-500 uppercase font-mono block">C# Initializer snippet:</span>
            <pre className="text-[11px] font-mono text-zinc-300 overflow-x-auto p-2 bg-black/40 rounded-lg">
              {`api KeyAuthApp = new api(
    name: "${keyAuthApp?.name}",
    ownerid: "${keyAuthApp?.owner_code}",
    version: "${keyAuthApp?.version}",
    url: "${typeof window !== 'undefined' ? `${window.location.origin}/api/1.3/` : 'http://localhost:3000/api/1.3/'}"
);
KeyAuthApp.init();`}
            </pre>
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => {
                if (keyAuthApp) {
                  onSelectApp(keyAuthApp.id);
                  onNavigate('sdk');
                }
                setKeyAuthApp(null);
              }}
              className="px-4 py-2 rounded-xl bg-red-600 hover:bg-red-500 text-white text-xs font-bold"
            >
              Test in SDK Playground →
            </button>
          </div>
        </div>
      </Modal>
    </div>
  );
};
