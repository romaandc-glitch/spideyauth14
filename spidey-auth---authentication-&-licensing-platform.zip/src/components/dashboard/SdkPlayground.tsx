import React, { useState, useEffect } from 'react';
import {
  Terminal,
  Play,
  Copy,
  Check,
  Code2,
  Clock,
  Layers,
  Shield,
  KeyRound,
  Users,
  CheckCircle2,
  XCircle,
  ExternalLink,
  Zap,
} from 'lucide-react';
import { Application } from '../../types';
import { api } from '../../services/api';
import { CodeBlock } from '../ui/CodeBlock';
import { useToast } from '../ui/Toast';

interface SdkPlaygroundProps {
  activeApp: Application | null;
  onNavigate: (view: string) => void;
}

export const SdkPlayground: React.FC<SdkPlaygroundProps> = ({ activeApp, onNavigate }) => {
  // Protocol mode: KeyAuth v1 Drop-in vs Native Spidey Auth
  const [protocol, setProtocol] = useState<'keyauth' | 'native'>('keyauth');

  // Native API action
  const [action, setAction] = useState<'login' | 'register' | 'activate' | 'validate' | 'reset-pass'>('login');
  
  // KeyAuth API action
  const [keyauthAction, setKeyauthAction] = useState<'init' | 'login' | 'register' | 'license' | 'check' | 'fetchstats' | 'upgrade' | 'var' | 'setvar' | 'checkblacklist' | 'log'>('init');

  const [language, setLanguage] = useState<'csharp' | 'winforms' | 'cpp' | 'python' | 'js' | 'curl'>('winforms');

  // Request Inputs
  const [username, setUsername] = useState('player123');
  const [password, setPassword] = useState('playerPassword123!');
  const [email, setEmail] = useState('player@example.com');
  const [licenseKey, setLicenseKey] = useState('SPIDEY-AX91-KL84-99P2-44QR');
  const [hwid, setHwid] = useState('HWID-DEV-MACHINE-01');
  const [newPassword, setNewPassword] = useState('newSecurePassword2026!');
  const [varName, setVarName] = useState('status');
  const [varData, setVarData] = useState('active_license');

  // KeyAuth specific inputs
  const [keyauthSessionId, setKeyauthSessionId] = useState('');

  // Real secret
  const [rawSecret, setRawSecret] = useState<string>('');

  // Results
  const [loading, setLoading] = useState(false);
  const [responseStatus, setResponseStatus] = useState<number | null>(null);
  const [responseLatency, setResponseLatency] = useState<number | null>(null);
  const [responseData, setResponseData] = useState<any>(null);

  const toast = useToast();

  const currentHostUrl = typeof window !== 'undefined' ? window.location.origin : 'http://localhost:3000';

  useEffect(() => {
    if (activeApp) {
      api.revealSecret(activeApp.id).then((res) => {
        setRawSecret(res.secret);
      }).catch(() => {
        setRawSecret('spy_sec_your_app_secret');
      });
    }
  }, [activeApp?.id]);

  const handleExecute = async () => {
    if (!activeApp) return;

    setLoading(true);
    setResponseStatus(null);
    setResponseLatency(null);
    setResponseData(null);

    const startTime = performance.now();
    try {
      let res: any;

      if (protocol === 'keyauth') {
        let currentSession = keyauthSessionId;

        // Auto-initialize if session missing and action needs it
        if (!currentSession && keyauthAction !== 'init') {
          try {
            const autoInitBody = new URLSearchParams({
              type: 'init',
              name: activeApp.name,
              ownerid: activeApp.owner_code,
              ver: activeApp.version || '1.0',
            }).toString();
            const initResponse = await fetch('/api/1.3/', {
              method: 'POST',
              headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
              body: autoInitBody,
            });
            const initResJson = await initResponse.json();
            if (initResJson.sessionid) {
              currentSession = initResJson.sessionid;
              setKeyauthSessionId(currentSession);
            }
          } catch {
            // Proceed with execution
          }
        }

        // Execute KeyAuth Protocol request against /api/1.3/
        const postParams: Record<string, string> = {
          type: keyauthAction,
          name: activeApp.name,
          ownerid: activeApp.owner_code,
          ver: activeApp.version || '1.0',
        };

        if (currentSession) {
          postParams.sessionid = currentSession;
        }

        if (keyauthAction === 'login') {
          postParams.username = username;
          postParams.pass = password;
          postParams.hwid = hwid;
        } else if (keyauthAction === 'register') {
          postParams.username = username;
          postParams.pass = password;
          postParams.key = licenseKey;
          postParams.email = email;
          postParams.hwid = hwid;
        } else if (keyauthAction === 'license') {
          postParams.key = licenseKey;
          postParams.hwid = hwid;
        } else if (keyauthAction === 'upgrade') {
          postParams.username = username;
          postParams.key = licenseKey;
        } else if (keyauthAction === 'var') {
          postParams.varid = varName;
        } else if (keyauthAction === 'setvar') {
          postParams.var = varName;
          postParams.data = varData;
        } else if (keyauthAction === 'checkblacklist') {
          postParams.hwid = hwid;
        } else if (keyauthAction === 'log') {
          postParams.message = `Test log from ${activeApp.name} at ${new Date().toISOString()}`;
        }

        const bodyData = new URLSearchParams(postParams).toString();
        const response = await fetch('/api/1.3/', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
          },
          body: bodyData,
        });

        res = await response.json();

        // If init, capture session id
        if (keyauthAction === 'init' && res.sessionid) {
          setKeyauthSessionId(res.sessionid);
        }

        const latency = Math.round(performance.now() - startTime);
        setResponseLatency(latency);
        setResponseStatus(response.status);
        setResponseData(res);

        if (res.success) {
          toast.success(`KeyAuth [${keyauthAction}] call succeeded!`, 'KeyAuth v1 Drop-in Live');
        } else {
          toast.error(res.message || 'KeyAuth API returned false');
        }
        return;
      }

      // Native Spidey Auth Protocol
      if (action === 'login') {
        res = await api.sdkLogin(activeApp.id, rawSecret, username, password, hwid);
      } else if (action === 'register') {
        res = await api.sdkRegister(activeApp.id, rawSecret, username, password, email, licenseKey);
      } else if (action === 'activate') {
        res = await api.sdkActivateLicense(activeApp.id, rawSecret, licenseKey, hwid, username);
      } else if (action === 'validate') {
        res = await api.sdkValidateLicense(activeApp.id, rawSecret, licenseKey);
      } else if (action === 'reset-pass') {
        const response = await fetch('/api/user/reset-password', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'x-application-id': activeApp.id,
            'x-application-secret': rawSecret,
          },
          body: JSON.stringify({ applicationId: activeApp.id, applicationSecret: rawSecret, username, currentPassword: password, newPassword }),
        });
        res = await response.json();
      }

      const latency = Math.round(performance.now() - startTime);
      setResponseLatency(latency);
      setResponseStatus(res.success ? 200 : (res.error?.code === 'RATE_LIMITED' ? 429 : 400));
      setResponseData(res);

      if (res.success) {
        toast.success(`Action "${action}" succeeded!`, 'Live API Response');
      } else {
        toast.error(`[${res.error?.code || 'ERROR'}] ${res.error?.message || 'Failed'}`);
      }
    } catch (err: any) {
      setResponseStatus(500);
      setResponseData({ success: false, error: { code: 'NETWORK_ERROR', message: err.message } });
      toast.error(err.message || 'Network error');
    } finally {
      setLoading(false);
    }
  };

  const appId = activeApp?.id || 'APP-92JD83';
  const appSecret = rawSecret || 'spy_sec_your_app_secret';
  const appName = activeApp?.name || 'Apex Velocity';
  const ownerCode = activeApp?.owner_code || 'SPY-OWNER-82HD72';
  const appVersion = activeApp?.version || '1.0.0';

  // Dynamic code generation
  const getGeneratedCode = () => {
    if (protocol === 'keyauth') {
      const targetUrl = `${currentHostUrl}/api/1.3/`;

      if (language === 'winforms') {
        return `using System;
using System.Windows.Forms;
using KeyAuth;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        // ==========================================
        // 1. INITIALIZE KEYAUTH CLIENT
        // Configured for ${appName} on Spidey Auth
        // ==========================================
        public static api KeyAuthApp = new api(
            name: "${appName}",
            ownerid: "${ownerCode}",
            version: "${appVersion}",
            path: null,
            url: "${targetUrl}"
        );

        public Form1()
        {
            InitializeComponent();

            try
            {
                KeyAuthApp.init(); // MUST run before ANY login
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Init Failed");
                Environment.Exit(0);
            }
        }

        // ==========================================
        // 2. IN LOGIN BUTTON
        // ==========================================
        private void LoginBtn_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(User.Text) || string.IsNullOrWhiteSpace(Pass.Text))
            {
                MessageBox.Show("Username or Password empty");
                return;
            }

            KeyAuthApp.login(User.Text, Pass.Text);

            if (KeyAuthApp.response.success)
            {
                // Authenticated successfully! Proceed to Form2
                Form1 f2 = new Form2();
                f2.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show(KeyAuthApp.response.message, "Login Failed");
            }
        }

        // ==========================================
        // 3. IN LICENSE (KEY) BUTTON
        // ==========================================
        private void LicenseBtn_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(LicenseKey.Text))
            {
                MessageBox.Show("License key empty");
                return;
            }

            KeyAuthApp.license(LicenseKey.Text);

            if (KeyAuthApp.response.success)
            {
                Form1 f2 = new Form2();
                f2.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show(KeyAuthApp.response.message, "License Error");
            }
        }
    }
}`;
      }

      if (language === 'csharp') {
        return `using KeyAuth;

// 1. Initialize KeyAuth client pointing to Spidey Auth
api KeyAuthApp = new api(
    name: "${appName}",
    ownerid: "${ownerCode}",
    version: "${appVersion}",
    url: "${targetUrl}"
);

KeyAuthApp.init();

${keyauthAction === 'init' ? `Console.WriteLine("App initialized. Total users: " + KeyAuthApp.app_data.numUsers);` : ''}${keyauthAction === 'login' ? `// 2. Authenticate User
KeyAuthApp.login("${username}", "${password}");

if (KeyAuthApp.response.success) {
    Console.WriteLine("Logged in! User: " + KeyAuthApp.user_data.username);
    Console.WriteLine("Expires in: " + KeyAuthApp.expirydaysleft("days", 0) + " days");
} else {
    Console.WriteLine("Error: " + KeyAuthApp.response.message);
}` : ''}${keyauthAction === 'register' ? `// 2. Register User with Key
KeyAuthApp.register("${username}", "${password}", "${licenseKey}", "${email}");
Console.WriteLine("Registered: " + KeyAuthApp.response.success);` : ''}${keyauthAction === 'license' ? `// 2. Key-only Login
KeyAuthApp.license("${licenseKey}");
Console.WriteLine("License valid: " + KeyAuthApp.response.success);` : ''}${keyauthAction === 'check' ? `// Check session
KeyAuthApp.check();
Console.WriteLine("Session valid: " + KeyAuthApp.response.success);` : ''}${keyauthAction === 'fetchstats' ? `// Fetch stats
KeyAuthApp.fetchStats();
Console.WriteLine("Total keys: " + KeyAuthApp.app_data.numKeys);` : ''}`;
      }

      if (language === 'python') {
        return `from keyauth_compat import KeyAuth

# Initialize client pointing to this Spidey Auth web instance
app = KeyAuth(
    name="${appName}",
    ownerid="${ownerCode}",
    version="${appVersion}",
    url="${targetUrl}"
)

app.init()

${keyauthAction === 'init' ? `print("Initialized! Total users:", app.app_data.numUsers)` : ''}${keyauthAction === 'login' ? `# Login user
if app.login("${username}", "${password}"):
    print("Logged in as:", app.user_data.username)
    print("Subscription:", app.user_data.subscriptions)
else:
    print("Login failed:", app.response.message)` : ''}${keyauthAction === 'register' ? `# Register user with license key
if app.register("${username}", "${password}", key="${licenseKey}", email="${email}"):
    print("Registered successfully!")
else:
    print("Registration error:", app.response.message)` : ''}${keyauthAction === 'license' ? `# Key-only authentication
if app.license("${licenseKey}"):
    print("License authenticated!")
else:
    print("Invalid license:", app.response.message)` : ''}${keyauthAction === 'check' ? `print("Session active:", app.check())` : ''}${keyauthAction === 'fetchstats' ? `stats = app.fetch_stats()
print("Stats:", stats)` : ''}`;
      }

      if (language === 'cpp') {
        return `#include "KeyAuthCompat.hpp"
#include <iostream>

int main() {
    KeyAuth::api app("${appName}", "${ownerCode}", "${appVersion}", "${targetUrl}");
    
    if (!app.init()) {
        std::cout << "Init failed: " << app.response.message << std::endl;
        return 1;
    }
    
    ${keyauthAction === 'login' ? `if (app.login("${username}", "${password}")) {
        std::cout << "Logged in: " << app.user_data.username << std::endl;
    }` : keyauthAction === 'license' ? `if (app.license("${licenseKey}")) {
        std::cout << "License valid!" << std::endl;
    }` : `std::cout << "App initialized with users: " << app.app_data.numUsers << std::endl;`}
    
    return 0;
}`;
      }

      if (language === 'js') {
        return `import { KeyAuthApi } from '@spideyauth/sdk';

const app = new KeyAuthApi(
  '${appName}',
  '${ownerCode}',
  '${appVersion}',
  '${targetUrl}'
);

await app.init();
${keyauthAction === 'login' ? `const ok = await app.login('${username}', '${password}');
console.log('Login success:', ok, app.userData);` : keyauthAction === 'license' ? `const ok = await app.license('${licenseKey}');
console.log('License valid:', ok);` : `console.log('App initialized:', app.appData);`}`;
      }

      return `curl -X POST ${targetUrl} \\
  -H "Content-Type: application/x-www-form-urlencoded" \\
  -d "type=${keyauthAction}&name=${encodeURIComponent(appName)}&ownerid=${encodeURIComponent(ownerCode)}&ver=${encodeURIComponent(appVersion)}${keyauthAction === 'login' ? `&username=${username}&pass=${password}&hwid=${hwid}` : ''}${keyauthAction === 'license' ? `&key=${licenseKey}&hwid=${hwid}` : ''}"`;
    }

    // Native Spidey Auth Protocol
    if (language === 'curl') {
      if (action === 'login') {
        return `curl -X POST ${currentHostUrl}/api/user/login \\
  -H "Content-Type: application/json" \\
  -H "x-application-id: ${appId}" \\
  -H "x-application-secret: ${appSecret}" \\
  -d '{"applicationId":"${appId}","applicationSecret":"${appSecret}","username":"${username}","password":"${password}","hwid":"${hwid}"}'`;
      }
      if (action === 'activate') {
        return `curl -X POST ${currentHostUrl}/api/license/activate \\
  -H "Content-Type: application/json" \\
  -H "x-application-id: ${appId}" \\
  -H "x-application-secret: ${appSecret}" \\
  -d '{"applicationId":"${appId}","applicationSecret":"${appSecret}","licenseKey":"${licenseKey}","hwid":"${hwid}"}'`;
      }
      if (action === 'validate') {
        return `curl -X POST ${currentHostUrl}/api/license/validate \\
  -H "Content-Type: application/json" \\
  -H "x-application-id: ${appId}" \\
  -H "x-application-secret: ${appSecret}" \\
  -d '{"applicationId":"${appId}","applicationSecret":"${appSecret}","licenseKey":"${licenseKey}"}'`;
      }
      return `curl -X POST ${currentHostUrl}/api/user/register \\
  -H "Content-Type: application/json" \\
  -H "x-application-id: ${appId}" \\
  -H "x-application-secret: ${appSecret}" \\
  -d '{"applicationId":"${appId}","applicationSecret":"${appSecret}","username":"${username}","password":"${password}","email":"${email}"}'`;
    }

            if (language === 'winforms' || language === 'csharp') {
      if (action === 'login') {
        return `using SpideyAuthSDK;

var auth = new SpideyAuth("${appId}", "${appSecret}", "${currentHostUrl}");
var response = await auth.LoginAsync("${username}", "${password}", "${hwid}");

if (response.Success) {
    Console.WriteLine($"Welcome, {response.Data?.Username}!");
} else {
    Console.WriteLine($"Error: [{response.ErrorCode}] {response.ErrorMessage}");
}`;
      }
      if (action === 'activate') {
        return `using SpideyAuthSDK;

var auth = new SpideyAuth("${appId}", "${appSecret}", "${currentHostUrl}");
var response = await auth.ActivateLicenseAsync("${licenseKey}", "${username}", "${hwid}");

if (response.Success) {
    Console.WriteLine($"Activated! Status: {response.Data?.Status}");
}`;
      }
      return `using SpideyAuthSDK;

var auth = new SpideyAuth("${appId}", "${appSecret}", "${currentHostUrl}");
var response = await auth.ValidateLicenseAsync("${licenseKey}");
Console.WriteLine($"Valid: {response.Success}");`;
    }

    if (language === 'python') {
      if (action === 'login') {
        return `from spidey_auth import SpideyAuth

auth = SpideyAuth("${appId}", "${appSecret}", "${currentHostUrl}")
user_data = auth.login("${username}", "${password}", "${hwid}")
print("Logged in user:", user_data["user"]["username"])`;
      }
      if (action === 'activate') {
        return `from spidey_auth import SpideyAuth

auth = SpideyAuth("${appId}", "${appSecret}", "${currentHostUrl}")
res = auth.activate_license("${licenseKey}", "${username}", "${hwid}")
print("License activated:", res["license"]["status"])`;
      }
      return `from spidey_auth import SpideyAuth

auth = SpideyAuth("${appId}", "${appSecret}", "${currentHostUrl}")
res = auth.validate_license("${licenseKey}")
print("Is valid:", res["valid"])`;
    }

    if (language === 'js') {
      if (action === 'login') {
        return `import { SpideyAuth } from '@spideyauth/sdk';

const auth = new SpideyAuth({
  applicationId: '${appId}',
  applicationSecret: '${appSecret}',
  baseUrl: '${currentHostUrl}',
});

const user = await auth.login('${username}', '${password}', '${hwid}');
console.log('Logged in as:', user.username);`;
      }
      if (action === 'activate') {
        return `import { SpideyAuth } from '@spideyauth/sdk';

const auth = new SpideyAuth({
  applicationId: '${appId}',
  applicationSecret: '${appSecret}',
  baseUrl: '${currentHostUrl}',
});

const license = await auth.activateLicense('${licenseKey}', '${hwid}');
console.log('License activated! Status:', license.status);`;
      }
      return `import { SpideyAuth } from '@spideyauth/sdk';

const auth = new SpideyAuth({
  applicationId: '${appId}',
  applicationSecret: '${appSecret}',
  baseUrl: '${currentHostUrl}',
});

const check = await auth.validateLicense('${licenseKey}');
console.log('Is valid:', check.valid);`;
    }

    return `// C++ Native Implementation
#include "SpideyAuth.hpp"

SpideyAuth::Client auth("${appId}", "${appSecret}", "${currentHostUrl}");
SpideyAuth::User user;
auto res = auth.Login("${username}", "${password}", user);
if (res.success) {
    std::cout << "Success: " << user.username << std::endl;
}`;
  };

  if (!activeApp) {
    return (
      <div className="p-12 text-center rounded-3xl bg-zinc-900/40 border border-zinc-800">
        <Terminal className="w-12 h-12 text-zinc-600 mx-auto mb-3" />
        <h3 className="text-base font-bold text-white">No Application Selected</h3>
        <p className="text-xs text-zinc-400 mt-1 mb-4">
          Select or create an application to execute live requests and generate SDK codes.
        </p>
        <button
          onClick={() => onNavigate('applications')}
          className="px-5 py-2 rounded-xl bg-red-600 text-white text-xs font-bold uppercase tracking-wider"
        >
          View Applications
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
            <Terminal className="w-5 h-5 text-red-500" />
            Live SDK & API Playground
          </h2>
          <p className="text-xs text-zinc-400 mt-1">
            Execute real-time API requests against <strong className="text-zinc-200">{activeApp.name}</strong> ({activeApp.id}) and inspect responses, latency, and code snippets.
          </p>
        </div>

        {/* PROTOCOL SELECTOR TAB */}
        <div className="flex p-1 bg-zinc-900 rounded-xl border border-zinc-800 shrink-0">
          <button
            type="button"
            onClick={() => {
              setProtocol('native');
              setResponseData(null);
            }}
            className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-all flex items-center gap-1.5 ${
              protocol === 'native' ? 'bg-red-600 text-white shadow-md' : 'text-zinc-400 hover:text-white'
            }`}
          >
            <Shield className="w-3.5 h-3.5" />
            Spidey Native Protocol
          </button>
          <button
            type="button"
            onClick={() => {
              setProtocol('keyauth');
              setResponseData(null);
            }}
            className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-all flex items-center gap-1.5 ${
              protocol === 'keyauth' ? 'bg-red-600 text-white shadow-md' : 'text-zinc-400 hover:text-white'
            }`}
          >
            <Zap className="w-3.5 h-3.5 text-amber-300" />
            KeyAuth v1.3 Drop-In
          </button>
        </div>
      </div>

      {protocol === 'keyauth' && (
        <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-start gap-3 text-xs">
          <Zap className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
          <div className="space-y-1">
            <div className="font-bold text-amber-200 flex items-center gap-2">
              KeyAuth Drop-In Compatibility Mode Active
              <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-amber-500/20 text-amber-300 border border-amber-500/40">
                PORT 3000 / API 1.3
              </span>
            </div>
            <p className="text-amber-200/80 leading-relaxed text-[11px]">
              You can drop your existing KeyAuth applications straight into Spidey Auth! Simply change your client endpoint to <code className="bg-black/40 px-1 py-0.5 rounded text-amber-200 font-mono">{currentHostUrl}/api/1.3/</code>.
              No complex migrations needed.
            </p>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Request Form */}
        <div className="lg:col-span-5 p-6 rounded-2xl bg-zinc-900/50 border border-zinc-800/80 backdrop-blur-xl space-y-5">
          {/* Action Selector */}
          <div>
            <label className="block text-xs font-bold text-zinc-300 uppercase tracking-wider mb-2">
              {protocol === 'native' ? 'Select Native Endpoint' : 'Select KeyAuth Action'}
            </label>

            {protocol === 'native' ? (
              <div className="grid grid-cols-2 gap-2 font-mono text-xs">
                <button
                  type="button"
                  onClick={() => setAction('login')}
                  className={`py-2 px-3 rounded-xl border text-left font-semibold transition-all ${
                    action === 'login'
                      ? 'bg-red-600/15 border-red-500/50 text-white'
                      : 'bg-zinc-950/60 border-zinc-800 text-zinc-400 hover:text-white'
                  }`}
                >
                  /api/user/login
                </button>
                <button
                  type="button"
                  onClick={() => setAction('register')}
                  className={`py-2 px-3 rounded-xl border text-left font-semibold transition-all ${
                    action === 'register'
                      ? 'bg-red-600/15 border-red-500/50 text-white'
                      : 'bg-zinc-950/60 border-zinc-800 text-zinc-400 hover:text-white'
                  }`}
                >
                  /api/user/register
                </button>
                <button
                  type="button"
                  onClick={() => setAction('activate')}
                  className={`py-2 px-3 rounded-xl border text-left font-semibold transition-all ${
                    action === 'activate'
                      ? 'bg-red-600/15 border-red-500/50 text-white'
                      : 'bg-zinc-950/60 border-zinc-800 text-zinc-400 hover:text-white'
                  }`}
                >
                  /api/license/activate
                </button>
                <button
                  type="button"
                  onClick={() => setAction('validate')}
                  className={`py-2 px-3 rounded-xl border text-left font-semibold transition-all ${
                    action === 'validate'
                      ? 'bg-red-600/15 border-red-500/50 text-white'
                      : 'bg-zinc-950/60 border-zinc-800 text-zinc-400 hover:text-white'
                  }`}
                >
                  /api/license/validate
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-3 sm:grid-cols-4 gap-1.5 font-mono text-xs">
                {(['init', 'login', 'register', 'license', 'check', 'fetchstats', 'upgrade', 'var', 'setvar', 'checkblacklist', 'log'] as const).map((ka) => (
                  <button
                    key={ka}
                    type="button"
                    onClick={() => setKeyauthAction(ka)}
                    className={`py-2 px-1.5 rounded-xl border text-center font-semibold transition-all uppercase text-[10px] ${
                      keyauthAction === ka
                        ? 'bg-red-600/20 border-red-500 text-white shadow-md'
                        : 'bg-zinc-950/60 border-zinc-800 text-zinc-400 hover:text-white'
                    }`}
                  >
                    {ka}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* KeyAuth Credentials Header */}
          {protocol === 'keyauth' && (
            <div className="p-3.5 rounded-xl bg-zinc-950/80 border border-zinc-800 space-y-2 font-mono text-[11px]">
              <div className="flex items-center justify-between pb-1.5 border-b border-zinc-800/80">
                <span className="text-zinc-400 font-sans font-bold text-[10px] uppercase tracking-wider">Drop-In Credentials</span>
                <button
                  type="button"
                  onClick={() => {
                    const cfg = `Application Name: ${appName}\nOwner ID: ${ownerCode}\nApp Secret: ${rawSecret}\nVersion: ${appVersion}\nAPI URL: ${currentHostUrl}/api/1.3/`;
                    navigator.clipboard.writeText(cfg);
                    toast.success('KeyAuth configuration copied to clipboard!');
                  }}
                  className="text-[10px] text-red-400 hover:text-red-300 flex items-center gap-1 font-sans font-semibold"
                >
                  <Copy className="w-3 h-3" /> Copy Config
                </button>
              </div>
              <div className="flex justify-between text-zinc-400">
                <span>Application:</span>
                <span className="text-white font-bold">{appName}</span>
              </div>
              <div className="flex justify-between text-zinc-400">
                <span>Owner ID:</span>
                <span className="text-red-400 font-bold">{ownerCode}</span>
              </div>
              <div className="flex justify-between text-zinc-400">
                <span>Version:</span>
                <span className="text-zinc-200">{appVersion}</span>
              </div>
              <div className="flex justify-between text-zinc-400">
                <span>Endpoint:</span>
                <span className="text-emerald-400 font-mono text-[10px]">{currentHostUrl}/api/1.3/</span>
              </div>
              {keyauthSessionId && (
                <div className="flex justify-between text-emerald-400 pt-1 border-t border-zinc-800/80">
                  <span>Session ID:</span>
                  <span className="truncate max-w-[150px]">{keyauthSessionId}</span>
                </div>
              )}
            </div>
          )}

          {/* Input Parameters based on action */}
          <div className="space-y-3 font-mono text-xs">
            {((protocol === 'native' && (action === 'login' || action === 'register' || action === 'reset-pass')) ||
              (protocol === 'keyauth' && (keyauthAction === 'login' || keyauthAction === 'register' || keyauthAction === 'upgrade'))) && (
              <div>
                <label className="block text-[11px] text-zinc-400 mb-1">username</label>
                <input
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-xl py-2 px-3 text-white focus:outline-none focus:border-red-500"
                />
              </div>
            )}

            {((protocol === 'native' && (action === 'login' || action === 'register' || action === 'reset-pass')) ||
              (protocol === 'keyauth' && (keyauthAction === 'login' || keyauthAction === 'register'))) && (
              <div>
                <label className="block text-[11px] text-zinc-400 mb-1">password / pass</label>
                <input
                  type="text"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-xl py-2 px-3 text-white focus:outline-none focus:border-red-500"
                />
              </div>
            )}

            {((protocol === 'native' && action === 'register') ||
              (protocol === 'keyauth' && keyauthAction === 'register')) && (
              <div>
                <label className="block text-[11px] text-zinc-400 mb-1">email (optional)</label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-xl py-2 px-3 text-white focus:outline-none focus:border-red-500"
                />
              </div>
            )}

            {((protocol === 'native' && (action === 'activate' || action === 'validate' || action === 'register')) ||
              (protocol === 'keyauth' && (keyauthAction === 'license' || keyauthAction === 'register' || keyauthAction === 'upgrade'))) && (
              <div>
                <label className="block text-[11px] text-zinc-400 mb-1">licenseKey / key</label>
                <input
                  type="text"
                  value={licenseKey}
                  onChange={(e) => setLicenseKey(e.target.value)}
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-xl py-2 px-3 text-white focus:outline-none focus:border-red-500"
                />
              </div>
            )}

            {protocol === 'keyauth' && (keyauthAction === 'var' || keyauthAction === 'setvar') && (
              <div>
                <label className="block text-[11px] text-zinc-400 mb-1">var / variable name</label>
                <input
                  type="text"
                  value={varName}
                  onChange={(e) => setVarName(e.target.value)}
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-xl py-2 px-3 text-white focus:outline-none focus:border-red-500"
                />
              </div>
            )}

            {protocol === 'keyauth' && keyauthAction === 'setvar' && (
              <div>
                <label className="block text-[11px] text-zinc-400 mb-1">data / variable value</label>
                <input
                  type="text"
                  value={varData}
                  onChange={(e) => setVarData(e.target.value)}
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-xl py-2 px-3 text-white focus:outline-none focus:border-red-500"
                />
              </div>
            )}

            {((protocol === 'native' && (action === 'login' || action === 'activate')) ||
              (protocol === 'keyauth' && (keyauthAction === 'login' || keyauthAction === 'license' || keyauthAction === 'register' || keyauthAction === 'checkblacklist'))) && (
              <div>
                <label className="block text-[11px] text-zinc-400 mb-1">hwid (Hardware Identifier)</label>
                <input
                  type="text"
                  value={hwid}
                  onChange={(e) => setHwid(e.target.value)}
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-xl py-2 px-3 text-white focus:outline-none focus:border-red-500"
                />
              </div>
            )}
          </div>

          {/* Execute Button */}
          <button
            onClick={handleExecute}
            disabled={loading}
            className="w-full py-3 rounded-xl bg-red-600 hover:bg-red-500 text-white font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-[0_0_20px_rgba(239,68,68,0.3)] transition-all disabled:opacity-50"
          >
            {loading ? (
              <span className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full" />
            ) : (
              <>
                <Play className="w-4 h-4 fill-white" />
                {protocol === 'native' ? 'Execute Live Request' : `Execute KeyAuth [${keyauthAction.toUpperCase()}]`}
              </>
            )}
          </button>
        </div>

        {/* Right Column: Response and Code Snippets */}
        <div className="lg:col-span-7 space-y-6">
          {/* Live Response Panel */}
          <div className="p-5 rounded-2xl bg-zinc-900/50 border border-zinc-800/80 backdrop-blur-xl">
            <div className="flex items-center justify-between pb-3 border-b border-zinc-800/80 mb-3">
              <span className="text-xs font-bold uppercase tracking-wider text-zinc-400 font-mono flex items-center gap-2">
                <span>Live Server Response</span>
                {protocol === 'keyauth' && (
                  <span className="text-[10px] bg-zinc-800 text-zinc-300 px-2 py-0.5 rounded font-mono">
                    /api/1.3/
                  </span>
                )}
              </span>
              <div className="flex items-center gap-3 text-xs font-mono">
                {responseStatus !== null && (
                  <span
                    className={`px-2 py-0.5 rounded font-bold ${
                      responseStatus >= 200 && responseStatus < 300
                        ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30'
                        : 'bg-red-500/15 text-red-400 border border-red-500/30'
                    }`}
                  >
                    HTTP {responseStatus}
                  </span>
                )}
                {responseLatency !== null && (
                  <span className="text-zinc-400 flex items-center gap-1">
                    <Clock className="w-3.5 h-3.5 text-zinc-500" />
                    {responseLatency} ms
                  </span>
                )}
              </div>
            </div>

            <pre className="p-4 rounded-xl bg-zinc-950/80 border border-zinc-800/80 text-xs font-mono text-zinc-200 overflow-x-auto min-h-[140px] max-h-[220px]">
              {responseData ? (
                JSON.stringify(responseData, null, 2)
              ) : (
                <span className="text-zinc-500 italic">
                  Press "Execute..." to send live authentication requests to this Spidey Auth web instance...
                </span>
              )}
            </pre>
          </div>

          {/* Code Snippets for Current Input */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold uppercase tracking-wider text-zinc-400 font-mono">
                {protocol === 'native' ? 'Native SDK Implementation' : 'KeyAuth Compatible Client Code'}
              </span>
              <div className="flex items-center gap-1 bg-zinc-900/80 p-1 rounded-xl border border-zinc-800 text-[11px] font-mono">
                {(protocol === 'keyauth'
                  ? (['winforms', 'csharp', 'python', 'cpp', 'js', 'curl'] as const)
                  : (['csharp', 'winforms', 'python', 'cpp', 'js', 'curl'] as const)
                ).map((lang) => (
                  <button
                    key={lang}
                    onClick={() => setLanguage(lang as any)}
                    className={`px-2 py-1 rounded-lg uppercase font-semibold transition-colors ${
                      language === lang ? 'bg-red-600 text-white' : 'text-zinc-400 hover:text-white'
                    }`}
                  >
                    {lang === 'winforms' ? 'C# WinForms' : lang === 'csharp' ? 'C# Console' : lang === 'js' ? 'TypeScript' : lang}
                  </button>
                ))}
              </div>
            </div>

            <CodeBlock
              code={getGeneratedCode()}
              language={language === 'winforms' || language === 'csharp' ? 'csharp' : language === 'cpp' ? 'cpp' : language === 'python' ? 'python' : language === 'js' ? 'typescript' : 'bash'}
              title={
                language === 'winforms'
                  ? `Windows Forms (Form1 / Form2) Implementation`
                  : protocol === 'native'
                  ? `SpideyAuth ${action.toUpperCase()} Implementation`
                  : `KeyAuth Compat [${keyauthAction.toUpperCase()}]`
              }
            />

            {/* Quick Helper Card for KeyAuth WinForms Users */}
            {protocol === 'keyauth' && (
              <div className="mt-4 p-4 rounded-2xl bg-zinc-950/70 border border-zinc-800 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Zap className="w-4 h-4 text-amber-400" />
                    <span className="text-xs font-bold text-white">Full C# Client File (KeyAuthApp.cs)</span>
                  </div>
                  <span className="text-[10px] bg-amber-500/10 text-amber-300 border border-amber-500/20 px-2 py-0.5 rounded font-mono">
                    Ed25519 & WinForms Compatible
                  </span>
                </div>
                <p className="text-[11px] text-zinc-400 leading-relaxed">
                  Add <code className="text-amber-300 font-mono">KeyAuthApp.cs</code> to your Visual Studio Windows Forms or WPF project. It contains the complete <code className="text-zinc-200 font-mono">KeyAuth.api</code> class, <code className="text-zinc-200 font-mono">Cryptographic.Ed25519</code> algorithm, and calls <code className="text-red-400 font-mono">{currentHostUrl}/api/1.3/</code>.
                </p>
                <div className="flex flex-wrap items-center gap-2 pt-1 font-mono text-xs">
                  <button
                    onClick={() => {
                      navigator.clipboard.writeText(getGeneratedCode());
                      toast.success('Form1 code snippet copied to clipboard!');
                    }}
                    className="px-3 py-1.5 rounded-xl bg-red-600 hover:bg-red-500 text-white font-semibold flex items-center gap-1.5 transition-colors"
                  >
                    <Copy className="w-3.5 h-3.5" />
                    Copy Form1 Code
                  </button>
                  <a
                    href="/sdk/csharp/KeyAuthApp.cs"
                    download="KeyAuthApp.cs"
                    className="px-3 py-1.5 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-200 font-semibold flex items-center gap-1.5 transition-colors"
                  >
                    Download KeyAuthApp.cs
                  </a>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
