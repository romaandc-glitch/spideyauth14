import React, { useState, useEffect } from 'react';
import { ScrollText, RefreshCw, Search, Shield, Filter, Calendar } from 'lucide-react';
import { Application, AuditLog } from '../../types';
import { api } from '../../services/api';
import { useToast } from '../ui/Toast';

interface AuditLogsViewProps {
  activeApp: Application | null;
}

export const AuditLogsView: React.FC<AuditLogsViewProps> = ({ activeApp }) => {
  const [logs, setLogs] = useState<AuditLog[]>([]);
  const [loading, setLoading] = useState(false);
  const [search, setSearch] = useState('');

  const toast = useToast();

  useEffect(() => {
    loadLogs();
  }, [activeApp?.id]);

  const loadLogs = async () => {
    setLoading(true);
    try {
      if (activeApp) {
        const res = await api.getAppAuditLogs(activeApp.id);
        setLogs(res.logs);
      } else {
        const res = await api.getUserAuditLogs();
        setLogs(res.logs);
      }
    } catch (err: any) {
      toast.error(err.message || 'Failed to load audit logs');
    } finally {
      setLoading(false);
    }
  };

  const filteredLogs = logs.filter(
    (l) =>
      l.event_type.toLowerCase().includes(search.toLowerCase()) ||
      l.description.toLowerCase().includes(search.toLowerCase()) ||
      (l.ip_address && l.ip_address.includes(search))
  );

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
            <ScrollText className="w-5 h-5 text-red-500" />
            Security & Audit Logs
          </h2>
          <p className="text-xs text-zinc-400 mt-1">
            Immutable log trail of administrative and API authorization events.
          </p>
        </div>

        <button
          onClick={loadLogs}
          className="p-2 rounded-xl bg-zinc-900 border border-zinc-800 text-zinc-400 hover:text-white transition-colors"
          title="Refresh logs"
        >
          <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
        </button>
      </div>

      <div className="p-4 rounded-2xl bg-zinc-900/40 border border-zinc-800/80 backdrop-blur-xl">
        <div className="relative">
          <Search className="absolute left-3 top-2.5 w-4 h-4 text-zinc-500" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search events, descriptions, or IP addresses..."
            className="w-full bg-zinc-950/80 border border-zinc-800 rounded-xl py-2 pl-9 pr-3 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-red-500 font-mono"
          />
        </div>
      </div>

      <div className="rounded-2xl border border-zinc-800/80 bg-zinc-900/30 backdrop-blur-xl overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-zinc-950/60 border-b border-zinc-800 text-zinc-400 font-mono uppercase text-[10px] tracking-wider">
              <tr>
                <th className="py-3 px-4">Event Type</th>
                <th className="py-3 px-4">Description</th>
                <th className="py-3 px-4">IP Address</th>
                <th className="py-3 px-4 text-right">Timestamp</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-800/60 text-zinc-300 font-mono">
              {filteredLogs.length === 0 ? (
                <tr>
                  <td colSpan={4} className="py-12 text-center text-zinc-500 font-sans">
                    {loading ? 'Loading logs...' : 'No audit events found.'}
                  </td>
                </tr>
              ) : (
                filteredLogs.map((log) => (
                  <tr key={log.id} className="hover:bg-zinc-800/20 transition-colors">
                    <td className="py-3.5 px-4 font-bold text-red-400">
                      <span className="bg-red-500/10 border border-red-500/20 px-2 py-0.5 rounded text-[11px]">
                        {log.event_type}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 text-zinc-200 font-sans text-xs">
                      {log.description}
                    </td>
                    <td className="py-3.5 px-4 text-zinc-400 text-[11px]">
                      {log.ip_address || '127.0.0.1'}
                    </td>
                    <td className="py-3.5 px-4 text-right text-zinc-500 text-[11px]">
                      {new Date(log.created_at).toLocaleString()}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
