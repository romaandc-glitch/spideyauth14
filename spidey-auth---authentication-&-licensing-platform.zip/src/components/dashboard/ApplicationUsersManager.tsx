import React, { useState, useEffect } from 'react';
import {
  Users,
  Plus,
  Search,
  Filter,
  Edit2,
  Trash2,
  KeyRound,
  Ban,
  CheckCircle2,
  Lock,
  Calendar,
  Clock,
  RefreshCw,
  Copy,
  Check,
  ChevronLeft,
  ChevronRight,
  Eye,
} from 'lucide-react';
import { Application, ApplicationUser } from '../../types';
import { Modal } from '../ui/Modal';
import { api } from '../../services/api';
import { useToast } from '../ui/Toast';

interface ApplicationUsersManagerProps {
  activeApp: Application | null;
  onNavigate: (view: string) => void;
}

export const ApplicationUsersManager: React.FC<ApplicationUsersManagerProps> = ({ activeApp, onNavigate }) => {
  const [users, setUsers] = useState<ApplicationUser[]>([]);
  const [loading, setLoading] = useState(false);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [totalCount, setTotalCount] = useState(0);

  // Modals
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [isEditOpen, setIsEditOpen] = useState(false);
  const [isResetPassOpen, setIsResetPassOpen] = useState(false);
  const [isDeleteOpen, setIsDeleteOpen] = useState(false);
  const [isViewOpen, setIsViewOpen] = useState(false);
  const [selectedUser, setSelectedUser] = useState<ApplicationUser | null>(null);

  // Create/Edit form fields
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [email, setEmail] = useState('');
  const [subscriptionRole, setSubscriptionRole] = useState('default');
  const [expiresAt, setExpiresAt] = useState('');
  const [notes, setNotes] = useState('');
  const [status, setStatus] = useState<'active' | 'disabled' | 'banned'>('active');

  // Password reset result
  const [resetResult, setResetResult] = useState<string | null>(null);
  const [newPasswordInput, setNewPasswordInput] = useState('');

  const [copiedKey, setCopiedKey] = useState(false);

  const toast = useToast();

  useEffect(() => {
    if (activeApp) {
      loadUsers();
    }
  }, [activeApp?.id, page, statusFilter]);

  const loadUsers = async () => {
    if (!activeApp) return;
    setLoading(true);
    try {
      const res = await api.listAppUsers(activeApp.id, {
        search,
        status: statusFilter,
        page,
        limit: 10,
      });
      setUsers(res.users);
      setTotalPages(res.pagination.pages || 1);
      setTotalCount(res.pagination.total || 0);
    } catch (err: any) {
      toast.error(err.message || 'Failed to fetch application users');
    } finally {
      setLoading(false);
    }
  };

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setPage(1);
    loadUsers();
  };

  const handleCreateUser = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeApp) return;
    if (!username.trim() || !password) {
      toast.error('Username and password are required');
      return;
    }

    setLoading(true);
    try {
      await api.createAppUser(activeApp.id, {
        username: username.trim(),
        password,
        email: email.trim() || undefined,
        subscriptionRole,
        expiresAt: expiresAt ? new Date(expiresAt).toISOString() : undefined,
        notes: notes.trim() || undefined,
      });

      toast.success(`User "${username.trim()}" created successfully!`, 'User Created');
      setIsCreateOpen(false);
      resetForm();
      loadUsers();
    } catch (err: any) {
      toast.error(err.message || 'Failed to create user');
    } finally {
      setLoading(false);
    }
  };

  const handleEditUser = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeApp || !selectedUser) return;

    setLoading(true);
    try {
      await api.updateAppUser(activeApp.id, selectedUser.id, {
        email: email.trim(),
        status,
        subscription_role: subscriptionRole,
        expires_at: expiresAt ? new Date(expiresAt).toISOString() : undefined,
        notes: notes.trim(),
      });

      toast.success('User updated successfully!');
      setIsEditOpen(false);
      loadUsers();
    } catch (err: any) {
      toast.error(err.message || 'Failed to update user');
    } finally {
      setLoading(false);
    }
  };

  const handleResetPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeApp || !selectedUser) return;

    setLoading(true);
    try {
      const res = await api.resetAppUserPassword(
        activeApp.id,
        selectedUser.id,
        newPasswordInput.trim() || undefined
      );

      setResetResult(res.temporaryPassword || newPasswordInput.trim());
      toast.success('Password updated successfully!');
    } catch (err: any) {
      toast.error(err.message || 'Failed to reset password');
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteUser = async () => {
    if (!activeApp || !selectedUser) return;
    setLoading(true);
    try {
      await api.deleteAppUser(activeApp.id, selectedUser.id);
      toast.success(`User "${selectedUser.username}" removed.`);
      setIsDeleteOpen(false);
      loadUsers();
    } catch (err: any) {
      toast.error(err.message || 'Failed to delete user');
    } finally {
      setLoading(false);
    }
  };

  const toggleUserStatus = async (user: ApplicationUser) => {
    if (!activeApp) return;
    const newStatus = user.status === 'active' ? 'disabled' : 'active';
    try {
      await api.updateAppUser(activeApp.id, user.id, { status: newStatus });
      toast.success(`User is now ${newStatus}.`);
      loadUsers();
    } catch (err: any) {
      toast.error(err.message || 'Failed to update status');
    }
  };

  const resetForm = () => {
    setUsername('');
    setPassword('');
    setEmail('');
    setSubscriptionRole('default');
    setExpiresAt('');
    setNotes('');
    setStatus('active');
    setResetResult(null);
    setNewPasswordInput('');
  };

  const openEdit = (user: ApplicationUser) => {
    setSelectedUser(user);
    setUsername(user.username);
    setEmail(user.email || '');
    setSubscriptionRole(user.subscription_role || 'default');
    setExpiresAt(user.expires_at ? user.expires_at.split('T')[0] : '');
    setNotes(user.notes || '');
    setStatus(user.status);
    setIsEditOpen(true);
  };

  const openResetPassword = (user: ApplicationUser) => {
    setSelectedUser(user);
    setResetResult(null);
    setNewPasswordInput('');
    setIsResetPassOpen(true);
  };

  if (!activeApp) {
    return (
      <div className="p-8 text-center bg-zinc-900/30 border border-zinc-800 rounded-3xl">
        <Users className="w-12 h-12 text-zinc-500 mx-auto mb-4" />
        <h3 className="text-lg font-bold text-white mb-2">No Application Selected</h3>
        <p className="text-xs text-zinc-400 mb-4">Select or create an application to manage its users.</p>
        <button
          onClick={() => onNavigate('applications')}
          className="px-5 py-2 rounded-xl bg-red-600 text-white text-xs font-bold uppercase tracking-wider"
        >
          View Applications
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
            <Users className="w-5 h-5 text-red-500" />
            Application Users
          </h2>
          <p className="text-xs text-zinc-400 mt-1">
            End-user credentials for <strong className="text-zinc-200">{activeApp.name}</strong> ({activeApp.id}). Isolated to this application.
          </p>
        </div>

        <button
          onClick={() => {
            resetForm();
            setIsCreateOpen(true);
          }}
          className="px-4 py-2 rounded-xl bg-red-600 hover:bg-red-500 text-white font-bold text-xs uppercase tracking-wider flex items-center gap-1.5 shadow-[0_0_20px_rgba(239,68,68,0.3)] transition-colors"
        >
          <Plus className="w-4 h-4" /> CREATE USER
        </button>
      </div>

      {/* Search and Filters Bar */}
      <div className="p-4 rounded-2xl bg-zinc-900/40 border border-zinc-800/80 backdrop-blur-xl flex flex-col sm:flex-row items-center justify-between gap-3">
        <form onSubmit={handleSearchSubmit} className="relative w-full sm:w-80">
          <Search className="absolute left-3 top-2.5 w-4 h-4 text-zinc-500" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search username, email, notes..."
            className="w-full bg-zinc-950/80 border border-zinc-800 rounded-xl py-2 pl-9 pr-3 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-red-500"
          />
        </form>

        <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
          <div className="flex items-center gap-1.5 bg-zinc-950/80 border border-zinc-800 px-3 py-1.5 rounded-xl">
            <Filter className="w-3.5 h-3.5 text-zinc-400" />
            <select
              value={statusFilter}
              onChange={(e) => {
                setStatusFilter(e.target.value);
                setPage(1);
              }}
              className="bg-transparent text-xs text-zinc-300 font-semibold focus:outline-none cursor-pointer"
            >
              <option value="all" className="bg-zinc-900 text-white">All Statuses</option>
              <option value="active" className="bg-zinc-900 text-white">Active</option>
              <option value="disabled" className="bg-zinc-900 text-white">Disabled</option>
              <option value="banned" className="bg-zinc-900 text-white">Banned</option>
            </select>
          </div>

          <button
            onClick={loadUsers}
            className="p-2 rounded-xl bg-zinc-950/80 border border-zinc-800 text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors"
            title="Refresh list"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          </button>
        </div>
      </div>

      {/* Users Table */}
      <div className="rounded-2xl border border-zinc-800/80 bg-zinc-900/30 backdrop-blur-xl overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-zinc-950/60 border-b border-zinc-800 text-zinc-400 font-mono uppercase text-[10px] tracking-wider">
              <tr>
                <th className="py-3 px-4">Username</th>
                <th className="py-3 px-4">Role / Plan</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4">Created</th>
                <th className="py-3 px-4">Last Login</th>
                <th className="py-3 px-4">Expiration</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-800/60 text-zinc-300">
              {users.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-zinc-500">
                    {loading ? 'Loading application users...' : 'No application users found. Click "+ CREATE USER" to add one.'}
                  </td>
                </tr>
              ) : (
                users.map((u) => (
                  <tr key={u.id} className="hover:bg-zinc-800/20 transition-colors group">
                    <td className="py-3.5 px-4">
                      <div className="font-bold text-white font-mono flex items-center gap-2">
                        <span>{u.username}</span>
                        {u.email && <span className="text-[10px] text-zinc-400 font-sans font-normal truncate max-w-[140px]">({u.email})</span>}
                      </div>
                      {u.notes && (
                        <p className="text-[10px] text-zinc-400 font-sans line-clamp-1 mt-0.5">{u.notes}</p>
                      )}
                    </td>

                    <td className="py-3.5 px-4 font-mono">
                      <span className="text-[11px] px-2 py-0.5 rounded bg-zinc-800 text-zinc-300 font-bold uppercase">
                        {u.subscription_role || 'default'}
                      </span>
                    </td>

                    <td className="py-3.5 px-4 font-mono">
                      <span
                        className={`text-[10px] font-bold px-2 py-0.5 rounded-full border uppercase ${
                          u.status === 'active'
                            ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
                            : u.status === 'banned'
                            ? 'bg-red-500/10 text-red-400 border-red-500/30'
                            : 'bg-zinc-800 text-zinc-400 border-zinc-700'
                        }`}
                      >
                        {u.status}
                      </span>
                    </td>

                    <td className="py-3.5 px-4 text-[11px] text-zinc-400">
                      {new Date(u.created_at).toLocaleDateString()}
                    </td>

                    <td className="py-3.5 px-4 text-[11px] text-zinc-400">
                      {u.last_login_at ? (
                        <span>{new Date(u.last_login_at).toLocaleDateString()}</span>
                      ) : (
                        <span className="text-zinc-600">Never</span>
                      )}
                    </td>

                    <td className="py-3.5 px-4 text-[11px] text-zinc-400 font-mono">
                      {u.expires_at ? (
                        <span>{new Date(u.expires_at).toLocaleDateString()}</span>
                      ) : (
                        <span className="text-zinc-500">Lifetime</span>
                      )}
                    </td>

                    <td className="py-3.5 px-4 text-right">
                      <div className="flex items-center justify-end gap-1">
                        <button
                          onClick={() => {
                            setSelectedUser(u);
                            setIsViewOpen(true);
                          }}
                          className="p-1.5 rounded-lg text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors"
                          title="View user details"
                        >
                          <Eye className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => openEdit(u)}
                          className="p-1.5 rounded-lg text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors"
                          title="Edit user"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => openResetPassword(u)}
                          className="p-1.5 rounded-lg text-amber-400 hover:text-amber-300 hover:bg-amber-500/10 transition-colors"
                          title="Reset password"
                        >
                          <KeyRound className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => toggleUserStatus(u)}
                          className="p-1.5 rounded-lg text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors"
                          title={u.status === 'active' ? 'Disable user' : 'Enable user'}
                        >
                          <Ban className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => {
                            setSelectedUser(u);
                            setIsDeleteOpen(true);
                          }}
                          className="p-1.5 rounded-lg text-red-400 hover:text-red-300 hover:bg-red-500/10 transition-colors"
                          title="Delete user"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="p-4 border-t border-zinc-800 flex items-center justify-between text-xs text-zinc-400">
            <span>
              Showing {users.length} of {totalCount} users
            </span>
            <div className="flex items-center gap-2">
              <button
                disabled={page <= 1}
                onClick={() => setPage((p) => Math.max(1, p - 1))}
                className="p-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 disabled:opacity-40 transition-colors"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <span className="font-mono text-white font-bold">
                {page} / {totalPages}
              </span>
              <button
                disabled={page >= totalPages}
                onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
                className="p-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 disabled:opacity-40 transition-colors"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}
      </div>

      {/* CREATE USER MODAL */}
      <Modal
        isOpen={isCreateOpen}
        onClose={() => setIsCreateOpen(false)}
        title="Create Application User"
        subtitle={`Add an authenticated user specifically for ${activeApp.name}`}
      >
        <form onSubmit={handleCreateUser} className="space-y-3.5">
          <div>
            <label className="block text-xs font-semibold text-zinc-300 mb-1">Username</label>
            <input
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="e.g., player123"
              className="w-full bg-zinc-900 border border-zinc-800 rounded-xl py-2 px-3 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-red-500"
              required
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-zinc-300 mb-1">Password</label>
            <input
              type="text"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Enter client password (hashed with bcrypt)"
              className="w-full bg-zinc-900 border border-zinc-800 rounded-xl py-2 px-3 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-red-500 font-mono"
              required
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-zinc-300 mb-1">Email (Optional)</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="user@example.com"
                className="w-full bg-zinc-900 border border-zinc-800 rounded-xl py-2 px-3 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-red-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-zinc-300 mb-1">Role / Plan</label>
              <input
                type="text"
                value={subscriptionRole}
                onChange={(e) => setSubscriptionRole(e.target.value)}
                placeholder="e.g., vip, premium, beta"
                className="w-full bg-zinc-900 border border-zinc-800 rounded-xl py-2 px-3 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-red-500 font-mono"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-zinc-300 mb-1">Expiration Date (Optional)</label>
            <input
              type="date"
              value={expiresAt}
              onChange={(e) => setExpiresAt(e.target.value)}
              className="w-full bg-zinc-900 border border-zinc-800 rounded-xl py-2 px-3 text-xs text-white focus:outline-none focus:border-red-500"
            />
            <span className="text-[10px] text-zinc-500 mt-0.5 block">Leave blank for lifetime access.</span>
          </div>

          <div>
            <label className="block text-xs font-semibold text-zinc-300 mb-1">Notes (Optional)</label>
            <textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Internal developer notes regarding this user..."
              className="w-full bg-zinc-900 border border-zinc-800 rounded-xl py-2 px-3 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-red-500 h-16 resize-none"
            />
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setIsCreateOpen(false)}
              className="px-4 py-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-300 text-xs font-semibold"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={loading}
              className="px-5 py-2 rounded-xl bg-red-600 hover:bg-red-500 text-white text-xs font-bold uppercase tracking-wider"
            >
              {loading ? 'Creating...' : 'Create User'}
            </button>
          </div>
        </form>
      </Modal>

      {/* EDIT USER MODAL */}
      <Modal
        isOpen={isEditOpen}
        onClose={() => setIsEditOpen(false)}
        title="Edit User"
        subtitle={`Modify settings for user: ${selectedUser?.username}`}
      >
        <form onSubmit={handleEditUser} className="space-y-3.5">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-zinc-300 mb-1">Status</label>
              <select
                value={status}
                onChange={(e) => setStatus(e.target.value as any)}
                className="w-full bg-zinc-900 border border-zinc-800 rounded-xl py-2 px-3 text-xs text-white focus:outline-none focus:border-red-500"
              >
                <option value="active">active (Allowed)</option>
                <option value="disabled">disabled (Temporarily blocked)</option>
                <option value="banned">banned (Banned from app)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-zinc-300 mb-1">Role / Plan</label>
              <input
                type="text"
                value={subscriptionRole}
                onChange={(e) => setSubscriptionRole(e.target.value)}
                className="w-full bg-zinc-900 border border-zinc-800 rounded-xl py-2 px-3 text-xs text-white focus:outline-none focus:border-red-500 font-mono"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-zinc-300 mb-1">Email</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full bg-zinc-900 border border-zinc-800 rounded-xl py-2 px-3 text-xs text-white focus:outline-none focus:border-red-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-zinc-300 mb-1">Expiration Date</label>
            <input
              type="date"
              value={expiresAt}
              onChange={(e) => setExpiresAt(e.target.value)}
              className="w-full bg-zinc-900 border border-zinc-800 rounded-xl py-2 px-3 text-xs text-white focus:outline-none focus:border-red-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-zinc-300 mb-1">Notes</label>
            <textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="w-full bg-zinc-900 border border-zinc-800 rounded-xl py-2 px-3 text-xs text-white focus:outline-none focus:border-red-500 h-16 resize-none"
            />
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setIsEditOpen(false)}
              className="px-4 py-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-300 text-xs font-semibold"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={loading}
              className="px-5 py-2 rounded-xl bg-red-600 hover:bg-red-500 text-white text-xs font-bold uppercase tracking-wider"
            >
              {loading ? 'Saving...' : 'Save User'}
            </button>
          </div>
        </form>
      </Modal>

      {/* RESET PASSWORD MODAL */}
      <Modal
        isOpen={isResetPassOpen}
        onClose={() => setIsResetPassOpen(false)}
        title="Reset User Password"
        subtitle={`Set new credentials for ${selectedUser?.username}`}
      >
        <form onSubmit={handleResetPassword} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-zinc-300 mb-1">
              New Password (Leave blank to generate random)
            </label>
            <input
              type="text"
              value={newPasswordInput}
              onChange={(e) => setNewPasswordInput(e.target.value)}
              placeholder="Leave blank for auto-generated password"
              className="w-full bg-zinc-900 border border-zinc-800 rounded-xl py-2 px-3 text-xs text-white font-mono placeholder-zinc-500 focus:outline-none focus:border-red-500"
            />
          </div>

          {resetResult && (
            <div className="p-3.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-200">
              <span className="text-[11px] font-bold block mb-1">Password updated! New password:</span>
              <div className="flex items-center justify-between font-mono text-xs font-bold bg-zinc-950 p-2 rounded-lg border border-zinc-800">
                <span>{resetResult}</span>
                <button
                  type="button"
                  onClick={() => {
                    navigator.clipboard.writeText(resetResult);
                    setCopiedKey(true);
                    setTimeout(() => setCopiedKey(false), 2000);
                  }}
                  className="text-zinc-400 hover:text-white"
                >
                  {copiedKey ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                </button>
              </div>
            </div>
          )}

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setIsResetPassOpen(false)}
              className="px-4 py-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-300 text-xs font-semibold"
            >
              Close
            </button>
            <button
              type="submit"
              disabled={loading}
              className="px-5 py-2 rounded-xl bg-amber-600 hover:bg-amber-500 text-white text-xs font-bold uppercase tracking-wider"
            >
              {loading ? 'Resetting...' : 'Reset Password'}
            </button>
          </div>
        </form>
      </Modal>

      {/* VIEW USER DETAILS MODAL */}
      <Modal
        isOpen={isViewOpen}
        onClose={() => setIsViewOpen(false)}
        title="User Account Details"
        subtitle={`Information for ${selectedUser?.username}`}
      >
        {selectedUser && (
          <div className="space-y-3 font-mono text-xs">
            <div className="p-3 rounded-xl bg-zinc-950/60 border border-zinc-800 flex justify-between">
              <span className="text-zinc-500">User ID:</span>
              <span className="text-white font-bold">{selectedUser.id}</span>
            </div>
            <div className="p-3 rounded-xl bg-zinc-950/60 border border-zinc-800 flex justify-between">
              <span className="text-zinc-500">Username:</span>
              <span className="text-white font-bold">{selectedUser.username}</span>
            </div>
            <div className="p-3 rounded-xl bg-zinc-950/60 border border-zinc-800 flex justify-between">
              <span className="text-zinc-500">Email:</span>
              <span className="text-white">{selectedUser.email || 'None'}</span>
            </div>
            <div className="p-3 rounded-xl bg-zinc-950/60 border border-zinc-800 flex justify-between">
              <span className="text-zinc-500">Status:</span>
              <span className="text-red-400 uppercase font-bold">{selectedUser.status}</span>
            </div>
            <div className="p-3 rounded-xl bg-zinc-950/60 border border-zinc-800 flex justify-between">
              <span className="text-zinc-500">Role / Plan:</span>
              <span className="text-white font-bold">{selectedUser.subscription_role}</span>
            </div>
            <div className="p-3 rounded-xl bg-zinc-950/60 border border-zinc-800 flex justify-between">
              <span className="text-zinc-500">Created At:</span>
              <span className="text-zinc-300">{new Date(selectedUser.created_at).toLocaleString()}</span>
            </div>
            <div className="p-3 rounded-xl bg-zinc-950/60 border border-zinc-800 flex justify-between">
              <span className="text-zinc-500">Last Login:</span>
              <span className="text-zinc-300">
                {selectedUser.last_login_at ? new Date(selectedUser.last_login_at).toLocaleString() : 'Never'}
              </span>
            </div>
            <div className="p-3 rounded-xl bg-zinc-950/60 border border-zinc-800 flex justify-between">
              <span className="text-zinc-500">Last IP Address:</span>
              <span className="text-zinc-300">{selectedUser.last_ip || 'None'}</span>
            </div>
          </div>
        )}
      </Modal>

      {/* DELETE USER CONFIRMATION MODAL */}
      <Modal
        isOpen={isDeleteOpen}
        onClose={() => setIsDeleteOpen(false)}
        title="Delete User"
        subtitle={`Remove user "${selectedUser?.username}"`}
      >
        <div className="space-y-4">
          <p className="text-xs text-zinc-300">
            Are you sure you want to delete user <strong className="text-white">{selectedUser?.username}</strong>?
            This will immediately invalidate any client tokens or sessions using these credentials.
          </p>
          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setIsDeleteOpen(false)}
              className="px-4 py-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-300 text-xs font-semibold"
            >
              Cancel
            </button>
            <button
              onClick={handleDeleteUser}
              disabled={loading}
              className="px-5 py-2 rounded-xl bg-red-600 hover:bg-red-500 text-white text-xs font-bold uppercase tracking-wider"
            >
              {loading ? 'Deleting...' : 'Delete User'}
            </button>
          </div>
        </div>
      </Modal>
    </div>
  );
};
