import React, { useState, useEffect } from 'react';
import {
  Users,
  KeyRound,
  Zap,
  Sparkles,
  Copy,
  Check,
  RefreshCw,
  Eye,
  EyeOff,
  Plus,
  Terminal,
  Activity,
  Layers,
  ShieldCheck,
  ShieldAlert,
} from 'lucide-react';
import { StatCard } from '../ui/StatCard';
import { Application, Subscription, DeveloperUser } from '../../types';
import { api } from '../../services/api';
import { useToast } from '../ui/Toast';

interface DashboardOverviewProps {
  user: DeveloperUser;
  applications: Application[];
  activeApp: Application | null;
  subscription: Subscription;
  onNavigate: (view: string) => void;
  onOpenCreateUser: () => void;
  onOpenGenerateKey: () => void;
  onRefreshApps: () => void;
}

export const DashboardOverview: React.FC<DashboardOverviewProps> = ({
  user,
  applications,
  activeApp,
  subscription,
  onNavigate,
  onOpenCreateUser,
  onOpenGenerateKey,
  onRefreshApps,
}) => {
  const [stats, setStats] = useState<any>(null);
  const [loadingStats, setLoadingStats] = useState(false);
  const [revealedSecret, setRevealedSecret] = useState<string | null>(null);
  const [copiedField, setCopiedField] = useState<string | null>(null);

  const toast = useToast();

  useEffect(() => {
    if (activeApp) {
      loadStats(activeApp.id);
      setRevealedSecret(null);
    }
  }, [activeApp?.id]);

  const loadStats = async (appId: string) => {
    setLoadingStats(true);
    try {
      const res = await api.getApplicationStats(appId);
      setStats(res);
    } catch (e) {
      console.error(e);
    } finally {
      setLoadingStats(false);
    }
  };

  const copyToClipboard = (text: string, fieldName: string) => {
    navigator.clipboard.writeText(text);
    setCopiedField(fieldName);
    toast.success(`Copied ${fieldName} to clipboard!`);
    setTimeout(() => setCopiedField(null), 2000);
  };

  const toggleRevealSecret = async () => {
    if (revealedSecret) {
      setRevealedSecret(null);
      return;
    }
    if (!activeApp) return;

    try {
      const res = await api.revealSecret(activeApp.id);
      setRevealedSecret(res.secret);
    } catch (e: any) {
      toast.error(e.message || 'Failed to reveal secret');
    }
  };

  if (!activeApp) {
    return (
      <div className="p-8 text-center bg-zinc-900/30 border border-zinc-800 rounded-3xl backdrop-blur-xl">
        <Layers className="w-12 h-12 text-zinc-500 mx-auto mb-4" />
        <h3 className="text-lg font-bold text-white mb-2">No Applications Found</h3>
        <p className="text-xs text-zinc-400 max-w-md mx-auto mb-6">
          Create your first developer application to start generating license keys, authenticating users, and exploring SDKs.
        </p>
        <button
          onClick={() => onNavigate('applications')}
          className="px-6 py-2.5 rounded-xl bg-red-600 hover:bg-red-500 text-white font-bold text-xs uppercase tracking-wider transition-colors inline-flex items-center gap-2"
        >
          <Plus className="w-4 h-4" /> Create Application
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* App Credentials Card */}
      <div className="p-6 rounded-2xl bg-zinc-900/50 border border-zinc-800/80 backdrop-blur-xl relative overflow-hidden">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div>
            <div className="flex items-center gap-2.5">
              <h2 className="text-xl font-bold text-white tracking-tight">{activeApp.name}</h2>
              <span
                className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded-full border ${
                  activeApp.status === 'ACTIVE'
                    ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
                    : 'bg-red-500/10 text-red-400 border-red-500/30'
                }`}
              >
                {activeApp.status}
              </span>
              <span className="text-[10px] font-mono text-zinc-400 bg-zinc-800/80 px-2 py-0.5 rounded">
                v{activeApp.version}
              </span>
            </div>
            {activeApp.description && (
              <p className="text-xs text-zinc-400 mt-1 max-w-2xl">{activeApp.description}</p>
            )}
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            <button
              onClick={onOpenCreateUser}
              className="px-4 py-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-white text-xs font-semibold flex items-center gap-1.5 transition-colors border border-zinc-700/60"
            >
              <Plus className="w-3.5 h-3.5 text-red-400" /> Create User
            </button>
            <button
              onClick={onOpenGenerateKey}
              className="px-4 py-2 rounded-xl bg-red-600 hover:bg-red-500 text-white text-xs font-bold flex items-center gap-1.5 transition-colors shadow-[0_0_20px_rgba(239,68,68,0.3)]"
            >
              <KeyRound className="w-3.5 h-3.5" /> Generate Key
            </button>
            <button
              onClick={() => onNavigate('sdk')}
              className="px-4 py-2 rounded-xl bg-zinc-900 hover:bg-zinc-800 text-zinc-300 text-xs font-semibold flex items-center gap-1.5 transition-colors border border-zinc-800"
            >
              <Terminal className="w-3.5 h-3.5 text-zinc-400" /> Live SDK Tester
            </button>
          </div>
        </div>

        {/* Credentials Grid */}
        <div className="mt-6 pt-6 border-t border-zinc-800/80 grid grid-cols-1 sm:grid-cols-3 gap-4 font-mono text-xs">
          <div className="p-3 rounded-xl bg-zinc-950/60 border border-zinc-800 flex items-center justify-between">
            <div>
              <span className="text-[10px] text-zinc-500 uppercase tracking-wider block">Application ID</span>
              <span className="text-zinc-200 font-bold">{activeApp.id}</span>
            </div>
            <button
              onClick={() => copyToClipboard(activeApp.id, 'Application ID')}
              className="text-zinc-400 hover:text-white p-1 rounded hover:bg-zinc-800"
            >
              {copiedField === 'Application ID' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            </button>
          </div>

          <div className="p-3 rounded-xl bg-zinc-950/60 border border-zinc-800 flex items-center justify-between">
            <div>
              <span className="text-[10px] text-zinc-500 uppercase tracking-wider block">Owner ID</span>
              <span className="text-zinc-200 font-bold">{activeApp.owner_code}</span>
            </div>
            <button
              onClick={() => copyToClipboard(activeApp.owner_code, 'Owner ID')}
              className="text-zinc-400 hover:text-white p-1 rounded hover:bg-zinc-800"
            >
              {copiedField === 'Owner ID' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            </button>
          </div>

          <div className="p-3 rounded-xl bg-zinc-950/60 border border-zinc-800 flex items-center justify-between">
            <div className="truncate mr-2">
              <span className="text-[10px] text-zinc-500 uppercase tracking-wider block">Application Secret</span>
              <span className="text-red-400 font-bold truncate block">
                {revealedSecret || activeApp.secretMasked || '••••••••••••••••'}
              </span>
            </div>
            <div className="flex items-center gap-1">
              <button
                onClick={toggleRevealSecret}
                className="text-zinc-400 hover:text-white p-1 rounded hover:bg-zinc-800"
                title={revealedSecret ? 'Hide secret' : 'Reveal secret'}
              >
                {revealedSecret ? <EyeOff className="w-3.5 h-3.5 text-amber-400" /> : <Eye className="w-3.5 h-3.5" />}
              </button>
              <button
                onClick={() => copyToClipboard(revealedSecret || activeApp.secret || '', 'Application Secret')}
                className="text-zinc-400 hover:text-white p-1 rounded hover:bg-zinc-800"
              >
                {copiedField === 'Application Secret' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Four Metrics Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        <StatCard
          title="ACTIVE USERS"
          value={activeApp.user_count || 0}
          subtitle="Managed application users"
          icon={Users}
          badge="Live"
          badgeColor="green"
          action={{
            label: 'Manage Users',
            onClick: () => onNavigate('users'),
          }}
        />

        <StatCard
          title="ACTIVE LICENSES"
          value={`${activeApp.active_license_count || 0} / ${activeApp.license_count || 0}`}
          subtitle="Unlimited Keys Enabled"
          icon={KeyRound}
          badge="Operational"
          badgeColor="green"
          action={{
            label: 'View Keys',
            onClick: () => onNavigate('licenses'),
          }}
        />

        <StatCard
          title="API REQUESTS"
          value={activeApp.request_count || 0}
          subtitle="Total recorded API calls"
          icon={Activity}
          badge="Healthy"
          badgeColor="blue"
          action={{
            label: 'View Stats',
            onClick: () => onNavigate('statistics'),
          }}
        />

        <StatCard
          title="DEVELOPER PLAN"
          value="UNLIMITED"
          subtitle="Unlimited Keys & Users"
          icon={KeyRound}
          badge="Active"
          badgeColor="green"
          action={{
            label: 'KeyAuth v1 Drop-in',
            onClick: () => onNavigate('sdk'),
          }}
        />
      </div>

      {/* Activity Charts & Breakdown */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Daily Requests / Registrations chart */}
        <div className="lg:col-span-2 p-6 rounded-2xl bg-zinc-900/40 border border-zinc-800/80 backdrop-blur-xl">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h3 className="text-sm font-bold text-white tracking-tight flex items-center gap-2">
                <Activity className="w-4 h-4 text-red-500" />
                API Traffic & Activity (Last 7 Days)
              </h3>
              <p className="text-xs text-zinc-400 mt-0.5">Request volume, registrations, and license activations</p>
            </div>
            <button
              onClick={() => activeApp && loadStats(activeApp.id)}
              className="p-1.5 rounded-lg text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${loadingStats ? 'animate-spin' : ''}`} />
            </button>
          </div>

          {stats?.dailyStats && stats.dailyStats.length > 0 ? (
            <div className="space-y-4">
              <div className="grid grid-cols-7 gap-2 h-44 items-end pt-4 pb-2 border-b border-zinc-800">
                {stats.dailyStats.map((day: any, idx: number) => {
                  const maxReq = Math.max(...stats.dailyStats.map((d: any) => d.requests), 1);
                  const heightPercent = Math.max(10, Math.round((day.requests / maxReq) * 100));

                  return (
                    <div key={idx} className="flex flex-col items-center gap-2 h-full justify-end group">
                      <div className="text-[10px] font-mono text-zinc-400 opacity-0 group-hover:opacity-100 transition-opacity">
                        {day.requests}
                      </div>
                      <div className="w-full bg-zinc-800/60 rounded-t-lg relative flex items-end justify-center overflow-hidden h-full">
                        <div
                          style={{ height: `${heightPercent}%` }}
                          className="w-full bg-gradient-to-t from-red-600 to-red-500 rounded-t-lg transition-all duration-500 shadow-[0_0_15px_rgba(239,68,68,0.4)] group-hover:from-red-500 group-hover:to-red-400"
                        />
                      </div>
                      <span className="text-[10px] font-mono text-zinc-400 truncate w-full text-center">
                        {day.date.split('-').slice(1).join('/')}
                      </span>
                    </div>
                  );
                })}
              </div>

              <div className="flex items-center justify-center gap-6 text-xs text-zinc-400 pt-1">
                <span className="flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded bg-red-500 shadow-[0_0_6px_rgba(239,68,68,0.8)]" />
                  API Requests
                </span>
                <span className="flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded bg-zinc-700" />
                  Baseline
                </span>
              </div>
            </div>
          ) : (
            <div className="h-44 flex items-center justify-center text-xs text-zinc-500">
              No API traffic recorded yet. Make a request using the SDK or Playground.
            </div>
          )}
        </div>

        {/* License Breakdown & Endpoints */}
        <div className="p-6 rounded-2xl bg-zinc-900/40 border border-zinc-800/80 backdrop-blur-xl flex flex-col justify-between">
          <div>
            <h3 className="text-sm font-bold text-white tracking-tight flex items-center gap-2 mb-4">
              <KeyRound className="w-4 h-4 text-red-500" />
              License Key Status
            </h3>

            <div className="space-y-3">
              {stats?.licenseBreakdown && stats.licenseBreakdown.length > 0 ? (
                stats.licenseBreakdown.map((item: any, idx: number) => (
                  <div key={idx} className="flex items-center justify-between p-3 rounded-xl bg-zinc-950/40 border border-zinc-800">
                    <span className="text-xs font-mono font-semibold text-zinc-300 uppercase">
                      {item.status}
                    </span>
                    <span className="text-xs font-mono font-bold text-white bg-zinc-800 px-2.5 py-0.5 rounded-full">
                      {item.count} keys
                    </span>
                  </div>
                ))
              ) : (
                <p className="text-xs text-zinc-500 py-4 text-center">No license keys created yet.</p>
              )}
            </div>

            <h4 className="text-xs font-bold uppercase tracking-wider text-zinc-400 mt-6 mb-3">
              Top Endpoints
            </h4>
            <div className="space-y-2">
              {stats?.topEndpoints && stats.topEndpoints.length > 0 ? (
                stats.topEndpoints.map((ep: any, idx: number) => (
                  <div key={idx} className="flex items-center justify-between text-xs font-mono">
                    <span className="text-zinc-400 truncate max-w-[170px]">{ep.endpoint}</span>
                    <span className="text-zinc-300 font-bold">{ep.count} hits</span>
                  </div>
                ))
              ) : (
                <p className="text-xs text-zinc-500 text-center py-2">No endpoint traffic logged.</p>
              )}
            </div>
          </div>

          <button
            onClick={() => onNavigate('statistics')}
            className="w-full mt-6 py-2 rounded-xl bg-zinc-800/60 hover:bg-zinc-800 text-zinc-300 text-xs font-semibold transition-colors text-center"
          >
            Detailed Analytics & Logs →
          </button>
        </div>
      </div>
    </div>
  );
};
