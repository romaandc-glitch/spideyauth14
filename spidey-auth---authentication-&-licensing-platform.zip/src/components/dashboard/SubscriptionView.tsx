import React, { useState } from 'react';
import {
  Sparkles,
  CheckCircle2,
  Check,
  Shield,
  Zap,
  CreditCard,
  ArrowRight,
  AlertCircle,
  KeyRound,
} from 'lucide-react';
import { Subscription, DeveloperUser } from '../../types';
import { api } from '../../services/api';
import { useToast } from '../ui/Toast';

interface SubscriptionViewProps {
  subscription: Subscription;
  user: DeveloperUser;
  onRefresh: () => void;
}

export const SubscriptionView: React.FC<SubscriptionViewProps> = ({
  subscription,
  user,
  onRefresh,
}) => {
  const [loading, setLoading] = useState(false);
  const toast = useToast();

  const handleUpgrade = async () => {
    setLoading(true);
    try {
      await api.upgradeSubscription();
      toast.success('Successfully upgraded to Premium Plan! You now have unlimited keys.', 'Upgrade Complete');
      onRefresh();
    } catch (err: any) {
      toast.error(err.message || 'Upgrade failed');
    } finally {
      setLoading(false);
    }
  };

  const handleDowngrade = async () => {
    setLoading(true);
    try {
      await api.downgradeSubscription();
      toast.info('Switched back to Free Tier.');
      onRefresh();
    } catch (err: any) {
      toast.error(err.message || 'Failed to downgrade');
    } finally {
      setLoading(false);
    }
  };

  const isPremium = subscription.plan_tier === 'PREMIUM';

  return (
    <div className="space-y-8 max-w-5xl mx-auto">
      <div>
        <h2 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
          <Sparkles className="w-5 h-5 text-amber-400" />
          Subscription & Limits
        </h2>
        <p className="text-xs text-zinc-400 mt-1">
          Manage your account tier, key capacities, and service level agreements.
        </p>
      </div>

      {/* Current Plan Overview Card */}
      <div className="p-6 rounded-2xl bg-zinc-900/50 border border-zinc-800/80 backdrop-blur-xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <span className="text-xs font-mono text-zinc-500 uppercase tracking-wider">CURRENT SUBSCRIPTION</span>
          <div className="flex items-center gap-3 mt-1">
            <h3 className="text-2xl font-extrabold text-white font-mono tracking-tight">
              {subscription.plan_tier} TIER
            </h3>
            <span
              className={`text-xs px-2.5 py-0.5 rounded-full font-bold uppercase tracking-wider border ${
                isPremium
                  ? 'bg-amber-500/10 text-amber-300 border-amber-500/30'
                  : 'bg-zinc-800 text-zinc-300 border-zinc-700'
              }`}
            >
              {subscription.status}
            </span>
          </div>
          <p className="text-xs text-zinc-400 mt-1">
            {isPremium
              ? 'Enjoying unlimited keys, priority bandwidth, and advanced telemetry.'
              : 'Free plan is limited to 20 license keys per application.'}
          </p>
        </div>

        <div className="text-right">
          <div className="text-2xl font-extrabold font-mono text-white">
            {isPremium ? '$29' : '$0'}
            <span className="text-xs font-normal text-zinc-400">/mo</span>
          </div>
          {isPremium && (
            <button
              onClick={handleDowngrade}
              disabled={loading}
              className="text-xs text-zinc-400 hover:text-zinc-200 underline mt-2 block"
            >
              Downgrade to Free
            </button>
          )}
        </div>
      </div>

      {/* Plan Cards Comparison */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* FREE PLAN */}
        <div
          className={`p-8 rounded-3xl border backdrop-blur-xl flex flex-col justify-between transition-all ${
            !isPremium
              ? 'bg-zinc-900/60 border-zinc-700 shadow-xl'
              : 'bg-zinc-900/30 border-zinc-800/80 opacity-80'
          }`}
        >
          <div>
            <div className="flex items-center justify-between mb-4">
              <span className="text-xs font-mono uppercase tracking-widest text-zinc-400 font-bold">FREE PLAN</span>
              {!isPremium && (
                <span className="text-[10px] bg-zinc-800 text-emerald-400 font-bold px-2 py-0.5 rounded-full font-mono border border-emerald-500/30">
                  CURRENT
                </span>
              )}
            </div>
            <div className="flex items-baseline gap-1 text-white mb-4">
              <span className="text-4xl sm:text-5xl font-mono font-extrabold">$0</span>
              <span className="text-zinc-400 text-xs">/ month</span>
            </div>
            <p className="text-xs text-zinc-400 leading-relaxed mb-6">
              Ideal for prototyping software and early testing stages.
            </p>

            <ul className="space-y-3 text-xs text-zinc-300">
              <li className="flex items-center gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-red-400 shrink-0" />
                <span><strong>Maximum 20 license keys</strong> per application</span>
              </li>
              <li className="flex items-center gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-red-400 shrink-0" />
                <span>Basic user management</span>
              </li>
              <li className="flex items-center gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-red-400 shrink-0" />
                <span>Full C#, C++, Python, and JS SDK access</span>
              </li>
              <li className="flex items-center gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-red-400 shrink-0" />
                <span>Core API rate limiting</span>
              </li>
              <li className="flex items-center gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-red-400 shrink-0" />
                <span>Basic request statistics</span>
              </li>
            </ul>
          </div>

          <div className="mt-8">
            <button
              disabled={!isPremium}
              onClick={handleDowngrade}
              className="w-full py-3 rounded-xl bg-zinc-800 text-white text-xs font-bold uppercase tracking-wider disabled:opacity-50 transition-colors"
            >
              {!isPremium ? 'CURRENT PLAN' : 'SWITCH TO FREE'}
            </button>
          </div>
        </div>

        {/* PREMIUM PLAN */}
        <div
          className={`p-8 rounded-3xl border-2 backdrop-blur-xl flex flex-col justify-between transition-all relative ${
            isPremium
              ? 'bg-zinc-900/80 border-amber-500/50 shadow-[0_0_50px_rgba(245,158,11,0.15)]'
              : 'bg-zinc-900/60 border-red-500/50 shadow-[0_0_50px_rgba(239,68,68,0.15)]'
          }`}
        >
          <div className="absolute -top-3.5 right-8 bg-gradient-to-r from-red-600 to-amber-500 text-white text-[10px] font-bold tracking-widest px-3 py-1 rounded-full uppercase shadow-md">
            {isPremium ? 'ACTIVE SUBSCRIPTION' : 'RECOMMENDED'}
          </div>

          <div>
            <div className="flex items-center justify-between mb-4">
              <span className="text-xs font-mono uppercase tracking-widest text-amber-400 font-bold">PREMIUM PLAN</span>
              <span className="text-[10px] bg-amber-500/20 text-amber-300 px-2 py-0.5 rounded-full font-mono border border-amber-500/30">
                ENTERPRISE READY
              </span>
            </div>
            <div className="flex items-baseline gap-1 text-white mb-4">
              <span className="text-4xl sm:text-5xl font-mono font-extrabold">$29</span>
              <span className="text-zinc-400 text-xs">/ month</span>
            </div>
            <p className="text-xs text-zinc-400 leading-relaxed mb-6">
              For commercial developers who require high key volumes, priority throughput, and full telemetry.
            </p>

            <ul className="space-y-3 text-xs text-zinc-200">
              <li className="flex items-center gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-amber-400 shrink-0" />
                <span><strong>Unlimited license keys</strong> (100,000+ per app)</span>
              </li>
              <li className="flex items-center gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-amber-400 shrink-0" />
                <span>Advanced user management & bulk operations</span>
              </li>
              <li className="flex items-center gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-amber-400 shrink-0" />
                <span>High-bandwidth priority API throughput</span>
              </li>
              <li className="flex items-center gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-amber-400 shrink-0" />
                <span>Deep telemetry, audit trails & logs</span>
              </li>
              <li className="flex items-center gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-amber-400 shrink-0" />
                <span>Priority features & premium dashboard badge</span>
              </li>
            </ul>
          </div>

          <div className="mt-8">
            <button
              disabled={isPremium || loading}
              onClick={handleUpgrade}
              className={`w-full py-3.5 rounded-xl text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-2 transition-all shadow-lg ${
                isPremium
                  ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 cursor-default'
                  : 'bg-red-600 hover:bg-red-500 text-white shadow-[0_0_25px_rgba(239,68,68,0.4)]'
              }`}
            >
              {isPremium ? (
                <>
                  <Check className="w-4 h-4" /> CURRENTLY ACTIVE
                </>
              ) : loading ? (
                'Processing...'
              ) : (
                <>
                  <Sparkles className="w-4 h-4" /> UPGRADE NOW
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
