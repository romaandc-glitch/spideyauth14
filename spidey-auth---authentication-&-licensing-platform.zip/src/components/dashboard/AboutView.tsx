import React from 'react';
import { Shield, Lock, Terminal, Cpu, Layers, ExternalLink, CheckCircle2 } from 'lucide-react';

export const AboutView: React.FC = () => {
  return (
    <div className="space-y-8 max-w-4xl mx-auto py-4">
      {/* Hero Card */}
      <div className="p-8 rounded-3xl bg-zinc-900/50 border border-zinc-800/80 backdrop-blur-xl relative overflow-hidden text-center">
        <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-red-500 to-red-700 flex items-center justify-center text-white mx-auto mb-5 shadow-[0_0_30px_rgba(239,68,68,0.4)]">
          <Shield className="w-8 h-8" />
        </div>

        <h1 className="text-3xl font-extrabold text-white tracking-tight font-mono uppercase">
          ABOUT SPIDEY <span className="text-red-500">AUTH</span>
        </h1>

        <p className="mt-4 text-sm sm:text-base text-zinc-300 leading-relaxed max-w-2xl mx-auto">
          Spidey Auth is a modern authentication and licensing platform built for developers who need a simple and secure way to manage application users, authentication, licenses and API access.
        </p>

        <div className="mt-6 inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-red-500/10 border border-red-500/20 text-red-400 text-xs font-mono font-bold tracking-wider">
          Built by Spidey
        </div>
      </div>

      {/* Architecture Highlights */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="p-6 rounded-2xl bg-zinc-900/40 border border-zinc-800">
          <div className="p-2.5 rounded-xl bg-red-500/10 text-red-400 w-fit mb-3">
            <Lock className="w-5 h-5" />
          </div>
          <h3 className="text-sm font-bold text-white mb-2">Zero Trust & Legitimate Architecture</h3>
          <p className="text-xs text-zinc-400 leading-relaxed">
            Spidey Auth is built for legitimate software licensing, game distribution, and enterprise developer tools. We strictly prohibit credential theft, malware, bypass mechanisms, stealth persistence, or security evasion.
          </p>
        </div>

        <div className="p-6 rounded-2xl bg-zinc-900/40 border border-zinc-800">
          <div className="p-2.5 rounded-xl bg-red-500/10 text-red-400 w-fit mb-3">
            <Layers className="w-5 h-5" />
          </div>
          <h3 className="text-sm font-bold text-white mb-2">Multi-Tenant Isolation</h3>
          <p className="text-xs text-zinc-400 leading-relaxed">
            Every application possesses an autonomous cryptographic realm. Developer A can never inspect Developer B's users, licenses, or logs. Queries enforce strict ownership verification.
          </p>
        </div>

        <div className="p-6 rounded-2xl bg-zinc-900/40 border border-zinc-800">
          <div className="p-2.5 rounded-xl bg-red-500/10 text-red-400 w-fit mb-3">
            <Cpu className="w-5 h-5" />
          </div>
          <h3 className="text-sm font-bold text-white mb-2">Hardware-Bound Licensing</h3>
          <p className="text-xs text-zinc-400 leading-relaxed">
            Licenses support hardware identifier binding (HWID) to prevent key redistribution while giving developers the flexibility to configure activation caps and revocation states.
          </p>
        </div>

        <div className="p-6 rounded-2xl bg-zinc-900/40 border border-zinc-800">
          <div className="p-2.5 rounded-xl bg-red-500/10 text-red-400 w-fit mb-3">
            <Terminal className="w-5 h-5" />
          </div>
          <h3 className="text-sm font-bold text-white mb-2">Multi-Language Ecosystem</h3>
          <p className="text-xs text-zinc-400 leading-relaxed">
            Official SDKs for C# (.NET/Unity/WPF), C++ (native executables), Python (desktop/backend), and TypeScript/JavaScript (Electron/Node).
          </p>
        </div>
      </div>

      {/* Platform Specification Table */}
      <div className="p-6 rounded-2xl bg-zinc-900/40 border border-zinc-800 font-mono text-xs space-y-2">
        <h4 className="text-xs font-bold text-white uppercase font-sans mb-3">Platform Specification</h4>
        <div className="flex justify-between py-1.5 border-b border-zinc-800">
          <span className="text-zinc-500">Platform Name:</span>
          <span className="text-white font-bold">SPIDEY AUTH</span>
        </div>
        <div className="flex justify-between py-1.5 border-b border-zinc-800">
          <span className="text-zinc-500">Core Tagline:</span>
          <span className="text-zinc-300">"Authentication & Licensing Built for Developers."</span>
        </div>
        <div className="flex justify-between py-1.5 border-b border-zinc-800">
          <span className="text-zinc-500">Database Engine:</span>
          <span className="text-emerald-400">SQLite (Relational Schema with Foreign Keys & Indexes)</span>
        </div>
        <div className="flex justify-between py-1.5 border-b border-zinc-800">
          <span className="text-zinc-500">Password Hashing:</span>
          <span className="text-zinc-300">Salted Bcrypt (10 rounds)</span>
        </div>
        <div className="flex justify-between py-1.5 border-b border-zinc-800">
          <span className="text-zinc-500">Identity Providers:</span>
          <span className="text-zinc-300">Email/Password + Google OAuth 2.0 / OpenID Connect</span>
        </div>
        <div className="flex justify-between py-1.5">
          <span className="text-zinc-500">Author & Craft:</span>
          <span className="text-red-400 font-bold">Built by Spidey</span>
        </div>
      </div>
    </div>
  );
};
