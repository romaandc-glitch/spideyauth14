import React, { useState } from 'react';
import {
  Shield,
  KeyRound,
  Users,
  Code2,
  Terminal,
  Zap,
  Lock,
  ArrowRight,
  CheckCircle2,
  Check,
  ChevronRight,
  Copy,
  Cpu,
  Layers,
  Database,
  Globe2,
  Sparkles,
  HelpCircle,
  ExternalLink,
} from 'lucide-react';
import { CodeBlock } from '../ui/CodeBlock';

interface LandingPageProps {
  onGetStarted: () => void;
  onViewDocs: () => void;
  onExploreSDK: () => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({
  onGetStarted,
  onViewDocs,
  onExploreSDK,
}) => {
  const [activeTab, setActiveTab] = useState<'csharp' | 'cpp' | 'python' | 'js'>('csharp');
  const [openFaq, setOpenFaq] = useState<number | null>(0);

  const sdkSnippets = {
    csharp: `using SpideyAuthSDK;

// Initialize with Application ID and Secret
var auth = new SpideyAuth("APP-92JD83", "spy_sec_your_secret");

// Authenticate Application User
var result = await auth.LoginAsync("player123", "secretPassword!");
if (result.Success) {
    Console.WriteLine($"Welcome, {result.Data?.Username}!");
    Console.WriteLine($"Subscription Role: {result.Data?.SubscriptionRole}");
}

// Activate License Key
var license = await auth.ActivateLicenseAsync("SPIDEY-AX91-KL84-99P2-44QR");
Console.WriteLine($"License Status: {license.Data?.Status}");`,

    cpp: `#include "SpideyAuth.hpp"
#include <iostream>

int main() {
    SpideyAuth::Client auth("APP-92JD83", "spy_sec_your_secret");

    SpideyAuth::User user;
    if (auth.Login("player123", "secretPassword!", user).success) {
        std::cout << "Authenticated: " << user.username << std::endl;
        std::cout << "Tier: " << user.subscriptionRole << std::endl;
    }

    SpideyAuth::License license;
    if (auth.ActivateLicense("SPIDEY-AX91-KL84-99P2-44QR", license).success) {
        std::cout << "License active! Expires: " << license.expires << std::endl;
    }
    return 0;
}`,

    python: `from spidey_auth import SpideyAuth

# Initialize Client
auth = SpideyAuth(
    application_id="APP-92JD83",
    application_secret="spy_sec_your_secret"
)

# User Login
user = auth.login("player123", "password123")
print(f"Logged in user: {user['user']['username']}")

# License Activation
license_info = auth.activate_license("SPIDEY-AX91-KL84-99P2-44QR")
print(f"License Active! Type: {license_info['license']['subscriptionType']}")`,

    js: `import { SpideyAuth } from '@spideyauth/sdk';

const auth = new SpideyAuth({
  applicationId: 'APP-92JD83',
  applicationSecret: 'spy_sec_your_secret',
});

// Authenticate
const user = await auth.login('player123', 'secretPassword!');
console.log('Authenticated user:', user.username);

// Activate License
const license = await auth.activateLicense('SPIDEY-AX91-KL84-99P2-44QR');
console.log('Expires at:', license.expires);`,
  };

  const faqs = [
    {
      q: 'What is Spidey Auth?',
      a: 'Spidey Auth is a complete developer authentication, user management, and licensing platform. Developers create isolated applications inside Spidey Auth and integrate them via our official C#, C++, Python, and JavaScript SDKs or REST API.',
    },
    {
      q: 'How does multi-tenant application isolation work?',
      a: 'Each developer application created in Spidey Auth has its own unique Application ID, cryptographic secret, and isolated database namespace. Application users and license keys created inside Application A can never be accessed or authenticated against Application B.',
    },
    {
      q: 'Are there any limits on license keys or user accounts?',
      a: 'No! Anyone can create unlimited applications, generate unlimited license keys, and register unlimited end users completely free with zero subscriptions or restrictions.',
    },
    {
      q: 'Are passwords and secrets safe?',
      a: 'Yes. We strictly adhere to modern security standards: passwords are never stored in plaintext and are hashed using salted bcrypt. Application secrets are generated cryptographically and masked in frontend views.',
    },
    {
      q: 'Can I integrate Spidey Auth into games, desktop software, and web tools?',
      a: 'Yes! We provide purpose-built client libraries for C# (.NET/Unity/WPF), C++ (native engines/executables), Python (scripts/automation/desktop), and TypeScript/JavaScript (Electron/Node/React).',
    },
  ];

  return (
    <div className="min-h-screen bg-[#090a0f] text-gray-100 overflow-x-hidden selection:bg-red-500/30 selection:text-red-200">
      {/* Spider Web Glow Hero Accent */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[1000px] h-[550px] bg-gradient-to-b from-red-600/15 via-red-900/5 to-transparent blur-3xl pointer-events-none" />

      {/* HERO SECTION */}
      <section className="relative pt-24 pb-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto text-center">
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-red-500/10 border border-red-500/20 text-red-400 text-xs font-semibold mb-8 shadow-[0_0_20px_rgba(239,68,68,0.2)] animate-pulse">
          <Shield className="w-3.5 h-3.5 text-red-400" />
          <span>Spidey Auth Platform v1.0 • Next-Gen Developer Licensing</span>
        </div>

        <h1 className="text-4xl sm:text-6xl lg:text-7xl font-extrabold tracking-tight text-white max-w-5xl mx-auto leading-none uppercase">
          SPIDEY <span className="text-transparent bg-clip-text bg-gradient-to-r from-red-500 to-red-600">AUTH</span>
          <br />
          <span className="text-2xl sm:text-4xl lg:text-5xl text-zinc-300 font-bold block mt-3">
            AUTHENTICATION BUILT FOR DEVELOPERS.
          </span>
        </h1>

        <p className="mt-6 text-base sm:text-lg text-zinc-400 max-w-2xl mx-auto leading-relaxed">
          Secure authentication, user management, licensing, APIs and developer tools for modern applications.
        </p>

        <div className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-4">
          <button
            onClick={onGetStarted}
            className="w-full sm:w-auto px-8 py-3.5 rounded-xl bg-red-600 hover:bg-red-500 text-white font-bold text-sm tracking-wide uppercase shadow-[0_0_30px_rgba(239,68,68,0.4)] hover:shadow-[0_0_40px_rgba(239,68,68,0.6)] transition-all duration-300 flex items-center justify-center gap-2 group"
          >
            <span>GET STARTED</span>
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </button>

          <button
            onClick={onViewDocs}
            className="w-full sm:w-auto px-8 py-3.5 rounded-xl bg-zinc-900/80 hover:bg-zinc-800 border border-zinc-700/80 text-zinc-200 font-bold text-sm tracking-wide uppercase hover:border-zinc-500 transition-all duration-300 flex items-center justify-center gap-2"
          >
            <span>VIEW DOCUMENTATION</span>
            <Code2 className="w-4 h-4 text-zinc-400" />
          </button>
        </div>

        {/* Live Metrics preview bar */}
        <div className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-4 max-w-4xl mx-auto">
          <div className="p-4 rounded-2xl bg-zinc-900/40 border border-zinc-800/80 backdrop-blur-xl">
            <div className="text-2xl font-mono font-bold text-white">&lt; 15ms</div>
            <div className="text-xs text-zinc-400 mt-1">API Response Latency</div>
          </div>
          <div className="p-4 rounded-2xl bg-zinc-900/40 border border-zinc-800/80 backdrop-blur-xl">
            <div className="text-2xl font-mono font-bold text-red-400">100% Isolated</div>
            <div className="text-xs text-zinc-400 mt-1">Multi-Tenant Scopes</div>
          </div>
          <div className="p-4 rounded-2xl bg-zinc-900/40 border border-zinc-800/80 backdrop-blur-xl">
            <div className="text-2xl font-mono font-bold text-white">4 Languages</div>
            <div className="text-xs text-zinc-400 mt-1">Official Native SDKs</div>
          </div>
          <div className="p-4 rounded-2xl bg-zinc-900/40 border border-zinc-800/80 backdrop-blur-xl">
            <div className="text-2xl font-mono font-bold text-emerald-400">99.99%</div>
            <div className="text-xs text-zinc-400 mt-1">Platform Uptime</div>
          </div>
        </div>
      </section>

      {/* HOW IT WORKS SECTION */}
      <section className="py-20 border-t border-zinc-800/60 bg-zinc-950/60">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <span className="text-xs font-bold text-red-500 uppercase tracking-widest font-mono">
              Architecture & Flow
            </span>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-white mt-2 tracking-tight">
              HOW SPIDEY AUTH WORKS
            </h2>
            <p className="text-zinc-400 text-sm mt-3">
              Three seamless steps from account creation to production-grade client authorization.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="p-6 rounded-2xl bg-zinc-900/50 border border-zinc-800 hover:border-red-500/30 transition-all duration-300 relative group">
              <div className="w-12 h-12 rounded-xl bg-red-600/10 border border-red-500/30 flex items-center justify-center text-red-400 font-mono font-bold text-lg mb-4 group-hover:scale-110 transition-transform">
                01
              </div>
              <h3 className="text-lg font-bold text-white mb-2">Create Application</h3>
              <p className="text-xs text-zinc-400 leading-relaxed">
                Register inside Spidey Auth and generate your application credentials: Application ID, Owner Code, and cryptographically secure Application Secret.
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-zinc-900/50 border border-zinc-800 hover:border-red-500/30 transition-all duration-300 relative group">
              <div className="w-12 h-12 rounded-xl bg-red-600/10 border border-red-500/30 flex items-center justify-center text-red-400 font-mono font-bold text-lg mb-4 group-hover:scale-110 transition-transform">
                02
              </div>
              <h3 className="text-lg font-bold text-white mb-2">Configure Users & Licenses</h3>
              <p className="text-xs text-zinc-400 leading-relaxed">
                Generate single or bulk license keys in the format <code className="text-red-300 font-mono">SPIDEY-XXXX-XXXX...</code>, configure roles, expiration dates, and activation limits.
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-zinc-900/50 border border-zinc-800 hover:border-red-500/30 transition-all duration-300 relative group">
              <div className="w-12 h-12 rounded-xl bg-red-600/10 border border-red-500/30 flex items-center justify-center text-red-400 font-mono font-bold text-lg mb-4 group-hover:scale-110 transition-transform">
                03
              </div>
              <h3 className="text-lg font-bold text-white mb-2">Integrate via SDK & API</h3>
              <p className="text-xs text-zinc-400 leading-relaxed">
                Drop our C#, C++, Python, or JavaScript SDK into your client application. Authenticate users and activate keys with just 2 lines of code.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CORE FEATURES SECTION */}
      <section className="py-20 border-t border-zinc-800/60">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <span className="text-xs font-bold text-red-500 uppercase tracking-widest font-mono">
              Complete Feature Suite
            </span>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-white mt-2 tracking-tight">
              ENGINEERED FOR SERIOUS DEVELOPERS
            </h2>
            <p className="text-zinc-400 text-sm mt-3">
              Everything you need to secure, distribute, and monetize your client applications.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <div className="p-6 rounded-2xl bg-zinc-900/40 border border-zinc-800 hover:border-red-500/40 hover:shadow-[0_0_30px_rgba(239,68,68,0.1)] transition-all">
              <div className="p-3 w-fit rounded-xl bg-red-500/10 text-red-400 mb-4">
                <Users className="w-6 h-6" />
              </div>
              <h3 className="text-base font-bold text-white mb-2">Multi-Tenant User Management</h3>
              <p className="text-xs text-zinc-400 leading-relaxed">
                Create and manage application users directly from your dashboard or allow in-app self-registration with license validation.
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-zinc-900/40 border border-zinc-800 hover:border-red-500/40 hover:shadow-[0_0_30px_rgba(239,68,68,0.1)] transition-all">
              <div className="p-3 w-fit rounded-xl bg-red-500/10 text-red-400 mb-4">
                <KeyRound className="w-6 h-6" />
              </div>
              <h3 className="text-base font-bold text-white mb-2">Cryptographic License Key Engine</h3>
              <p className="text-xs text-zinc-400 leading-relaxed">
                Generate single or bulk license keys with custom expiration dates, maximum activations, status revocation, and subscription types.
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-zinc-900/40 border border-zinc-800 hover:border-red-500/40 hover:shadow-[0_0_30px_rgba(239,68,68,0.1)] transition-all">
              <div className="p-3 w-fit rounded-xl bg-red-500/10 text-red-400 mb-4">
                <Shield className="w-6 h-6" />
              </div>
              <h3 className="text-base font-bold text-white mb-2">Strict Multi-Tenant Isolation</h3>
              <p className="text-xs text-zinc-400 leading-relaxed">
                Every application is strictly isolated. Database queries enforce ownership barriers to guarantee zero cross-developer contamination.
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-zinc-900/40 border border-zinc-800 hover:border-red-500/40 hover:shadow-[0_0_30px_rgba(239,68,68,0.1)] transition-all">
              <div className="p-3 w-fit rounded-xl bg-red-500/10 text-red-400 mb-4">
                <Zap className="w-6 h-6" />
              </div>
              <h3 className="text-base font-bold text-white mb-2">Built-in Rate Limiting</h3>
              <p className="text-xs text-zinc-400 leading-relaxed">
                Protect your apps from brute-force login attempts and spam with our native sliding-window rate limiters returning standardized error payloads.
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-zinc-900/40 border border-zinc-800 hover:border-red-500/40 hover:shadow-[0_0_30px_rgba(239,68,68,0.1)] transition-all">
              <div className="p-3 w-fit rounded-xl bg-red-500/10 text-red-400 mb-4">
                <Cpu className="w-6 h-6" />
              </div>
              <h3 className="text-base font-bold text-white mb-2">Client Hardware Binding</h3>
              <p className="text-xs text-zinc-400 leading-relaxed">
                Track client device identifiers (HWID/machine hashes) upon license activation to enforce multi-device limits and prevent key sharing.
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-zinc-900/40 border border-zinc-800 hover:border-red-500/40 hover:shadow-[0_0_30px_rgba(239,68,68,0.1)] transition-all">
              <div className="p-3 w-fit rounded-xl bg-red-500/10 text-red-400 mb-4">
                <Database className="w-6 h-6" />
              </div>
              <h3 className="text-base font-bold text-white mb-2">Comprehensive Audit Logging</h3>
              <p className="text-xs text-zinc-400 leading-relaxed">
                Full immutable audit trail recording every user login, failed password attempt, key generation, secret reset, and admin action.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* DEVELOPER SDK & API PREVIEW SECTION */}
      <section className="py-20 border-t border-zinc-800/60 bg-zinc-950/70">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col lg:flex-row items-start justify-between gap-12">
            <div className="lg:w-1/2">
              <span className="text-xs font-bold text-red-500 uppercase tracking-widest font-mono">
                Developer SDK
              </span>
              <h2 className="text-3xl sm:text-4xl font-extrabold text-white mt-2 tracking-tight">
                INTEGRATE IN MINUTES ACROSS ANY STACK
              </h2>
              <p className="text-zinc-400 text-sm mt-4 leading-relaxed">
                Whether you are developing desktop tools in C#, games in C++, automation scripts in Python, or modern web clients with TypeScript, Spidey Auth provides high-performance SDKs with zero unnecessary overhead.
              </p>

              <div className="mt-8 space-y-3">
                <div className="flex items-start gap-3">
                  <div className="p-1 rounded-full bg-red-500/20 text-red-400 mt-0.5">
                    <Check className="w-3.5 h-3.5" />
                  </div>
                  <div>
                    <h5 className="text-xs font-bold text-white">Full Type Safety & Structured Errors</h5>
                    <p className="text-xs text-zinc-400">Standardized error codes like <code className="text-red-400">INVALID_USERNAME</code> and <code className="text-red-400">ACTIVATION_LIMIT_REACHED</code>.</p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="p-1 rounded-full bg-red-500/20 text-red-400 mt-0.5">
                    <Check className="w-3.5 h-3.5" />
                  </div>
                  <div>
                    <h5 className="text-xs font-bold text-white">Interactive In-Dashboard Playground</h5>
                    <p className="text-xs text-zinc-400">Test live requests against your actual application right inside your browser.</p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="p-1 rounded-full bg-red-500/20 text-red-400 mt-0.5">
                    <Check className="w-3.5 h-3.5" />
                  </div>
                  <div>
                    <h5 className="text-xs font-bold text-white">Secure Secret Management</h5>
                    <p className="text-xs text-zinc-400">Secrets are revocable and regeneratable on demand without losing user or license data.</p>
                  </div>
                </div>
              </div>

              <div className="mt-8">
                <button
                  onClick={onExploreSDK}
                  className="px-6 py-3 rounded-xl bg-zinc-900 border border-zinc-700 hover:border-red-500/50 text-white text-xs font-bold uppercase tracking-wider flex items-center gap-2 hover:bg-zinc-800 transition-colors"
                >
                  <Terminal className="w-4 h-4 text-red-400" /> Open Live SDK Playground
                </button>
              </div>
            </div>

            {/* Code Tabs */}
            <div className="lg:w-1/2 w-full">
              <div className="flex items-center gap-2 mb-3 bg-zinc-900/60 p-1.5 rounded-xl border border-zinc-800">
                <button
                  onClick={() => setActiveTab('csharp')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-mono font-semibold transition-colors ${
                    activeTab === 'csharp' ? 'bg-red-600 text-white' : 'text-zinc-400 hover:text-white'
                  }`}
                >
                  C# (.NET)
                </button>
                <button
                  onClick={() => setActiveTab('cpp')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-mono font-semibold transition-colors ${
                    activeTab === 'cpp' ? 'bg-red-600 text-white' : 'text-zinc-400 hover:text-white'
                  }`}
                >
                  C++ Native
                </button>
                <button
                  onClick={() => setActiveTab('python')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-mono font-semibold transition-colors ${
                    activeTab === 'python' ? 'bg-red-600 text-white' : 'text-zinc-400 hover:text-white'
                  }`}
                >
                  Python
                </button>
                <button
                  onClick={() => setActiveTab('js')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-mono font-semibold transition-colors ${
                    activeTab === 'js' ? 'bg-red-600 text-white' : 'text-zinc-400 hover:text-white'
                  }`}
                >
                  TypeScript
                </button>
              </div>

              <CodeBlock
                code={sdkSnippets[activeTab]}
                language={activeTab === 'csharp' ? 'csharp' : activeTab === 'cpp' ? 'cpp' : activeTab === 'python' ? 'python' : 'typescript'}
                title={`SpideyAuth Client Implementation (${activeTab.toUpperCase()})`}
              />
            </div>
          </div>
        </div>
      </section>

      {/* KEYAUTH V1 DROP-IN & UNLIMITED DEVELOPER PLATFORM SECTION */}
      <section className="py-20 border-t border-zinc-800/60" id="keyauth-dropin">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <span className="text-xs font-bold text-emerald-400 uppercase tracking-widest font-mono">
              KeyAuth v1 Drop-in Compatible & Unlimited
            </span>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-white mt-2 tracking-tight">
              UNLIMITED KEYS & USERS • ZERO SUBSCRIPTION
            </h2>
            <p className="text-zinc-400 text-sm mt-3">
              Drop Spidey Auth directly into your existing KeyAuth v1 projects. Anyone can create unlimited keys and users with no subscriptions or paywalls.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-5xl mx-auto mb-12">
            <div className="p-6 rounded-3xl bg-zinc-900/40 border border-zinc-800/80 backdrop-blur-xl hover:border-emerald-500/40 transition-all flex flex-col justify-between">
              <div>
                <div className="w-10 h-10 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 flex items-center justify-center mb-4">
                  <KeyRound className="w-5 h-5" />
                </div>
                <h3 className="text-base font-bold text-white mb-2">Unlimited License Keys</h3>
                <p className="text-xs text-zinc-400 leading-relaxed">
                  Generate single or bulk license keys in batches of hundreds or thousands. Set custom prefixes, expiration dates, and multi-device activation limits without hitting any quota.
                </p>
              </div>
              <div className="mt-6 pt-4 border-t border-zinc-800/80">
                <span className="text-[11px] font-mono font-bold text-emerald-400 uppercase">100% Free Forever</span>
              </div>
            </div>

            <div className="p-6 rounded-3xl bg-zinc-900/40 border border-zinc-800/80 backdrop-blur-xl hover:border-red-500/40 transition-all flex flex-col justify-between">
              <div>
                <div className="w-10 h-10 rounded-2xl bg-red-500/10 border border-red-500/20 text-red-400 flex items-center justify-center mb-4">
                  <Users className="w-5 h-5" />
                </div>
                <h3 className="text-base font-bold text-white mb-2">Unlimited End Users</h3>
                <p className="text-xs text-zinc-400 leading-relaxed">
                  Register as many players, clients, and customer accounts as you need. Includes password hashing, HWID device locking, account banning, and subscription roles.
                </p>
              </div>
              <div className="mt-6 pt-4 border-t border-zinc-800/80">
                <span className="text-[11px] font-mono font-bold text-red-400 uppercase">No User Caps</span>
              </div>
            </div>

            <div className="p-6 rounded-3xl bg-zinc-900/40 border border-zinc-800/80 backdrop-blur-xl hover:border-blue-500/40 transition-all flex flex-col justify-between">
              <div>
                <div className="w-10 h-10 rounded-2xl bg-blue-500/10 border border-blue-500/20 text-blue-400 flex items-center justify-center mb-4">
                  <Terminal className="w-5 h-5" />
                </div>
                <h3 className="text-base font-bold text-white mb-2">KeyAuth v1 Drop-in API</h3>
                <p className="text-xs text-zinc-400 leading-relaxed">
                  Full wire-level compatibility with KeyAuth v1.x (v1.0 - v1.4) protocol at <code className="text-red-400 bg-zinc-950 px-1 py-0.5 rounded font-mono text-[11px]">/api/1.3/</code>. Drop in our client files and your apps authenticate immediately.
                </p>
              </div>
              <div className="mt-6 pt-4 border-t border-zinc-800/80">
                <span className="text-[11px] font-mono font-bold text-blue-400 uppercase">C#, C++, Python, JS</span>
              </div>
            </div>
          </div>

          <div className="p-8 rounded-3xl bg-zinc-900/60 border border-zinc-800/80 max-w-4xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-6 shadow-2xl">
            <div>
              <h3 className="text-lg font-bold text-white tracking-tight">Ready to migrate your KeyAuth project?</h3>
              <p className="text-xs text-zinc-400 mt-1">
                Point your API URL to this web platform and start generating unlimited keys right now.
              </p>
            </div>
            <div className="flex items-center gap-3 shrink-0">
              <button
                onClick={onExploreSDK}
                className="px-5 py-2.5 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-white font-bold text-xs uppercase tracking-wider transition-colors flex items-center gap-2"
              >
                <Terminal className="w-4 h-4 text-red-400" /> KeyAuth SDK
              </button>
              <button
                onClick={onGetStarted}
                className="px-6 py-2.5 rounded-xl bg-red-600 hover:bg-red-500 text-white font-bold text-xs uppercase tracking-wider transition-all shadow-[0_0_20px_rgba(239,68,68,0.4)]"
              >
                GET STARTED FREE
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* SECURITY SECTION */}
      <section className="py-20 border-t border-zinc-800/60 bg-zinc-950/70">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <span className="text-xs font-bold text-red-500 uppercase tracking-widest font-mono">
              Enterprise Grade Protection
            </span>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-white mt-2 tracking-tight">
              SECURITY AT EVERY LAYER
            </h2>
            <p className="text-zinc-400 text-sm mt-3">
              Built from scratch with zero compromises on password safety, privacy, and token isolation.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-5xl mx-auto">
            <div className="p-6 rounded-2xl bg-zinc-900/40 border border-zinc-800">
              <Lock className="w-6 h-6 text-red-400 mb-3" />
              <h4 className="text-sm font-bold text-white mb-1.5">No Plaintext Passwords</h4>
              <p className="text-xs text-zinc-400 leading-relaxed">
                Passwords are authenticated using bcrypt with unique cryptographically generated salts. Passwords never touch database logs or public APIs.
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-zinc-900/40 border border-zinc-800">
              <Shield className="w-6 h-6 text-red-400 mb-3" />
              <h4 className="text-sm font-bold text-white mb-1.5">Application Secrets Protection</h4>
              <p className="text-xs text-zinc-400 leading-relaxed">
                Secrets are never sent over unauthenticated channels. They can be rotated or regenerated instantly with zero downtime for existing active users.
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-zinc-900/40 border border-zinc-800">
              <Zap className="w-6 h-6 text-red-400 mb-3" />
              <h4 className="text-sm font-bold text-white mb-1.5">Rate Limiting & Anti-Brute-Force</h4>
              <p className="text-xs text-zinc-400 leading-relaxed">
                Sliding-window IP and application rate limiting shields all login, registration, and license activation endpoints.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ SECTION */}
      <section className="py-20 border-t border-zinc-800/60">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <span className="text-xs font-bold text-red-500 uppercase tracking-widest font-mono">
              Got Questions?
            </span>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-white mt-2 tracking-tight">
              FREQUENTLY ASKED QUESTIONS
            </h2>
          </div>

          <div className="space-y-4">
            {faqs.map((faq, idx) => (
              <div
                key={idx}
                className="rounded-2xl bg-zinc-900/40 border border-zinc-800 overflow-hidden transition-colors"
              >
                <button
                  onClick={() => setOpenFaq(openFaq === idx ? null : idx)}
                  className="w-full flex items-center justify-between p-5 text-left text-sm font-bold text-white hover:text-red-400 transition-colors"
                >
                  <span className="flex items-center gap-3">
                    <HelpCircle className="w-4 h-4 text-red-400 shrink-0" />
                    {faq.q}
                  </span>
                  <ChevronRight
                    className={`w-4 h-4 text-zinc-400 transition-transform duration-200 ${
                      openFaq === idx ? 'rotate-90 text-red-400' : ''
                    }`}
                  />
                </button>
                {openFaq === idx && (
                  <div className="px-5 pb-5 pt-1 text-xs text-zinc-400 border-t border-zinc-800/60 leading-relaxed">
                    {faq.a}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ABOUT SECTION IN LANDING */}
      <section className="py-20 border-t border-zinc-800/60 bg-zinc-950/80">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="w-12 h-12 rounded-2xl bg-red-600/10 border border-red-500/30 flex items-center justify-center text-red-400 mx-auto mb-4">
            <Shield className="w-6 h-6" />
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight uppercase">
            ABOUT SPIDEY AUTH
          </h2>
          <p className="mt-4 text-sm sm:text-base text-zinc-300 leading-relaxed max-w-2xl mx-auto">
            Spidey Auth is a modern authentication and licensing platform designed to help developers securely manage users, applications, licenses and API access.
          </p>
          <div className="mt-6 flex items-center justify-center gap-2 text-xs text-zinc-400">
            <span>Engineered with high-performance C#, C++, Python & TypeScript support.</span>
          </div>
          <div className="mt-4 inline-block font-mono text-xs font-bold text-red-400 bg-red-500/10 border border-red-500/20 px-3 py-1 rounded-full">
            Built by Spidey
          </div>
        </div>
      </section>
    </div>
  );
};
