import React, { useState } from 'react';
import {
  BookOpen,
  Search,
  Code2,
  Terminal,
  Shield,
  KeyRound,
  Users,
  AlertTriangle,
  Zap,
  Lock,
  ChevronRight,
  Copy,
  Check,
} from 'lucide-react';
import { CodeBlock } from '../ui/CodeBlock';

export const DocsPage: React.FC = () => {
  const [activeSection, setActiveSection] = useState('getting-started');
  const [search, setSearch] = useState('');
  const [langTab, setLangTab] = useState<'csharp' | 'cpp' | 'python' | 'js'>('csharp');

  const navSections = [
    { id: 'getting-started', title: 'Getting Started' },
    { id: 'creating-app', title: 'Creating an Application' },
    { id: 'creating-users', title: 'Creating Users' },
    { id: 'creating-licenses', title: 'Creating License Keys' },
    { id: 'auth-flow', title: 'Authentication Flow' },
    { id: 'license-activation', title: 'License Activation' },
    { id: 'api-reference', title: 'API Reference' },
    { id: 'keyauth-compat', title: 'KeyAuth Drop-In Compatibility' },
    { id: 'sdk-csharp', title: 'C# SDK' },
    { id: 'sdk-cpp', title: 'C++ SDK' },
    { id: 'sdk-python', title: 'Python SDK' },
    { id: 'sdk-js', title: 'JavaScript SDK' },
    { id: 'error-codes', title: 'Error Codes' },
    { id: 'rate-limits', title: 'Rate Limits' },
    { id: 'security', title: 'Security Architecture' },
    { id: 'faq', title: 'FAQ' },
  ];

  const filteredNav = navSections.filter((s) =>
    s.title.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
      <div className="flex flex-col lg:flex-row gap-8 items-start">
        {/* Docs Sidebar */}
        <div className="w-full lg:w-64 shrink-0 rounded-2xl bg-zinc-900/50 border border-zinc-800 p-4 sticky top-20 max-h-[85vh] overflow-y-auto custom-scrollbar">
          <div className="relative mb-4">
            <Search className="absolute left-3 top-2.5 w-3.5 h-3.5 text-zinc-500" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search docs..."
              className="w-full bg-zinc-950 border border-zinc-800 rounded-xl py-1.5 pl-8 pr-3 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-red-500"
            />
          </div>

          <div className="space-y-1">
            {filteredNav.map((sec) => (
              <button
                key={sec.id}
                onClick={() => setActiveSection(sec.id)}
                className={`w-full text-left px-3 py-2 rounded-xl text-xs font-semibold transition-colors flex items-center justify-between ${
                  activeSection === sec.id
                    ? 'bg-red-600 text-white font-bold shadow-md'
                    : 'text-zinc-400 hover:text-white hover:bg-zinc-800/60'
                }`}
              >
                <span>{sec.title}</span>
                {activeSection === sec.id && <ChevronRight className="w-3.5 h-3.5" />}
              </button>
            ))}
          </div>
        </div>

        {/* Content Area */}
        <div className="flex-1 w-full p-6 sm:p-8 rounded-3xl bg-zinc-900/40 border border-zinc-800/80 backdrop-blur-xl space-y-8">
          {/* Section: Getting Started */}
          {activeSection === 'getting-started' && (
            <div className="space-y-6">
              <div>
                <span className="text-xs font-mono font-bold text-red-500 uppercase tracking-widest">
                  Overview
                </span>
                <h1 className="text-3xl font-extrabold text-white mt-1 tracking-tight">
                  Getting Started with Spidey Auth
                </h1>
                <p className="text-sm text-zinc-400 mt-2 leading-relaxed">
                  Spidey Auth enables software developers, indie game studios, and enterprise tool builders to securely license applications, verify end-user identities, and distribute software keys without managing their own complex auth infrastructure.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="p-4 rounded-xl bg-zinc-950/60 border border-zinc-800">
                  <span className="font-mono text-red-400 font-bold block mb-1">Step 1</span>
                  <h4 className="text-xs font-bold text-white mb-1">Register Account</h4>
                  <p className="text-[11px] text-zinc-400">Sign in with email/password or Google OAuth to access the developer console.</p>
                </div>
                <div className="p-4 rounded-xl bg-zinc-950/60 border border-zinc-800">
                  <span className="font-mono text-red-400 font-bold block mb-1">Step 2</span>
                  <h4 className="text-xs font-bold text-white mb-1">Create App</h4>
                  <p className="text-[11px] text-zinc-400">Generate an Application ID and secure secret to isolate your software.</p>
                </div>
                <div className="p-4 rounded-xl bg-zinc-950/60 border border-zinc-800">
                  <span className="font-mono text-red-400 font-bold block mb-1">Step 3</span>
                  <h4 className="text-xs font-bold text-white mb-1">Integrate SDK</h4>
                  <p className="text-[11px] text-zinc-400">Install the official client library in C#, C++, Python, or TypeScript.</p>
                </div>
              </div>

              <CodeBlock
                code={`// Basic C# Integration
using SpideyAuthSDK;

var auth = new SpideyAuth("APP-92JD83", "spy_sec_your_secret");
var login = await auth.LoginAsync("player123", "password123");

if (login.Success) {
    Console.WriteLine($"Welcome, {login.Data?.Username}!");
}`}
                language="csharp"
                title="Quick Initialization Example"
              />
            </div>
          )}

          {/* Section: Creating an Application */}
          {activeSection === 'creating-app' && (
            <div className="space-y-6">
              <div>
                <span className="text-xs font-mono font-bold text-red-500 uppercase tracking-widest">
                  Lifecycle
                </span>
                <h1 className="text-3xl font-extrabold text-white mt-1 tracking-tight">
                  Creating an Application
                </h1>
                <p className="text-sm text-zinc-400 mt-2 leading-relaxed">
                  Applications represent distinct software projects. Each application has its own users, license keys, and cryptographic secret.
                </p>
              </div>

              <div className="p-4 rounded-xl bg-zinc-950/60 border border-zinc-800 text-xs space-y-2">
                <h4 className="font-bold text-white uppercase text-[11px] font-mono">Generated Credentials</h4>
                <ul className="list-disc pl-5 space-y-1 text-zinc-300">
                  <li><strong className="text-white">Application ID:</strong> Formatted as <code className="text-red-400">APP-XXXXXX</code>, uniquely identifies your project.</li>
                  <li><strong className="text-white">Owner ID:</strong> Formatted as <code className="text-red-400">SPY-OWNER-XXXXXX</code>, establishes developer ownership.</li>
                  <li><strong className="text-white">Application Secret:</strong> 256-bit cryptographic hex key. Never expose in public frontend code.</li>
                </ul>
              </div>
            </div>
          )}

          {/* Section: Creating Users */}
          {activeSection === 'creating-users' && (
            <div className="space-y-6">
              <div>
                <span className="text-xs font-mono font-bold text-red-500 uppercase tracking-widest">
                  User Management
                </span>
                <h1 className="text-3xl font-extrabold text-white mt-1 tracking-tight">
                  Developer User Management
                </h1>
                <p className="text-sm text-zinc-400 mt-2 leading-relaxed">
                  Developers can manage end-user accounts for their applications either directly via the Spidey Auth dashboard or programmatically through the registration API.
                </p>
              </div>

              <CodeBlock
                code={`POST /api/user/register
Headers:
  x-application-id: APP-92JD83
  x-application-secret: spy_sec_your_secret

Body:
{
  "applicationId": "APP-92JD83",
  "applicationSecret": "spy_sec_your_secret",
  "username": "player123",
  "password": "strongPassword123!",
  "email": "player@example.com",
  "licenseKey": "SPIDEY-XXXX-XXXX-XXXX-XXXX" // Optional license key activation
}`}
                language="json"
                title="User Registration Endpoint"
              />
            </div>
          )}

          {/* Section: Creating License Keys */}
          {activeSection === 'creating-licenses' && (
            <div className="space-y-6">
              <div>
                <span className="text-xs font-mono font-bold text-red-500 uppercase tracking-widest">
                  Licensing
                </span>
                <h1 className="text-3xl font-extrabold text-white mt-1 tracking-tight">
                  License Key System
                </h1>
                <p className="text-sm text-zinc-400 mt-2 leading-relaxed">
                  Keys are generated in standard blocks: <code className="text-red-400 font-mono">SPIDEY-XXXX-XXXX-XXXX-XXXX</code>.
                </p>
              </div>

              <div className="p-4 rounded-xl bg-zinc-950/60 border border-zinc-800 text-xs space-y-2">
                <h4 className="font-bold text-white uppercase text-[11px] font-mono">License Statuses</h4>
                <div className="grid grid-cols-2 gap-2 text-[11px]">
                  <div><strong className="text-emerald-400">ACTIVE:</strong> Ready for activation</div>
                  <div><strong className="text-blue-400">USED:</strong> Max activations reached</div>
                  <div><strong className="text-zinc-400">EXPIRED:</strong> Past expiration date</div>
                  <div><strong className="text-red-400">REVOKED:</strong> Administratively cancelled</div>
                </div>
              </div>
            </div>
          )}

          {/* Section: API Reference */}
          {activeSection === 'api-reference' && (
            <div className="space-y-6">
              <div>
                <span className="text-xs font-mono font-bold text-red-500 uppercase tracking-widest">
                  REST API
                </span>
                <h1 className="text-3xl font-extrabold text-white mt-1 tracking-tight">
                  REST API Reference
                </h1>
                <p className="text-sm text-zinc-400 mt-2 leading-relaxed">
                  Complete endpoints for client authentication, license validation, and user management.
                </p>
              </div>

              <div className="space-y-4">
                <div className="p-4 rounded-xl bg-zinc-950/60 border border-zinc-800">
                  <div className="flex items-center gap-2 mb-2">
                    <span className="bg-red-600 text-white font-mono text-[10px] font-bold px-2 py-0.5 rounded">POST</span>
                    <code className="text-xs font-mono text-zinc-200">/api/user/login</code>
                  </div>
                  <p className="text-xs text-zinc-400">Authenticates an application user with username and password.</p>
                </div>

                <div className="p-4 rounded-xl bg-zinc-950/60 border border-zinc-800">
                  <div className="flex items-center gap-2 mb-2">
                    <span className="bg-red-600 text-white font-mono text-[10px] font-bold px-2 py-0.5 rounded">POST</span>
                    <code className="text-xs font-mono text-zinc-200">/api/license/activate</code>
                  </div>
                  <p className="text-xs text-zinc-400">Activates a license key with client hardware identifier.</p>
                </div>

                <div className="p-4 rounded-xl bg-zinc-950/60 border border-zinc-800">
                  <div className="flex items-center gap-2 mb-2">
                    <span className="bg-red-600 text-white font-mono text-[10px] font-bold px-2 py-0.5 rounded">POST</span>
                    <code className="text-xs font-mono text-zinc-200">/api/license/validate</code>
                  </div>
                  <p className="text-xs text-zinc-400">Verifies if a license key is currently valid and active.</p>
                </div>

                <div className="p-4 rounded-xl bg-zinc-950/60 border border-zinc-800">
                  <div className="flex items-center gap-2 mb-2">
                    <span className="bg-emerald-600 text-white font-mono text-[10px] font-bold px-2 py-0.5 rounded">GET</span>
                    <code className="text-xs font-mono text-zinc-200">/status</code>
                  </div>
                  <p className="text-xs text-zinc-400">Health check returning operational status of API, Database, and Auth services.</p>
                </div>
              </div>
            </div>
          )}

          {/* Section: Error Codes */}
          {activeSection === 'error-codes' && (
            <div className="space-y-6">
              <div>
                <span className="text-xs font-mono font-bold text-red-500 uppercase tracking-widest">
                  Standards
                </span>
                <h1 className="text-3xl font-extrabold text-white mt-1 tracking-tight">
                  Error Code Directory
                </h1>
                <p className="text-sm text-zinc-400 mt-2 leading-relaxed">
                  Consistent JSON error responses for reliable client error handling.
                </p>
              </div>

              <div className="rounded-xl border border-zinc-800 overflow-hidden text-xs font-mono">
                <table className="w-full text-left">
                  <thead className="bg-zinc-950 p-3 text-zinc-400 text-[10px] uppercase">
                    <tr>
                      <th className="p-3">Error Code</th>
                      <th className="p-3">HTTP Status</th>
                      <th className="p-3">Description</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-zinc-800 text-zinc-300">
                    <tr>
                      <td className="p-3 text-red-400 font-bold">INVALID_USERNAME</td>
                      <td className="p-3">404</td>
                      <td className="p-3 font-sans">User does not exist in this application.</td>
                    </tr>
                    <tr>
                      <td className="p-3 text-red-400 font-bold">INVALID_PASSWORD</td>
                      <td className="p-3">401</td>
                      <td className="p-3 font-sans">The password provided does not match.</td>
                    </tr>
                    <tr>
                      <td className="p-3 text-red-400 font-bold">USER_BANNED</td>
                      <td className="p-3">403</td>
                      <td className="p-3 font-sans">User has been banned by developer.</td>
                    </tr>
                    <tr>
                      <td className="p-3 text-red-400 font-bold">USER_EXPIRED</td>
                      <td className="p-3">403</td>
                      <td className="p-3 font-sans">User account expiration date reached.</td>
                    </tr>
                    <tr>
                      <td className="p-3 text-red-400 font-bold">INVALID_LICENSE</td>
                      <td className="p-3">404</td>
                      <td className="p-3 font-sans">License key not found or mistyped.</td>
                    </tr>
                    <tr>
                      <td className="p-3 text-red-400 font-bold">ACTIVATION_LIMIT_REACHED</td>
                      <td className="p-3">403</td>
                      <td className="p-3 font-sans">Maximum device activation count reached.</td>
                    </tr>
                    <tr>
                      <td className="p-3 text-red-400 font-bold">RATE_LIMITED</td>
                      <td className="p-3">429</td>
                      <td className="p-3 font-sans">Too many requests made from this IP.</td>
                    </tr>
                    <tr>
                      <td className="p-3 text-red-400 font-bold">APPLICATION_DISABLED</td>
                      <td className="p-3">403</td>
                      <td className="p-3 font-sans">Application is disabled by owner or admin.</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* Section: Rate Limits */}
          {activeSection === 'rate-limits' && (
            <div className="space-y-6">
              <div>
                <span className="text-xs font-mono font-bold text-red-500 uppercase tracking-widest">
                  Throttling
                </span>
                <h1 className="text-3xl font-extrabold text-white mt-1 tracking-tight">
                  Rate Limits & Protection
                </h1>
                <p className="text-sm text-zinc-400 mt-2 leading-relaxed">
                  Spidey Auth employs sliding-window IP rate limiting to mitigate denial-of-service and brute-force credential stuffing.
                </p>
              </div>

              <div className="p-4 rounded-xl bg-zinc-950/60 border border-zinc-800 text-xs space-y-2">
                <h4 className="font-bold text-white uppercase text-[11px] font-mono">Default Limits</h4>
                <ul className="list-disc pl-5 space-y-1 text-zinc-300">
                  <li><strong>/api/auth/login & /api/auth/register:</strong> 30 requests / minute / IP</li>
                  <li><strong>/api/user/login:</strong> 120 requests / minute / IP</li>
                  <li><strong>/api/license/activate & validate:</strong> 120 requests / minute / IP</li>
                </ul>
              </div>
            </div>
          )}

          {/* Section: Security */}
          {activeSection === 'security' && (
            <div className="space-y-6">
              <div>
                <span className="text-xs font-mono font-bold text-red-500 uppercase tracking-widest">
                  Hardened Protection
                </span>
                <h1 className="text-3xl font-extrabold text-white mt-1 tracking-tight">
                  Security Architecture
                </h1>
                <p className="text-sm text-zinc-400 mt-2 leading-relaxed">
                  Engineered from the ground up for strict multi-tenant safety and compliance.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-4 rounded-xl bg-zinc-950/60 border border-zinc-800 text-xs">
                  <h4 className="font-bold text-white mb-1">Salted Bcrypt Passwords</h4>
                  <p className="text-zinc-400">Passwords are cryptographically salted and hashed. Plaintext passwords never exist in memory longer than the request duration.</p>
                </div>
                <div className="p-4 rounded-xl bg-zinc-950/60 border border-zinc-800 text-xs">
                  <h4 className="font-bold text-white mb-1">Masked Application Secrets</h4>
                  <p className="text-zinc-400">Secrets are stored securely and masked in all UI lists. They can be rotated on demand without affecting existing licenses.</p>
                </div>
              </div>
            </div>
          )}

          {/* Section: C# SDK */}
          {activeSection === 'sdk-csharp' && (
            <div className="space-y-6">
              <h1 className="text-3xl font-extrabold text-white tracking-tight">C# / .NET SDK</h1>
              <p className="text-xs text-zinc-400">Built for .NET Core, WPF desktop applications, and Unity game clients.</p>
              <CodeBlock
                code={`using SpideyAuthSDK;

var auth = new SpideyAuth("APP-92JD83", "spy_sec_your_secret");

// 1. Login
var loginRes = await auth.LoginAsync("player123", "password123");
if (loginRes.Success) {
    Console.WriteLine($"Logged in: {loginRes.Data?.Username}");
}

// 2. Activate License
var licRes = await auth.ActivateLicenseAsync("SPIDEY-XXXX-XXXX-XXXX-XXXX");
if (licRes.Success) {
    Console.WriteLine($"Activated: {licRes.Data?.SubscriptionType}");
}`}
                language="csharp"
                title="C# SDK Integration"
              />
            </div>
          )}

          {/* Section: C++ SDK */}
          {activeSection === 'sdk-cpp' && (
            <div className="space-y-6">
              <h1 className="text-3xl font-extrabold text-white tracking-tight">C++ Native SDK</h1>
              <p className="text-xs text-zinc-400">High-performance client for native gaming and anti-cheat friendly software.</p>
              <CodeBlock
                code={`#include "SpideyAuth.hpp"

SpideyAuth::Client auth("APP-92JD83", "spy_sec_your_secret");
SpideyAuth::User user;
auto res = auth.Login("player123", "password123", user);

if (res.success) {
    std::cout << "Authenticated: " << user.username << std::endl;
}`}
                language="cpp"
                title="C++ SDK Integration"
              />
            </div>
          )}

          {/* Section: Python SDK */}
          {activeSection === 'sdk-python' && (
            <div className="space-y-6">
              <h1 className="text-3xl font-extrabold text-white tracking-tight">Python SDK</h1>
              <p className="text-xs text-zinc-400">Official library for automation scripts, PySide/Tkinter desktop apps, and servers.</p>
              <CodeBlock
                code={`from spidey_auth import SpideyAuth

auth = SpideyAuth(
    application_id="APP-92JD83",
    application_secret="spy_sec_your_secret"
)

# Login
user = auth.login("player123", "password123")
print("User authenticated:", user["user"]["username"])

# Activate License
lic = auth.activate_license("SPIDEY-XXXX-XXXX-XXXX-XXXX")
print("License active:", lic["license"]["status"])`}
                language="python"
                title="Python SDK Integration"
              />
            </div>
          )}

          {/* Section: KeyAuth Drop-In Compatibility */}
          {activeSection === 'keyauth-compat' && (
            <div className="space-y-6">
              <div>
                <span className="text-xs font-mono font-bold text-amber-400 uppercase tracking-widest flex items-center gap-1.5">
                  <Zap className="w-4 h-4" /> Migration & Compatibility
                </span>
                <h1 className="text-3xl font-extrabold text-white mt-1 tracking-tight">
                  KeyAuth v1.3 Drop-In Compatibility
                </h1>
                <p className="text-xs text-zinc-400 mt-2 leading-relaxed">
                  Migrating from KeyAuth? Spidey Auth natively implements the exact KeyAuth v1.3 wire protocol on <code className="text-red-400 font-mono">/api/1.3/</code>.
                  You can keep your existing C#, C++, Python, or web clients and simply point the API endpoint to your Spidey Auth server with zero breaking changes.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="p-3.5 rounded-xl bg-zinc-950/60 border border-zinc-800">
                  <span className="text-[10px] text-zinc-500 uppercase font-mono block">Endpoint</span>
                  <span className="text-xs font-bold text-white font-mono break-all">/api/1.3/</span>
                </div>
                <div className="p-3.5 rounded-xl bg-zinc-950/60 border border-zinc-800">
                  <span className="text-[10px] text-zinc-500 uppercase font-mono block">App Identifier</span>
                  <span className="text-xs font-bold text-amber-400 font-mono">App Name + Owner Code</span>
                </div>
                <div className="p-3.5 rounded-xl bg-zinc-950/60 border border-zinc-800">
                  <span className="text-[10px] text-zinc-500 uppercase font-mono block">Supported Methods</span>
                  <span className="text-xs font-bold text-emerald-400 font-mono">init, login, license, register</span>
                </div>
              </div>

              <div className="space-y-3">
                <h3 className="text-sm font-bold text-white">1. C# Windows Forms (Form1 / Login Button) Implementation</h3>
                <p className="text-xs text-zinc-400">
                  Include <code className="text-red-300 font-mono">KeyAuthApp.cs</code> into your Windows Forms / WPF project and initialize it inside your form:
                </p>
                <CodeBlock
                  code={`using System;
using System.Windows.Forms;
using KeyAuth;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        // 1. Initialize client pointing to this Spidey Auth web instance
        public static api KeyAuthApp = new api(
            name: "Apex Velocity",                         // Application Name from Spidey Auth
            ownerid: "SPY-OWNER-82HD72",                   // Owner ID from Spidey Auth Dashboard
            version: "1.0",                                // Version
            path: null,
            url: "https://your-domain.com/api/1.3/"         // Spidey Auth Gateway
        );

        public Form1()
        {
            InitializeComponent();

            try
            {
                KeyAuthApp.init(); // MUST run before ANY login
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Init Failed");
                Environment.Exit(0);
            }
        }

        // (IN LOGIN BUTTON)
        private void LoginBtn_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(User.Text) || string.IsNullOrWhiteSpace(Pass.Text))
            {
                MessageBox.Show("Username or Password empty");
                return;
            }

            KeyAuthApp.login(User.Text, Pass.Text);

            if (KeyAuthApp.response.success)
            {
                // Successful authentication! Open Form2 and hide Form1
                Form1 f2 = new Form2();
                f2.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show(KeyAuthApp.response.message, "Login Failed");
            }
        }
    }
}`}
                  language="csharp"
                  title="C# Windows Forms (Form1) KeyAuth Drop-In"
                />
              </div>

              <div className="space-y-3">
                <h3 className="text-sm font-bold text-white">2. C# Console / Background Service</h3>
                <CodeBlock
                  code={`using KeyAuth;

// Connect to your Spidey Auth instance
public static api KeyAuthApp = new api(
    name: "Apex Velocity",
    ownerid: "SPY-OWNER-82HD72",
    version: "1.0",
    url: "https://your-domain.com/api/1.3/"
);

KeyAuthApp.init();

// Login
KeyAuthApp.login("player123", "mypassword");
if (KeyAuthApp.response.success) {
    Console.WriteLine("Logged in! User: " + KeyAuthApp.user_data.username);
} else {
    Console.WriteLine("Error: " + KeyAuthApp.response.message);
}`}
                  language="csharp"
                  title="C# KeyAuth Console Implementation"
                />
              </div>

              <div className="space-y-3">
                <h3 className="text-sm font-bold text-white">2. Python Drop-In Example</h3>
                <CodeBlock
                  code={`from keyauth_compat import KeyAuth

app = KeyAuth(
    name="Apex Velocity",
    ownerid="SPY-OWNER-82HD72",
    version="1.0",
    url="https://your-domain.com/api/1.3/"
)

app.init()

# Authenticate user
if app.login("player123", "mypassword"):
    print("Logged in as:", app.user_data.username)
else:
    print("Login error:", app.response.message)`}
                  language="python"
                  title="Python KeyAuth Compatibility"
                />
              </div>

              <div className="space-y-3">
                <h3 className="text-sm font-bold text-white">3. Supported Wire Protocol Actions</h3>
                <div className="overflow-x-auto rounded-xl border border-zinc-800">
                  <table className="w-full text-left text-xs font-mono">
                    <thead className="bg-zinc-950/80 text-zinc-400 border-b border-zinc-800">
                      <tr>
                        <th className="p-3">Action (type)</th>
                        <th className="p-3">Parameters</th>
                        <th className="p-3">Description</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-zinc-800/60 bg-zinc-900/30 text-zinc-300">
                      <tr>
                        <td className="p-3 text-red-400 font-bold">init</td>
                        <td className="p-3 text-zinc-400">name, ownerid, ver</td>
                        <td className="p-3">Creates active session and returns application metrics</td>
                      </tr>
                      <tr>
                        <td className="p-3 text-red-400 font-bold">login</td>
                        <td className="p-3 text-zinc-400">username, pass, hwid, sessionid</td>
                        <td className="p-3">Authenticates application user & verifies hardware ID</td>
                      </tr>
                      <tr>
                        <td className="p-3 text-red-400 font-bold">register</td>
                        <td className="p-3 text-zinc-400">username, pass, key, hwid, sessionid</td>
                        <td className="p-3">Registers new user and optionally consumes license key</td>
                      </tr>
                      <tr>
                        <td className="p-3 text-red-400 font-bold">license</td>
                        <td className="p-3 text-zinc-400">key, hwid, sessionid</td>
                        <td className="p-3">Direct license key authentication without username</td>
                      </tr>
                      <tr>
                        <td className="p-3 text-red-400 font-bold">check</td>
                        <td className="p-3 text-zinc-400">sessionid</td>
                        <td className="p-3">Validates session integrity and keep-alive</td>
                      </tr>
                      <tr>
                        <td className="p-3 text-red-400 font-bold">fetchstats</td>
                        <td className="p-3 text-zinc-400">sessionid</td>
                        <td className="p-3">Fetches current online users and total keys count</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* Section: JavaScript SDK */}
          {activeSection === 'sdk-js' && (
            <div className="space-y-6">
              <h1 className="text-3xl font-extrabold text-white tracking-tight">JavaScript & TypeScript SDK</h1>
              <p className="text-xs text-zinc-400">Modern client library for Electron, Node.js, Next.js, and browser web applications.</p>
              <CodeBlock
                code={`import { SpideyAuth } from '@spideyauth/sdk';

const auth = new SpideyAuth({
  applicationId: 'APP-92JD83',
  applicationSecret: 'spy_sec_your_secret',
});

// Authenticate
const user = await auth.login('player123', 'secretPassword!');
console.log('User logged in:', user.username);

// Activate License
const license = await auth.activateLicense('SPIDEY-XXXX-XXXX-XXXX-XXXX');
console.log('License active:', license.status);`}
                language="typescript"
                title="JavaScript / TypeScript SDK"
              />
            </div>
          )}

          {/* Section: FAQ */}
          {activeSection === 'faq' && (
            <div className="space-y-6">
              <h1 className="text-3xl font-extrabold text-white tracking-tight">Frequently Asked Questions</h1>
              <div className="space-y-4 text-xs text-zinc-300">
                <div className="p-4 rounded-xl bg-zinc-950/60 border border-zinc-800">
                  <h4 className="font-bold text-white mb-1">Can I reset a user password if they forgot it?</h4>
                  <p className="text-zinc-400">Yes! Go to Application &gt; Users, select the user, and click "Reset Password" to generate a temporary password.</p>
                </div>
                <div className="p-4 rounded-xl bg-zinc-950/60 border border-zinc-800">
                  <h4 className="font-bold text-white mb-1">What happens when I hit 20 keys on the Free Plan?</h4>
                  <p className="text-zinc-400">The platform displays a prompt notifying you of the Free plan limit and offers an instant upgrade to the Premium plan for unlimited keys.</p>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
