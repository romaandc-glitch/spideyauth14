import React from 'react';
import { LucideIcon } from 'lucide-react';

interface StatCardProps {
  title: string;
  value: string | number;
  subtitle?: string;
  icon: LucideIcon;
  badge?: string;
  badgeColor?: 'red' | 'green' | 'amber' | 'blue';
  action?: {
    label: string;
    onClick: () => void;
  };
}

export const StatCard: React.FC<StatCardProps> = ({
  title,
  value,
  subtitle,
  icon: Icon,
  badge,
  badgeColor = 'red',
  action,
}) => {
  return (
    <div className="relative overflow-hidden rounded-2xl bg-zinc-900/40 border border-zinc-800/80 p-5 backdrop-blur-xl transition-all duration-300 hover:border-red-500/30 hover:shadow-[0_0_30px_rgba(239,68,68,0.08)] group">
      {/* Subtle red gradient accent in corner */}
      <div className="absolute -top-12 -right-12 w-28 h-28 bg-red-600/10 rounded-full blur-2xl group-hover:bg-red-600/20 transition-all duration-500" />

      <div className="flex items-start justify-between relative z-10">
        <div>
          <span className="text-xs font-medium uppercase tracking-wider text-zinc-400">
            {title}
          </span>
          <div className="mt-2 text-2xl sm:text-3xl font-extrabold text-white tracking-tight font-mono">
            {value}
          </div>
          {subtitle && (
            <p className="mt-1 text-xs text-zinc-400 flex items-center gap-1.5">
              {subtitle}
            </p>
          )}
        </div>

        <div className="flex flex-col items-end gap-2">
          <div className="p-2.5 rounded-xl bg-zinc-800/80 border border-zinc-700/50 text-red-400 group-hover:text-red-300 group-hover:border-red-500/40 group-hover:bg-red-500/10 transition-all duration-300">
            <Icon className="w-5 h-5" />
          </div>
          {badge && (
            <span
              className={`text-[10px] font-semibold px-2 py-0.5 rounded-full border ${
                badgeColor === 'green'
                  ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
                  : badgeColor === 'amber'
                  ? 'bg-amber-500/10 text-amber-400 border-amber-500/30'
                  : badgeColor === 'blue'
                  ? 'bg-cyan-500/10 text-cyan-400 border-cyan-500/30'
                  : 'bg-red-500/10 text-red-400 border-red-500/30'
              }`}
            >
              {badge}
            </span>
          )}
        </div>
      </div>

      {action && (
        <div className="mt-4 pt-3 border-t border-zinc-800/60 relative z-10 flex justify-end">
          <button
            onClick={action.onClick}
            className="text-xs font-semibold text-red-400 hover:text-red-300 transition-colors"
          >
            {action.label} →
          </button>
        </div>
      )}
    </div>
  );
};
