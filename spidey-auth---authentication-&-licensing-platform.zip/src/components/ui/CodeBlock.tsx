import React, { useState } from 'react';
import { Copy, Check } from 'lucide-react';

interface CodeBlockProps {
  code: string;
  language?: string;
  title?: string;
}

export const CodeBlock: React.FC<CodeBlockProps> = ({ code, language = 'bash', title }) => {
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="rounded-xl border border-zinc-800 bg-[#0d0e14] overflow-hidden shadow-lg group">
      {(title || language) && (
        <div className="flex items-center justify-between px-4 py-2.5 bg-zinc-900/60 border-b border-zinc-800/80 text-xs text-zinc-400 font-mono">
          <div className="flex items-center gap-2">
            <div className="flex gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-red-500/30 border border-red-500/50" />
              <span className="w-2.5 h-2.5 rounded-full bg-amber-500/30 border border-amber-500/50" />
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500/30 border border-emerald-500/50" />
            </div>
            {title && <span className="font-sans text-zinc-300 font-medium ml-2">{title}</span>}
          </div>
          <div className="flex items-center gap-3">
            <span className="uppercase text-[10px] tracking-wider text-zinc-500">{language}</span>
            <button
              onClick={handleCopy}
              className="flex items-center gap-1.5 text-zinc-400 hover:text-white px-2 py-1 rounded bg-zinc-800/60 hover:bg-zinc-800 transition-colors"
            >
              {copied ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="text-emerald-400 text-xs">Copied</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  <span className="text-xs">Copy</span>
                </>
              )}
            </button>
          </div>
        </div>
      )}
      <div className="relative">
        <pre className="p-4 overflow-x-auto text-xs font-mono leading-relaxed text-zinc-200">
          <code>{code}</code>
        </pre>
        {!title && !language && (
          <button
            onClick={handleCopy}
            className="absolute top-3 right-3 text-zinc-400 hover:text-white p-2 rounded-lg bg-zinc-800/80 hover:bg-zinc-700 transition-colors opacity-0 group-hover:opacity-100"
          >
            {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
          </button>
        )}
      </div>
    </div>
  );
};
