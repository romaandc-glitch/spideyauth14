import { DeveloperUser, Application, ApplicationUser, LicenseKey, AuditLog, SystemStatus, Subscription, NotificationItem, OAuthAccount } from '../types';

const TOKEN_KEY = 'spidey_auth_token';

export const getStoredToken = (): string | null => {
  return localStorage.getItem(TOKEN_KEY);
};

export const setStoredToken = (token: string | null): void => {
  if (token) {
    localStorage.setItem(TOKEN_KEY, token);
  } else {
    localStorage.removeItem(TOKEN_KEY);
  }
};

async function apiRequest<T = any>(endpoint: string, options: RequestInit = {}): Promise<T> {
  const token = getStoredToken();
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...(options.headers as Record<string, string> || {}),
  };

  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  const response = await fetch(endpoint, {
    ...options,
    headers,
  });

  const data = await response.json().catch(() => ({ success: false, error: { message: 'Failed to parse response' } }));

  if (!response.ok || !data.success) {
    const error = new Error(data.error?.message || 'Request failed');
    (error as any).code = data.error?.code || 'UNKNOWN_ERROR';
    (error as any).details = data.error;
    throw error;
  }

  return data;
}

export const api = {
  // Auth
  async login(loginInput: string, password: string): Promise<{ token: string; user: DeveloperUser }> {
    const res = await apiRequest('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({ login: loginInput, password }),
    });
    setStoredToken(res.token);
    return res;
  },

  async register(email: string, username: string, password: string, confirmPassword: string): Promise<{ token: string; user: DeveloperUser }> {
    const res = await apiRequest('/api/auth/register', {
      method: 'POST',
      body: JSON.stringify({ email, username, password, confirmPassword }),
    });
    setStoredToken(res.token);
    return res;
  },

  async googleAuth(googleId: string, email: string, name: string, avatarUrl?: string): Promise<{ token: string; user: DeveloperUser }> {
    const res = await apiRequest('/api/auth/google', {
      method: 'POST',
      body: JSON.stringify({ googleId, email, name, avatarUrl }),
    });
    setStoredToken(res.token);
    return res;
  },

  async resetAccountPassword(email: string, newPassword: string): Promise<{ token: string; user: DeveloperUser; message: string }> {
    const res = await apiRequest('/api/auth/reset-password', {
      method: 'POST',
      body: JSON.stringify({ email, newPassword }),
    });
    setStoredToken(res.token);
    return res;
  },

  logout(): void {
    setStoredToken(null);
  },

  async getMe(): Promise<{ user: DeveloperUser; subscription: Subscription; oauthAccounts: OAuthAccount[]; notifications: NotificationItem[]; applicationsCount: number }> {
    return apiRequest('/api/auth/me');
  },

  async updateProfile(username: string, email: string): Promise<any> {
    return apiRequest('/api/auth/profile', {
      method: 'PUT',
      body: JSON.stringify({ username, email }),
    });
  },

  async updatePassword(currentPassword: string, newPassword: string): Promise<any> {
    return apiRequest('/api/auth/password', {
      method: 'PUT',
      body: JSON.stringify({ currentPassword, newPassword }),
    });
  },

  async markNotificationsRead(): Promise<any> {
    return apiRequest('/api/auth/notifications/read', { method: 'POST' });
  },

  // Applications
  async listApplications(): Promise<{ applications: Application[] }> {
    return apiRequest('/api/application');
  },

  async createApplication(name: string, description: string, version: string): Promise<{ application: Application }> {
    return apiRequest('/api/application', {
      method: 'POST',
      body: JSON.stringify({ name, description, version }),
    });
  },

  async getApplication(id: string): Promise<{ application: Application }> {
    return apiRequest(`/api/application/${id}`);
  },

  async updateApplication(id: string, data: Partial<Application>): Promise<any> {
    return apiRequest(`/api/application/${id}`, {
      method: 'PUT',
      body: JSON.stringify(data),
    });
  },

  async deleteApplication(id: string): Promise<any> {
    return apiRequest(`/api/application/${id}`, {
      method: 'DELETE',
    });
  },

  async regenerateSecret(id: string): Promise<{ secret: string; secretMasked: string }> {
    return apiRequest(`/api/application/${id}/regenerate-secret`, {
      method: 'POST',
    });
  },

  async revealSecret(id: string): Promise<{ secret: string }> {
    return apiRequest(`/api/application/${id}/secret`);
  },

  async getApplicationStats(id: string): Promise<any> {
    return apiRequest(`/api/application/${id}/statistics`);
  },

  // Application Users (End-Users)
  async listAppUsers(appId: string, params: { search?: string; status?: string; page?: number; limit?: number } = {}): Promise<{ users: ApplicationUser[]; pagination: any }> {
    const queryStr = new URLSearchParams({
      search: params.search || '',
      status: params.status || 'all',
      page: String(params.page || 1),
      limit: String(params.limit || 10),
    }).toString();
    return apiRequest(`/api/application/${appId}/users?${queryStr}`);
  },

  async createAppUser(appId: string, data: { username: string; password: string; email?: string; subscriptionRole?: string; expiresAt?: string; notes?: string }): Promise<{ user: ApplicationUser }> {
    return apiRequest(`/api/application/${appId}/users`, {
      method: 'POST',
      body: JSON.stringify(data),
    });
  },

  async updateAppUser(appId: string, userId: string, data: Partial<ApplicationUser>): Promise<any> {
    return apiRequest(`/api/application/${appId}/users/${userId}`, {
      method: 'PUT',
      body: JSON.stringify(data),
    });
  },

  async resetAppUserPassword(appId: string, userId: string, newPassword?: string): Promise<{ temporaryPassword?: string }> {
    return apiRequest(`/api/application/${appId}/users/${userId}/reset-password`, {
      method: 'POST',
      body: JSON.stringify({ newPassword }),
    });
  },

  async deleteAppUser(appId: string, userId: string): Promise<any> {
    return apiRequest(`/api/application/${appId}/users/${userId}`, {
      method: 'DELETE',
    });
  },

  // Licenses
  async listLicenses(appId: string, params: { search?: string; status?: string; type?: string; page?: number; limit?: number } = {}): Promise<{ licenses: LicenseKey[]; totalKeysInApp: number; pagination: any }> {
    const queryStr = new URLSearchParams({
      search: params.search || '',
      status: params.status || 'all',
      type: params.type || 'all',
      page: String(params.page || 1),
      limit: String(params.limit || 10),
    }).toString();
    return apiRequest(`/api/application/${appId}/licenses?${queryStr}`);
  },

  async generateSingleLicense(appId: string, data: { prefix?: string; subscriptionType?: string; maxActivations?: number; expiresAt?: string; notes?: string }): Promise<{ license: LicenseKey }> {
    return apiRequest(`/api/application/${appId}/licenses/single`, {
      method: 'POST',
      body: JSON.stringify(data),
    });
  },

  async generateBulkLicenses(appId: string, data: { count: number; prefix?: string; subscriptionType?: string; maxActivations?: number; expiresAt?: string; notes?: string }): Promise<{ count: number; keys: any[] }> {
    return apiRequest(`/api/application/${appId}/licenses/bulk`, {
      method: 'POST',
      body: JSON.stringify(data),
    });
  },

  async updateLicense(appId: string, licenseId: string, data: Partial<LicenseKey>): Promise<any> {
    return apiRequest(`/api/application/${appId}/licenses/${licenseId}`, {
      method: 'PUT',
      body: JSON.stringify(data),
    });
  },

  async deleteLicense(appId: string, licenseId: string): Promise<any> {
    return apiRequest(`/api/application/${appId}/licenses/${licenseId}`, {
      method: 'DELETE',
    });
  },

  // Subscriptions
  async getSubscription(): Promise<{ subscription: Subscription }> {
    return apiRequest('/api/subscription');
  },

  async upgradeSubscription(): Promise<{ subscription: Subscription }> {
    return apiRequest('/api/subscription/upgrade', { method: 'POST' });
  },

  async downgradeSubscription(): Promise<any> {
    return apiRequest('/api/subscription/downgrade', { method: 'POST' });
  },

  // Audit Logs
  async getAppAuditLogs(appId: string): Promise<{ logs: AuditLog[] }> {
    return apiRequest(`/api/application/${appId}/audit-logs`);
  },

  async getUserAuditLogs(): Promise<{ logs: AuditLog[] }> {
    return apiRequest('/api/audit-logs');
  },

  // Live SDK Tester Calls (Using Application ID and Application Secret)
  async sdkLogin(appId: string, appSecret: string, username: string, password: string, hwid?: string): Promise<any> {
    const res = await fetch('/api/user/login', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-application-id': appId,
        'x-application-secret': appSecret,
      },
      body: JSON.stringify({ applicationId: appId, applicationSecret: appSecret, username, password, hwid }),
    });
    return res.json();
  },

  async sdkRegister(appId: string, appSecret: string, username: string, password: string, email?: string, licenseKey?: string): Promise<any> {
    const res = await fetch('/api/user/register', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-application-id': appId,
        'x-application-secret': appSecret,
      },
      body: JSON.stringify({ applicationId: appId, applicationSecret: appSecret, username, password, email, licenseKey }),
    });
    return res.json();
  },

  async sdkActivateLicense(appId: string, appSecret: string, licenseKey: string, hwid?: string, username?: string): Promise<any> {
    const res = await fetch('/api/license/activate', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-application-id': appId,
        'x-application-secret': appSecret,
      },
      body: JSON.stringify({ applicationId: appId, applicationSecret: appSecret, licenseKey, hwid, username }),
    });
    return res.json();
  },

  async sdkValidateLicense(appId: string, appSecret: string, licenseKey: string): Promise<any> {
    const res = await fetch('/api/license/validate', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-application-id': appId,
        'x-application-secret': appSecret,
      },
      body: JSON.stringify({ applicationId: appId, applicationSecret: appSecret, licenseKey }),
    });
    return res.json();
  },

  // Admin
  async getAdminOverview(): Promise<any> {
    return apiRequest('/api/admin/overview');
  },

  async listAllUsers(): Promise<any> {
    return apiRequest('/api/admin/users');
  },

  async updateUserRole(userId: string, role: string): Promise<any> {
    return apiRequest(`/api/admin/users/${userId}/role`, {
      method: 'PUT',
      body: JSON.stringify({ role }),
    });
  },

  async toggleUserSuspension(userId: string, isSuspended: boolean): Promise<any> {
    return apiRequest(`/api/admin/users/${userId}/suspend`, {
      method: 'PUT',
      body: JSON.stringify({ isSuspended }),
    });
  },

  async listAllApps(): Promise<any> {
    return apiRequest('/api/admin/applications');
  },

  async toggleAppStatus(appId: string, status: string): Promise<any> {
    return apiRequest(`/api/admin/applications/${appId}/status`, {
      method: 'PUT',
      body: JSON.stringify({ status }),
    });
  },

  async getAllAuditLogs(): Promise<any> {
    return apiRequest('/api/admin/audit-logs');
  },

  // Status
  async getStatus(): Promise<SystemStatus> {
    const res = await fetch('/status');
    return res.json();
  },
};
