import express, { Request, Response, NextFunction } from 'express';
import cors from 'cors';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { getDatabase } from './server/db/database';
import { runMigrations } from './server/db/migrations';
import { requireAuth, requireAdmin, requireAppAuth } from './server/middleware/authMiddleware';
import { rateLimiter } from './server/middleware/rateLimiter';

import * as authController from './server/controllers/authController';
import * as appController from './server/controllers/appController';
import * as userController from './server/controllers/userController';
import * as licenseController from './server/controllers/licenseController';
import * as subscriptionController from './server/controllers/subscriptionController';
import * as auditController from './server/controllers/auditController';
import * as adminController from './server/controllers/adminController';
import * as statusController from './server/controllers/statusController';
import * as compatController from './server/controllers/compatController';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  // Initialize Database & Run Migrations
  await getDatabase();
  await runMigrations();

  const app = express();
  const PORT = parseInt(process.env.PORT || '3000', 10);

  // Security & Middleware
  app.use(cors());
  app.use(express.json({ limit: '1mb' }));
  app.use(express.urlencoded({ extended: true, limit: '1mb' }));

  // Security Headers
  app.use((_req: Request, res: Response, next: NextFunction) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('X-Frame-Options', 'SAMEORIGIN');
    res.setHeader('X-XSS-Protection', '1; mode=block');
    res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
    next();
  });

  // Health / Status endpoints
  app.get('/status', statusController.getSystemStatus);
  app.get('/api/status', statusController.getSystemStatus);

  // ==========================================
  // SPIDEY AUTH DEVELOPER ACCOUNT AUTHENTICATION
  // ==========================================
  app.post('/api/auth/register', rateLimiter(20, 60000), authController.register);
  app.post('/api/auth/login', rateLimiter(30, 60000), authController.login);
  app.post('/api/auth/google', rateLimiter(30, 60000), authController.googleAuth);
  app.post('/api/auth/reset-password', rateLimiter(20, 60000), authController.resetPassword);
  app.get('/api/auth/me', requireAuth, authController.getMe);
  app.put('/api/auth/profile', requireAuth, authController.updateProfile);
  app.put('/api/auth/password', requireAuth, authController.updatePassword);
  app.post('/api/auth/notifications/read', requireAuth, authController.markNotificationsRead);
  app.post('/api/auth/logout', (_req: Request, res: Response) => {
    res.json({ success: true, message: 'Logged out successfully.' });
  });

  // ==========================================
  // DEVELOPER APPLICATIONS SYSTEM
  // ==========================================
  app.get('/api/application', requireAuth, appController.listApplications);
  app.post('/api/application', requireAuth, appController.createApplication);
  app.get('/api/application/:id', requireAuth, appController.getApplicationDetails);
  app.put('/api/application/:id', requireAuth, appController.updateApplication);
  app.delete('/api/application/:id', requireAuth, appController.deleteApplication);
  app.post('/api/application/:id/regenerate-secret', requireAuth, appController.regenerateSecret);
  app.get('/api/application/:id/secret', requireAuth, appController.revealSecret);
  app.get('/api/application/:id/statistics', requireAuth, appController.getStatistics);

  // ==========================================
  // DEVELOPER APP USER MANAGEMENT (Dashboard)
  // ==========================================
  app.get('/api/application/:appId/users', requireAuth, userController.listApplicationUsers);
  app.post('/api/application/:appId/users', requireAuth, userController.createApplicationUser);
  app.put('/api/application/:appId/users/:userId', requireAuth, userController.updateApplicationUser);
  app.post('/api/application/:appId/users/:userId/reset-password', requireAuth, userController.resetApplicationUserPassword);
  app.delete('/api/application/:appId/users/:userId', requireAuth, userController.deleteApplicationUser);

  // ==========================================
  // DEVELOPER APP LICENSE MANAGEMENT (Dashboard)
  // ==========================================
  app.get('/api/application/:appId/licenses', requireAuth, licenseController.listApplicationLicenses);
  app.post('/api/application/:appId/licenses/single', requireAuth, licenseController.generateSingleLicense);
  app.post('/api/application/:appId/licenses/bulk', requireAuth, licenseController.generateBulkLicenses);
  app.put('/api/application/:appId/licenses/:licenseId', requireAuth, licenseController.updateLicense);
  app.delete('/api/application/:appId/licenses/:licenseId', requireAuth, licenseController.deleteLicense);

  // ==========================================
  // CLIENT / SDK AUTHENTICATION & LICENSE APIS
  // ==========================================
  // Protected with app secret check + rate limiter
  app.post('/api/user/login', rateLimiter(120, 60000), requireAppAuth, userController.apiUserLogin);
  app.post('/api/user/register', rateLimiter(60, 60000), requireAppAuth, userController.apiUserRegister);
  app.post('/api/user/reset-password', rateLimiter(30, 60000), requireAppAuth, userController.apiUserResetPassword);
  app.get('/api/user', rateLimiter(120, 60000), requireAppAuth, userController.apiGetUser);

  app.post('/api/license/activate', rateLimiter(120, 60000), requireAppAuth, licenseController.apiActivateLicense);
  app.post('/api/license/validate', rateLimiter(120, 60000), requireAppAuth, licenseController.apiValidateLicense);
  app.post('/api/license/revoke', rateLimiter(60, 60000), requireAppAuth, licenseController.apiRevokeLicense);

  // ==========================================
  // SUBSCRIPTION & PLANS
  // ==========================================
  app.get('/api/subscription', requireAuth, subscriptionController.getSubscription);
  app.post('/api/subscription/upgrade', requireAuth, subscriptionController.upgradeSubscription);
  app.post('/api/subscription/downgrade', requireAuth, subscriptionController.downgradeSubscription);

  // ==========================================
  // AUDIT LOGS
  // ==========================================
  app.get('/api/application/:appId/audit-logs', requireAuth, auditController.getAppAuditLogs);
  app.get('/api/audit-logs', requireAuth, auditController.getUserAuditLogs);

  // ==========================================
  // ADMIN PANEL
  // ==========================================
  app.get('/api/admin/overview', requireAdmin, adminController.getAdminOverview);
  app.get('/api/admin/users', requireAdmin, adminController.listAllUsers);
  app.put('/api/admin/users/:userId/role', requireAdmin, adminController.updateUserRole);
  app.put('/api/admin/users/:userId/suspend', requireAdmin, adminController.toggleUserSuspension);
  app.get('/api/admin/applications', requireAdmin, adminController.listAllApplications);
  app.put('/api/admin/applications/:appId/status', requireAdmin, adminController.toggleAppStatus);
  app.get('/api/admin/audit-logs', requireAdmin, adminController.getAllAuditLogs);

  // ==========================================
  // CLIENT COMPATIBILITY API (KeyAuth v1.0, v1.1, v1.2, v1.3, v1.4 drop-in wire protocol)
  // ==========================================
  app.all([
    '/api/1.3', '/api/1.3/*',
    '/api/v1.3', '/api/v1.3/*',
    '/api/1.2', '/api/1.2/*',
    '/api/v1.2', '/api/v1.2/*',
    '/api/1.1', '/api/1.1/*',
    '/api/v1.1', '/api/v1.1/*',
    '/api/1.0', '/api/1.0/*',
    '/api/v1.0', '/api/v1.0/*',
    '/api/1.4', '/api/1.4/*',
    '/api/v1', '/api/v1/*',
    '/api/keyauth', '/api/keyauth/*',
    '/1.3', '/1.3/*',
    '/1.2', '/1.2/*',
    '/1.1', '/1.1/*',
    '/1.0', '/1.0/*',
  ], compatController.handleCompatApi);

  // ==========================================
  // VITE DEV MIDDLEWARE / STATIC ASSETS
  // ==========================================
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[SPIDEY AUTH] Server running at http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('[SPIDEY AUTH] Failed to start server:', err);
  process.exit(1);
});
